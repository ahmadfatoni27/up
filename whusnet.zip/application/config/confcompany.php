<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
//adding config items.
$config['companyName'] = 'Whusnet'; // 
$config['urlgatewaywa'] = 'http://apiwa.whusnet.com'; // url gatway from whatsva.
// $config['key_cronjob'] = '53nh46u74m3nt3';
?>