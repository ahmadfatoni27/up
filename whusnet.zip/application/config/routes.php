<?php

defined('BASEPATH') or exit('No direct script access allowed');



/*

| -------------------------------------------------------------------------

| URI ROUTING

| -------------------------------------------------------------------------

| This file lets you re-map URI requests to specific controller functions.

|

| Typically there is a one-to-one relationship between a URL string

| and its corresponding controller class/method. The segments in a

| URL normally follow this pattern:

|

|	example.com/class/method/id/

|

| In some instances, however, you may want to remap this relationship

| so that a different class/function is called than the one

| corresponding to the URL.

|

| Please see the user guide for complete details:

|

|	https://codeigniter.com/user_guide/general/routing.html

|

| -------------------------------------------------------------------------

| RESERVED ROUTES

| -------------------------------------------------------------------------

|

| There are three reserved routes:

|

|	$route['default_controller'] = 'welcome';

|

| This route indicates which controller class should be loaded if the

| URI contains no data. In the above example, the "welcome" class

| would be loaded.

|

|	$route['404_override'] = 'errors/page_missing';

|

| This route will tell the Router which controller/method to use if those

| provided in the URL cannot be matched to a valid route.

|

|	$route['translate_uri_dashes'] = FALSE;

|

| This is not exactly a route, but allows you to automatically route

| controller and method names that contain dashes. '-' isn't a valid

| class or method name character, so it requires translation.

| When you set this option to TRUE, it will replace ALL dashes in the

| controller and method URI segments.

|

| Examples:	my-controller/index	-> my_controller/index

|		my-controller/my-method	-> my_controller/my_method

*/

// $route['default_controller'] = 'Auth';



/* API */







// if(isset( $_SESSION['LEVEL'] ))

// { // define your routing here

// if ($_SESSION['LEVEL'] === 'Admin') {

$route['default_controller'] = 'Auth';

$route['data-log'] = 'Controll_Log';

$route['data-log-root'] = 'Controll_LogRoot';

/* SETTINGS */

$route['data-users-login'] = 'settings/Controll_users';

$route['data-export-import'] = 'settings/Controll_import';

$route['data-pengguna-aplikasi'] = 'settings/Controll_pengguna';

$route['data-setting-barang'] = 'settings/Controll_setting_barang';

$route['data-setting-akses-halaman'] = 'settings/Controll_aksesJabatan';

$route['data-setting-umum'] = 'settings/Controll_SettingTampilan';

$route['form-snmp-protocol'] = 'settings/Controll_snmpProtocol';

$route['data-setup-jabatan'] = 'settings/Controll_jabatan';

$route['data-status-barang'] = 'settings/Controll_statusBarang';

$route['data-reset'] = 'settings/Controll_Reset';

$route['data-backup-and-restore'] = 'settings/Controll_Backres';
$route['data-promo'] = 'settings/Controll_Promo';

/*GANGGGUAN*/
$route['Data-tambah-tiket'] = 'gangguan/Controll_tambahtiket';
$route['data-tiket-masuk'] = 'gangguan/Controll_tiketmasuk';
$route['data-tiket-proses'] = 'gangguan/Controll_tiketproses';
$route['data-riwayat-tiket-selesai'] = 'gangguan/Controll_riwayatTiketSelesai';
$route['data-riwayat-tiket-gagal'] = 'gangguan/Controll_riwayatTiketGagal';

/* RIWAYAT */

$route['data-riwayat-alat'] = 'riwayat/Controll_riwayatAlat';

$route['data-riwayat-pelanggan'] = 'riwayat/Controll_riwayatPelanggan';

$route['data-riwayat-transaksi'] = 'riwayat/Controll_riwayatTransaksi';

// $route['data-transaksi-pelanggan'] = 'transaksi/Controll_transaksi';

/* PELANGGAN */

$route['data-survei'] = 'pelanggan/Controll_survei';

$route['data-pelanggan'] = 'pelanggan/Controll_data_pelanggan';

$route['data-permintaan'] = 'pelanggan/Controll_permintaan';

$route['data-registrasi-pelanggan'] = 'pelanggan/Controll_registrasiPelanggan';

$route['data-antrian-survei'] = 'pelanggan/Controll_antrianSurvei';

$route['data-antrian-proses'] = 'pelanggan/Controll_antrianProses';

$route['data-list-gagal-pasang'] = 'pelanggan/Controll_listGagalPasang';

$route['data-list-putus-langganan'] = 'pelanggan/Controll_listPutusLangganan';

// $route['data-proses'] = 'pelanggan/Controll_proses';

/* MASTER */

$route['data-barang'] = 'master/Controll_barang';

$route['data-satuan'] 			= 'master/Controll_satuan';

$route['data-kategori-barang']  = 'master/Controll_kategori_barang';

$route['data-paket'] 			= 'master/Controll_Paket';

$route['data-wilayah'] 		= 'master/Controll_wilayah';

$route['data-jenis-paket'] 		= 'master/Controll_jenKaPaket';

/* TOOLS */

$route['data-ipkosong'] = 'tools/Controll_ipkosong';

$route['data-olt'] = 'tools/Controll_olt';

$route['data-aktivasi-pelanggan'] = 'tools/Controll_aktivasiPelanggan';

$route['data-router'] = 'tools/Controll_Routers';

/* logout / keluar aplikasi*/

$route['url-logout'] = 'Auth/logout';

/* Customer_app */

$route['Form-Pendaftaran-Pengguna-Baru'] = 'Customer_app/Controll_newUser_registration';



// } else {



$route['data-registrasi-pelanggan'] = 'pelanggan/Controll_registrasiPelanggan';



$route['data-antrian-survei'] = 'pelanggan/Controll_antrianSurvei';



$route['data-antrian-proses'] = 'pelanggan/Controll_antrianProses';



// }

// }


// KEUANGAN
$route['transaksi-pembayaran'] = 'transaksi/Controll_Pembayaran';

$route['data-mapping-odp'] = 'mapingOdp/Controll_Mapping';











/* API */

$route['api'] = 'master/Con_api';

$uri = $this->uri->segment(2);

$route['api/(:any)'] = function ($uri) {

	return 'master/Con_api/' . $uri;
};



// $route['404_override'] = 'Home/index';

$route['translate_uri_dashes'] = TRUE;





/*

| -------------------------------------------------------------------------

| Sample REST API Routes

| -------------------------------------------------------------------------

*/

$route['api/example/users/(:num)'] = 'api/example/users/id/$1'; // Example 4

$route['api/example/users/(:num)(\.)([a-zA-Z0-9_-]+)(.*)'] = 'api/example/users/id/$1/format/$3$4'; // Example 8




$route['bayar'] = 'transaksi/Controll_Pembayaran';
$route['koreksi'] = 'ControllKoreksiData';
$route['tesriwayat'] = 'transaksi/Controll_RiwayatBayar';
$route['ScanDuplicate'] = 'ScanDuplicate/ScanDuplicate';
