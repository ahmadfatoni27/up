<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
//adding config items.
$config['perusahaan'] = array(
  'serial'      => '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!@%&?|=*-',
  'companyName' => 'Pt. ',
);
?>
