<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Invoice extends CI_Controller {
  public function __construct() {
    parent::__construct();
  }
  function getDataInvoice() {
    $id = $this->input->get('id');
    // print_r($id);die();
    $res = $this->db->query("SELECT pw.IDPERMINTAAN, pw.IDPENGGUNA, p.NAMADEPAN as PELANGGAN, spw.KATEGORITINGKAT, spw.FOTORUMAH, spw.ESTIMASIKEBUTUHAN,
      REPLACE(p.NAMADEPAN, '-', ' ') as NAMA_LENGKAP, p.NAMABELAKANG, p.TLP, p.HP, p.ALMT, p.EMAIL, p.IDWILAYAH, p.KOTA, p.KEC, p.DESA, CONCAT(p.DESA , ' , ' , p.KEC, ' , ' , p.KOTA ) AS ALAMATLENGKAP, UPPER(pw.STATUSALAT) as STATUSALAT, UPPER(pw.JENISJARINGAN) AS JENISJARINGAN,
      p.JENISKELAMIN, p.KTP_SIM,p.HP,p.TLP,
      spw.LAT, spw.`LONG`, p.FOTOKTP, pw.`STATUS`, pk.SPEEDUP, pk.KODEPAKET, pk.NAMA_PAKET, pw.UBAHKONEKSI,pw.IDBIAYA,

      lp.TESTUP,lp.TESTDOWN, lp.`PINGGATEWAY`, lp.`PINGGOOGLE`, lp.`IPADDR`, lp.`MACADDR_ANTENA`,
      lp.`MACADDR_ROOTER`, lp.`SNROOTER_FIBER`, lp.`NOMOR_ODP`, lp.`NOMOR_PORT_ODP`,
      lp.`NOMOR_PORT_OLT`, lp.`SIGNAL_WIRELESS`, lp.`SIGNAL_KABEL`,
      lp.FOTOTOWER,lp.FOTOKABEL,lp.FOTOROOTER,lp.FOTOSPEED,lp.FOTOFORMULIR,lp.FOTOTTDFORMULIR, bt.BIAYAPASANG, bt.BIAYABULANAN, bt.BIAYALAINLAIN, bt.TOTALBIAYA,bt.TGLINSERT,

      fRupiah(bt.BIAYAPASANG) as BIAYAPASANGRP, fRupiah(bt.BIAYABULANAN) as BIAYABULANANRP, fRupiah(bt.BIAYALAINLAIN) as BIAYALAINLAINRP, fRupiah(bt.TOTALBIAYA) as TOTALBIAYARP

      FROM prosedure_permintaan_wifi AS pw
      JOIN pengguna AS p ON pw.IDPENGGUNA=p.IDPENGGUNA
      JOIN survey_pemasangan_wifi AS spw ON pw.IDPERMINTAAN=spw.IDPERMINTAAN AND spw.IDPENGGUNA=pw.IDPENGGUNA
      JOIN laporan_pemasangan_wifi AS lp ON pw.IDPERMINTAAN=lp.IDPERMINTAAN AND lp.IDPENGGUNA=pw.IDPENGGUNA
      JOIN paket as pk ON pw.IDPAKET=pk.KODEPAKET
      JOIN biaya_tagihan as bt on pw.IDPERMINTAAN=bt.IDPERMINTAAN and pw.IDPENGGUNA=bt.IDPELANGGAN and pw.IDBIAYA=bt.IDBIAYA
      WHERE md5(pw.IDPERMINTAAN)='".$id."'")->row_array();
      echo json_encode(array('result' => $res));
  }
}
