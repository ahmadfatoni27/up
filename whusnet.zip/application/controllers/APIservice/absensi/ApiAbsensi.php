<?php

require APPPATH . 'libraries/REST_Controller.php';

class ApiAbsensi extends REST_Controller {

  /**
  * Get All Data from this method.
  *
  * @return Response
  */
  public function __construct() {
    parent::__construct();
    $this->load->database('default');
    $db_absensi = $this->load->database('db_absensi');
  }

  /**
  * Get All Data from this method.
  *
  * @return Response
  */
  public function getDataIdcard_get() {
    $id = $this->get('IDABSENSI');
    $CABANG = substr($id,0,2);
    $IDPENGGUNA = substr($id,3,8);

    $sqlcabang = "SELECT c.NAMACABANG , c.URL_SERVICE FROM tb_cabang AS c WHERE c.IDCABANG = '".$CABANG."'";
    $query = $db_absensi->query($sqlcabang);
    $datacabang = $query->row_array();

    $sqlpengguna = "SELECT CONCAT(P.NAMADEPAN, P.NAMABELANG) AS NAMALENGKAP , p.HP , p.IDPENGGUNA FROM pengguna AS p WHERE p.IDPENGGUNA = '".$IDPENGGUNA."'";
    $query = $this->db->query($sqlpengguna);
    $datapengguna = $query->row_array();


    $rest = REST_Controller::HTTP_OK;
    $res = array(
      "DataPengguna" => $datapengguna,
      "DataCabang" => $datacabang,
      "status" => $rest,
    );
    $this->response($res, $rest);
  }

  public function getRiwayatAbsensi_get() {
    $id = $this->get('IDABSENSI');
    $IDPENGGUNA = substr($id,3,8);

    $sql = "SELECT ga.* FROM tb_goabsensi AS ga WHERE ga.IDABSENSI = '".$IDPENGGUNA."'";
    $query = $db_absensi->query($sql);
    $datariwayat = $query->result();
    $total = $query->num_rows();


    $rest = REST_Controller::HTTP_OK;
    $res = array(
      "Data" => $datapengguna,
      "RecordsTotal" => $total,
      "status" => $rest,
    );
    $this->response($res, $rest);
  }


  public function getDataPengguna_get() {
    $id = $this->get('IDABSENSI');
    $IDPENGGUNA = substr($id,3,8);
    if ($id <> NULL){


      $sql = "SELECT p.* FROM pengguna AS p WHERE p.IDPENGGUNA = '".$IDPENGGUNA."'";
      $query = $this->db->query($sql);
      $datariwayat = $query->result();
      $total = $query->num_rows();

      $res = array(
        // if status = 200  ||  status = 404 ( not found )
        "status"       => $status,
        "Saldo"        => $SisaSaldo,
      );
    } else {
      $res = array(
        "status"  => '404',
        "message" => 'id pengguan not found',
      );
    }
    echo json_encode($res);
  }


  public function updateDataPerusahaan_post() {
    $data = array(
      'IDPENGGUNA'  => $this->input->post('IDPENGGUNA'),
      'NAMALENGKAP' => $this->input->post('NAMALENGKAP'),
      'EMAIL'       => $this->input->post('EMAIL'),
      'PASSWORD'    => $this->input->post('PASSWORD'),
      'ALAMAT'      => $this->input->post('ALAMAT'),
    );
		$this->db->where('IDPENGGUNA',$data['IDPENGGUNA']);
		$query = $this->db->update('pengguna',$data);
    $status = REST_Controller::HTTP_OK; // OK (200) being the HTTP response code
    $res = array(
      "status"       => $status,
      "Data"         => $data,
    );

    echo json_encode($res);
  }


  // public function index_get()
  // {
  //   // if(!empty($id)){
  //     // $data = $this->db->get_where("pengguna", ['IDPENGGUNA' => $id])->row_array();
  //   // }else{
  //     $data = $this->db->get("pengguna")->result();
  //     print_r($data);die();
  //   // }
  //
  //   $this->response($data, REST_Controller::HTTP_OK);
  // }

  /**
  * Get All Data from this method.
  *
  * @return Response
  */
  // public function index_post()
  // {
  //   $input = $this->input->post();
  //   $this->db->insert('items',$input);
  //
  //   $this->response(['Item created successfully.'], REST_Controller::HTTP_OK);
  // }

  /**
  * Get All Data from this method.
  *
  * @return Response
  */
  // public function index_put($id)
  // {
  //   $input = $this->put();
  //   $this->db->update('items', $input, array('id'=>$id));
  //
  //   $this->response(['Item updated successfully.'], REST_Controller::HTTP_OK);
  // }

  /**
  * Get All Data from this method.
  *
  * @return Response
  */
  // public function index_delete($id)
  // {
  //   $this->db->delete('items', array('id'=>$id));
  //
  //   $this->response(['Item deleted successfully.'], REST_Controller::HTTP_OK);
  // }

}
