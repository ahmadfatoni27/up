<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->helper(array('configsession')); cek_login();
		$this->load->model(
          array(
				'DashboardModel' => 'model',
				'CheckModel' => 'check',
			)
        );
	}
	public function index() {
		$data['page']  = "home";
		$data['title'] = "Dashboard Administrator ";
		// print session = $session['sessionName']; sessionname in configsession_helper file.
		$data['session']= session();
		$data['EMAIL']= $this->session->userdata('EMAIL');

		$this->template->load('_template','dashboard/_home', $data);
	}
	public function getDataUriPage(){
		$data = array(
			"page" 		=> $_POST['id'],
			"jabatan" 	=> $this->session->userdata('JABATANID'),
			"status"	=> 'YES',
		);
		$res = $this->check->getSelectIdPage($data);
		$res = array("result" => $res ); echo json_encode($res);
	}
	public function getCounts(){

		// $month = date('m-Y'); // 21-2020
		// jumlah pelanggan kita
		// Jumlah data sudah Active = Pelanggan
		$ActiveAll 	   = $this->model->getCountsData($status = 'ACTIVE', $month = '', $stspasang='');
		$ActiveBulanini= $this->model->getCountsData($status = 'ACTIVE', $month = date('m-Y'), $stspasang='');

		// Belum Survei || PENGAJUAN
		$BelumSurvei   = $this->model->getCountsData($status = 'PENGAJUAN', $month = '', $stspasang='');

		// Belum Proses
		$BelumProses   = $this->model->getCountsData($status = 'DISURVEI', $month = '', $stspasang='');

		// Belum Verifikasi
		$BelumVerifikasi= $this->model->getCountsData($status = 'DIPROSES', $month = '', $stspasang = 'Terpasang');

		// Gagal Pemasangan.
		$gagalAll 		= $this->model->getCountsData($status = 'GAGAL', $month = '', $stspasang='');
		$gagalBulanini 	= $this->model->getCountsData($status = 'GAGAL', $month = date('m-Y'), $stspasang='');

		// Putus Pemasangan.
		$putusAll 		= $this->model->getCountsData($status = 'PUTUS', $month = '', $stspasang='');
		$putusBulanini 	= $this->model->getCountsData($status = 'PUTUS', $month = date('m-Y'), $stspasang='');
	 
		$res = array(
			'ActiveAll' 		=> $ActiveAll,
			'ActiveBulanini' 	=> $ActiveBulanini,
			'BelumSurvei' 		=> $BelumSurvei,
			'BelumProses' 		=> $BelumProses,
			'BelumVerifikasi' 	=> $BelumVerifikasi,
			'gagalAll' 			=> $gagalAll,
			'gagalBulanini' 	=> $gagalBulanini,
			'putusAll' 			=> $putusAll,
			'putusBulanini' 	=> $putusBulanini
		);
		echo json_encode($res);
	}

	function datachartbatang(){
		$res = $this->model->getdatachartbatang();
		echo json_encode($res);
	}

	function databiayapemasangan(){
		$res = $this->model->getDataBiayaPasang();
		echo json_encode($res);
	} // PERTUMBUHAN OMSET

	//function dataPemasanganBarudanPutus(){
	//	$res = $this->model->getDataChartLine();
	//	echo json_encode($res);
	//} // PEMASANGAN BARU dan putus
  	
  	function dataPemasanganBarudanPutus(){
		$baru  = $this->model->getDataChartLine_baru();
		$putus = $this->model->getDataChartLine_putus();
		$res = array(
				"Baru"  => $baru, 
				"Putus" => $putus
		);
		echo json_encode($res, true);
	} // PEMASANGAN BARU dan putus

}
/* End of file Home.php */
/* Location: ./application/controllers/Home.php */
