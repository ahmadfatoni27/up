<?php

/**
 * @Author: Arif Efendi - Kazuya Media Indonesia
 * @Date:   2021-08-10 20:04:44
 * @Last Modified by:   kazuya
 * @Last Modified time: 2021-08-10 20:47:15
 */
defined('BASEPATH') or exit('No direct script access allowed');
class Admin_manager extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('configsession'));
        cek_login();
        $this->load->model(
            array(
                'DashboardModel' => 'model',
            )
        );
    }
    public function index()
    {
        $data['page']  = "home";
        $data['title'] = "Dashboard Administrator ";
        // print session = $session['sessionName']; sessionname in configsession_helper file.
        $data['session'] = session();
        $data['EMAIL'] = $this->session->userdata('EMAIL');
        $this->template->load('_template', 'dashboard/_homeManager', $data);
    }
}
