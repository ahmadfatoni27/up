<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Auth extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model(array('M_auth'));
		$this->load->helper('text');
	}
	public function index()
	{
		$data['title']  = "Halaman login Menu Dinamis dengan user access";
		// $data['admin']  = $this->M_auth->get_admin()->row_array();
		// $data['spv'] 	= $this->M_auth->get_spv()->row_array();
		$this->load->view('_login',$data);
	}
	public function validate()
	{
		$username 	=  $this->input->post('username');
		// $password 	=  sha1($this->input->post('password'));
		$password 	=  sha1($this->input->post('password'));
		$valid 	  	= $this->M_auth->get_valid($username, $password);

		if ($valid->num_rows() > 0 ) {
			# if valid
			$get_data = $this->M_auth->get_id($username, $password);
			$val =  $get_data->row();

		// print_r($val); die();
			// foreach($get_id as $val)
			// {
			$data = array(
				'IDUSERS' 		=> $val->IDUSERS,
				'IDPENGGUNA' 	=> $val->IDPENGGUNA,
				'JABATANID' 	=> $val->JABATANID,
				'JABATAN'		=> $val->JABATAN,
				'CABANG'		=> $val->CABANG,
				'NAMADEPAN' 	=> $val->NAMADEPAN,
				'NAMABELAKANG' 	=> $val->NAMABELAKANG,
				'IDLEVEL' 		=> $val->IDLEVEL,
				'LEVEL' 		=> $val->LEVEL,
				'HP'  			=> $val->HP,
				'TLP'  			=> $val->TLP,
				'KOTA'  		=> $val->KOTA,
				'KEC'  			=> $val->KEC,
				'DESA'  		=> $val->DESA,
				'ALMT'  		=> $val->ALMT,
				'EMAIL'  		=> $val->EMAIL,
				'STATUSAKUN'  	=> $val->STATUSAKUN,
				'NAMAPERUSAHAAN'=> $val->NAMAPERUSAHAAN,
				'NPWP'  		=> $val->NPWP,
				'KTP_SIM'  		=> $val->KTP_SIM,
				'FOTO'  		=> $val->FOTO,
				'is_logged_in' 	=> true
			);
				$this->session->set_userdata($data); //  Create Session.

				$this->session->set_flashdata("welcome", "<br/> to the 'Wushnet' Management System!");
    			// redirect('Admin');
    			custom_redirect();
			// }
			} else {
			# if not valid
				$this->session->set_flashdata('msg1', 'Username or Password Incorrect!');
				redirect('Auth');
			}
		}
		public function logout(){
			$checkSession = array(
				'USERNAME',
				'PASSWORD',
				'IDUSERS',
				'IDLEVEL',
				'LEVEL',
				'HP',
				'TLP',
				'EMAIL',
				'STATUSAKUN',
				'NAMAPERUSAHAAN',
				'host',
				'nama',
				'username',
				'is_logged_in');
			$this->session->unset_userdata($checkSession);
			$this->session->set_flashdata('msg', 'You have been logged out!');
			redirect('Auth');
		}

		public function hapusSessionRouter(){
			// $cek = $this->session->userdata('host');
			// print_r($cek);die();
			$checkSession = array(
				'host',
				'nama',
				'username',
				'password',
			// 'status_router',
			);
			$this->session->unset_userdata($checkSession);
		// $this->session->set_flashdata('msg', 'You have been logged out!');
		// redirect('Auth');
		}



	} ?>
