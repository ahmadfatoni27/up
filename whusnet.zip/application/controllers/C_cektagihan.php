<?php defined('BASEPATH') OR exit('No direct script access allowed');
class C_cektagihan extends CI_Controller {
  public function __construct() {
    parent::__construct();
    $this->load->helper(array('my'));
    // cek_login();
  }
  function index($str='30') {
    // $data['session']= session();
    $tes = array(
      'tes1' => $str.'M/'.$str.'M',
      'tes2' => 'tes data',
    );
    $res = json_encode($tes);
    echo delBackSlash($res); die();
    echo "tes data / Uji coba <br/>".$data['session'];
  }









  function getMacLinux() {
    exec('netstat -ie', $result);
    if(is_array($result)) {
      $iface = array();
      foreach($result as $key => $line) {
        echo "$tmp<br>";
        if($key > 0) {
          $tmp = str_replace(" ", "", substr($line, 0, 10));
          if($tmp <> "") {
            $macpos = strpos($line, "HWaddr");
            if($macpos !== false) {
              $iface[] = array('iface' => $tmp, 'mac' => strtolower(substr($line, $macpos+7, 17)));
            }
          }
        }
      }
      return $iface[0]['mac'];
    } else {
      return "notfound";
    }
  }





  function GetMAC(){

    $ipaddress = $_SERVER['REMOTE_ADDR'];
    $cmd = "/usr/sbin/arp -a " . $ipaddress;
    $status = 0;
    $return = [];
    exec($cmd, $return, $status);
    var_dump($status, $return);
    die;

    // ob_start();
    //
    // system('getmac');
    //
    // $Content = ob_get_contents();
    //
    // ob_clean();
    //
    // $res = substr($Content, strpos($Content,'\\')-20, 17);
    //
    // echo $res;
    //
    // die();
  }












  function error() {
    $this->load->view('errors/_dataErrors404');
  }

  function keyActive(){
    $this->config->load('confcompany', TRUE);
    $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
    $curl = curl_init();
    $res = "".$urlgateway."/custom/Devices/getKeyDevice/key";
    curl_setopt_array($curl, array(
      CURLOPT_URL => $res,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    ));
    $response = curl_exec($curl); curl_close($curl);
    return $response = json_decode($response);
  }
  /*  CUSTOM = urlgateway*/
  function urlgateway(){
    $this->config->load('confcompany', TRUE);
    $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
    $curl = curl_init();
    $url = "".$urlgateway."/custom/Devices/getUrl_getway";
    curl_setopt_array($curl, array(
      CURLOPT_URL => $url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    ));
    $response = curl_exec($curl); curl_close($curl);
    return $response = json_decode($response);
  }





  function GetDataTagihan() {
    // get uri segment
    $uriSegments = explode("/", parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
    $no = $uriSegments['3'];
     print_r($no);die();

    // get data tagihan tagihan by no hp
    $sqldata = "SELECT bt.IDBIAYA , tg.NOINDEXTAGIHAN , bt.BIAYAPASANG , bt.BIAYABULANAN , bt.BIAYALAINLAIN , bt.TOTALBIAYA , tg.BULANTAGIHAN, tg.BAYAR , tg.FLAG
    FROM apikeuangan_buktitransaksitagihan as tg
    JOIN biaya_tagihan as bt on bt.IDPERMINTAAN=tg.IDPERMINTAAN
    JOIN pengguna as p on p.IDPENGGUNA=bt.IDPELANGGAN
    WHERE p.HP = '$no'
    UNION
    SELECT bt.IDBIAYA , tg.NOINDEXTAGIHAN , bt.BIAYAPASANG , bt.BIAYABULANAN , bt.BIAYALAINLAIN , bt.TOTALBIAYA , tg.BULANTAGIHAN, tg.BAYAR , tg.FLAG
    FROM apikeuangan_buktitransaksiterkumpul as btk
    JOIN apikeuangan_buktitransaksitagihan as tg on btk.IDTRANSAKSI=tg.IDTRANSAKSI
    JOIN biaya_tagihan as bt on bt.IDPERMINTAAN=tg.IDPERMINTAAN
    JOIN pengguna as p on p.IDPENGGUNA=bt.IDPELANGGAN
    WHERE p.HP = '$no'";
    $get = $this->db->query($sqldata);
    $data = $get->result_array();



    //print_r($data);die();

    if ($data != "") {
      // tampilkan data informasi tagihan.$checkKeyactive = $this->keyActive();
      foreach ($data as $d) {
        //print_r($d['IDBIAYA']);die();
        //$id = $d['IDBIAYA'];
        $b = $d['BAYAR'];
        //echo "$id-$b</br>";
		$checkKeyactive = $this->keyActive();
        if ($checkKeyactive==='no connect') {
          $res = json_encode(array('status' => FALSE, 'res' => $checkKeyactive));
          echo $res;
        }else{
          $this->config->load('confcompany', TRUE);
          $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration, custom configuration in config/confcompany.php
          /* SENDING MESSAGE WA */
          $curl = curl_init();
          // AMBIL urlgatewaywa, api Whatsapp from setup confcompany.
          $CURLOPT_URL = ''.$urlgateway.'/index.php/api/sendMessageText';
          // BUAT CURLOPT_POSTFIELDS /  DATA YANG AKAN DI POST KE API WHATSAPP.
          $data = '{
            "instance_key":  "'.$checkKeyactive.'" ,
            "jid": "'.$no.'",
            "message": "'.$b.'"
          }';
          curl_setopt_array($curl, array(
            CURLOPT_URL => $CURLOPT_URL,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $data,
          ));
          curl_exec($curl);
          // $res = curl_exec($curl);
          curl_close($curl);
          /* END SENDING MESSAGE WA */
        }
        // kirim lagi pesan lewat wa ke nomor pelanggan by uri segment
      }
    } else {
      // tidak ada tagihan
      $checkKeyactive = $this->keyActive();
      if ($checkKeyactive==='no connect') {
        $res = json_encode(array('status' => FALSE, 'res' => $checkKeyactive));
        echo $res;
      }else{
        $this->config->load('confcompany', TRUE);
        $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration, custom configuration in config/confcompany.php
        /* SENDING MESSAGE WA */
        $curl = curl_init();
        // AMBIL urlgatewaywa, api Whatsapp from setup confcompany.
        $CURLOPT_URL = ''.$urlgateway.'/index.php/api/sendMessageText';
        // BUAT CURLOPT_POSTFIELDS /  DATA YANG AKAN DI POST KE API WHATSAPP.
        $data = '{
          "instance_key":  "'.$checkKeyactive.'" ,
          "jid": "'.$no.'",
          "message": "Tidak Ada Tagihan."
        }';
        curl_setopt_array($curl, array(
          CURLOPT_URL => $CURLOPT_URL,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $data,
        ));
        curl_exec($curl);
        // $res = curl_exec($curl);
        curl_close($curl);
        /* END SENDING MESSAGE WA */
      }
    }


    header('Location: ' . $_SERVER['HTTP_REFERER']);
  }









}
/* End of file Home.php */
/* Location: ./application/controllers/Home.php */
