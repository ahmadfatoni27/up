<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class ControllKoreksiData extends CI_Controller
{
  function __construct(){
    parent::__construct();
    // $this->load->helper(array('login','configsession','my'));cek_login();
    $this->load->helper(array('configsession','my'));
    $this->load->model('M_KoreksiData','model');
  }
  function index()
  {
    $data['title'] = "Data Paket";
    $data['session']= session();
    $this->template->load('_template', '@_KoreksiData',$data);
  }
  function getData1(){
    $data = array( 'start' => $_POST['start'],
    'length' => $_POST['length'],
    'filtervalue' => $_POST['filtervalue'],
    'filtertext' => $_POST['filtertext']);
    $res = $this->model->getDataAll1($data); echo json_encode($res);
  }
  function getData2(){
    $data = array( 'start' => $_POST['start'],
    'length' => $_POST['length'],
    'filtervalue' => $_POST['filtervalue'],
    'filtertext' => $_POST['filtertext']);
    $res = $this->model->getDataAll2($data); echo json_encode($res);
  }
  function delete(){
    $data = json_decode(file_get_contents('php://input'), true);
    $data = array( 'IDBIAYA' => $data['id']);
    $res = $this->model->delete($data);
    echo $res;
  }
}
?>
