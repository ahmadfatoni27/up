<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_Log extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->helper(array('login','configsession','my'));cek_login();
    $this->load->model('M__Log','model');
  }
  function index()
  {
    $data['title'] = "Data Log";
    $data['session']= session();
    $this->template->load('_template', '@_dataLog',$data);
  }
  function getData(){
    $data = array( 'start' => $_POST['start'],
    'length' => $_POST['length'],
    'filtervalue' => $_POST['filtervalue'],
    'filtertext' => $_POST['filtertext']);
    $res = $this->model->getDataAll($data); echo json_encode($res);
  }
}?>
