<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_LogRoot extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->helper(array('login','configsession','my'));cek_login();
    $this->load->model('M__LogRoot','model');
  }
  function index()
  {
    $data['title'] = "Data Log";
    $data['session']= session();
    $this->template->load('_template', '@_dataLogRoot',$data);
  }
  function getData(){
    $data = array( 'start' => $_POST['start'],
    'length' => $_POST['length'],
    'filtervalue' => $_POST['filtervalue'],
    'filtertext' => $_POST['filtertext']);
    $res = $this->model->getDataAll($data); echo json_encode($res);
  }
  function getDataSelect(){
    $res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
  }
  function save(){
    $data = json_decode(file_get_contents('php://input'), true);
    $data = array(
      'id' => "LOG".uniqid(),
      'versi' =>  $data['versi'],
      'jenis_log' =>  $data['jenis_log'],
      'log' =>  $data['log'],
    );
    // print_r($data);die();
    // insert to table kategori
    $check = $this->model->insert($data);
    if ($check == true) {
      $res=  "OK";
    }else {
      $res= "Data Sama";
    }
    echo json_encode($res);
  }
  function update(){
    $data = json_decode(file_get_contents('php://input'), true);
    $data = array(
      'id' =>  $data['id'],
      'versi' =>  $data['versi'],
      'jenis_log' =>  $data['jenis_log'],
      'log' =>  $data['log'],
    );
    // print_r(json_encode($data));die();
    $res = $this->model->update($data); echo $res;
  }
  function checkId(){
    $data = json_decode(file_get_contents('php://input'), true);
    // print_r($data['id']);die();
    $check = $this->model->checkId($data['id']);
    $res = array( 'res' => $check);echo json_encode($res);
  }
}
?>
