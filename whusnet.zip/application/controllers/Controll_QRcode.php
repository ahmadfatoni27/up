<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_QRcode extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('configsession','my'));
		$this->load->model(
			array(
				'pelanggan/M__antrianProses'=>'model',
				'QRcode/QRcode_Model'=>'QRcode',
				'CheckModel'=>'CheckData',
			)
		);
	}
	// function index(){
	// 	$data['title'] = "Data Yang telah di Survei";
	// 	$data['session']= session();
	// 	$this->template->load('_templateCustomersApp', 'QR_code/QR_code', $data);
	// }
	// QRCODE FUNCTION
	function QR_code() {
		$id = $this->uri->segment(3);
		$data['row'] = $this->QRcode->getIDQRcode($id);
		$data['title'] = 'Test QR Code';
		$data['session'] = session();
		$this->template->load('customersApp/_templateCustomersApp','QR_code/QR_code', $data);
	}
	function getDataSelectqr() {
		$id = $this->uri->segment(3);
		$res = $this->QRcode->getSelectIdQR($id);
		echo json_encode($res);
	}
	// END QRCODE FUNCTION




}
