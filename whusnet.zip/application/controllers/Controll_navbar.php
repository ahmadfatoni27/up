<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_navbar extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->helper(array('login','configsession','my'));cek_login();
    $this->load->model('NavbarModel','model');
  }

  // function of Parents menu.
  function getDataParents(){
    $session = session(); $idjabatan = $session['JABATANID'];
    $parents = $this->model->getParents($idjabatan);
    $res = json_encode($parents); echo $res;
  }

  // function of childs menu.
  function getDataChilds(){
    $session    = session();
    $idjabatan  = $session['JABATANID'];
    $parents    = $this->model->getParents($idjabatan);
    // foreach childs menu
    // foreach ($parents as $p) {
    $child = "SELECT m1.menuid, m1.menuparentid, m1.menuname, m1.menuid, (select m2.menuname from tb_menu m2 where m2.menuid=m1.menuparentid) AS menuparentname, tmj.`status`, tj.JABATAN, m1.menulink, m1.menuicon, m1.menualias
    FROM tb_menu AS m1 LEFT JOIN tb_menu AS m2 ON m1.menuid = m2.menuparentid INNER JOIN tb_menujabatan as tmj on tmj.menuid = m1.menuid INNER JOIN jabatan as tj on tj.ID = tmj.JABATANID
    WHERE tmj.`status`= 'YES' AND m1.menuparentid=m1.menuparentid AND tj.ID = '$idjabatan' AND m1.menuparentid='".$_POST['id']."' GROUP BY m1.menuid ORDER BY m1.sort ASC";
    $childs = $this->db->query($child)->result();
    $childs = array('res'=> $childs);

    $res = json_encode($childs); echo $res;
    // }
    // echo $res;
  }

  function getDataMenu() {
    $session    = session();
    $idjabatan  = $session['JABATANID'];
    $parents    = $this->model->getParents($idjabatan);

    $sql = "SELECT mn.menuid, mn.menuname, mn.menuparentid, tmj.`status`, j.JABATAN,
    (select mn3.menuname from tb_menu as mn3 where mn3.menuid=mn.menuparentid) as nameparent
    FROM tb_menu as mn, tb_menujabatan AS tmj, jabatan as j
    WHERE tmj.`status`= 'YES' and tmj.JABATANID=j.ID and tmj.menuid=mn.menuid AND tmj.JABATANID='$idjabatan'";

    $childs = $this->db->query($sql)->result();
    // $childs = array('res'=> $childs);
    $res = json_encode($childs); echo $res;
  }

  function changeTheme()
  {
    $change = $this->uri->segment(3);
    $data   = array( 'theme' => $change );
    $this->session->set_userdata($data);

    redirect(base_url('Admin'),'refresh');
  }


}
