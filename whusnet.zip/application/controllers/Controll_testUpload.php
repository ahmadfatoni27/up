<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * @Author: Arif Efendi - Kazuya Media Indonesia
 * @Date:   2021-03-26 10:12:21
 * @Last Modified by:   kazuya
 * @Last Modified time: 2021-03-26 11:25:12
 */
class Controll_testUpload extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->model(array( 
			'ModelTestUpload' => 'model',
		));
	}
	function index(){
		$data['title'] = "Data test upload";
		// print session = $session['sessionName']; sessionname in configsession_helper file.
		$data['session']= session();
		$this->template->load('_template', 'tesUpload', $data);
	}
	function save(){

		$checkPengguna = $this->model->checkBynama($_POST['NAMA_LENGKAP']);

		if( $checkPengguna == "OK" ){

			// configurasi Upload
			$config['upload_path'] = 'upload/fotoktp/';
			$config['allowed_types'] = 'jpg|jpeg|png';
			// $config['max_size'] = 1024 * 8;
			$config['encrypt_name'] = TRUE;
			$this->load->library('upload', $config);
			$file_element_name = 'userfile';

			// AND data insert to table testUpload
			$data = array (

				'IDPENGGUNA' 	=> generateKodeForm('TS','tambah'),
				'NAMADEPAN' 	=> seo_title($_POST['NAMA_LENGKAP']),
				'JENISKELAMIN' 	=> $_POST['JENISKELAMIN'],
				'KTP_SIM' 		=> $_POST['KTP_SIM'],
				'EMAIL' 		=> $_POST['EMAIL'],
				'HP' 			=> $_POST['HP'],
				'NPWP' 			=> $_POST['NPWP'],
				'ALMT' 			=> $_POST['ALMT'],
				// "FOTOKTP" 		=> 

			);

			// Upload FOTOKTP
			if ($this->upload->do_upload($file_element_name)) {
				$uploadData = $this->upload->data();
				$data['FOTOKTP'] = $uploadData['file_name'];
			}

			// echo json_encode(array('result'=> $data)); die();

			$this->model->insert($data);
		}
		$res = array("result" => $checkPengguna);
		echo json_encode($res);
	}

	function checkBypengguna(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkBynama($data['id']);
		$res = array( 'res' => $check);
		echo json_encode($res);
	}

}