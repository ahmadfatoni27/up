<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Iserror extends CI_Controller {

	public function index()
	{
		$this->load->view('errors/_dataErrors404');
	}

}
/* End of file Is_error.php */
/* Location: ./application/controllers/Is_error.php */