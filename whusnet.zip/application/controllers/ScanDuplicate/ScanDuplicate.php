<?php defined('BASEPATH') or exit('No direct script access allowed');
class ScanDuplicate extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }
    function index()
    {
        // 1
        // echo $this->ScanDuplicate();
        // 2
        // echo $this->ScanDataPengguna();
        // 3
        // echo $this->GeneretDataPenggunaNotFound("survey_pemasangan_wifi", "survey_pemasangan_wifi_IDPENGGUNA_NOT_FOUND.txt");
        // 4
        echo $this->GeneretDataPenggunaNotFoundBylaporan_pemasangan_wifi("pengguna", "pengguna_IDRIWAYAT_NOT_FOUND_FROM_laporan_pemasangan_wifi.txt");
    }

    function CekDataPengguna($paramreq)
    {
        $sql = "SELECT p.IDPENGGUNA FROM prosedure_permintaan_wifi AS p WHERE p.IDPERMINTAAN = '" . $paramreq . "'";
        $query = $this->db->query($sql);
        $rows = $query->num_rows();
        $res = $query->row_array();
        if ($rows > 0) {
            return $res;
        } else {
            return "404";
        }
    }

    function CekDataDesa($param)
    {
        $sql = "SELECT w.IDWILAYAH ,w.KOTA, w.KEC, w.DESA FROM tb_alamat  AS w WHERE w.DESA = '" . $param . "'";
        $query = $this->db->query($sql);
        $rows = $query->num_rows();
        $res = $query->row_array();
        if ($rows > 0) {
            return $res;
        } else {
            return "404";
        }
    }

    function GetDataPenggunaForUpdate()
    {
        $data = $this->GetDataPenggunaForUpdate();
        foreach ($data as $key) {
            $alamat = $this->GetDataAlamatForUpdate($key->IDWILAYAH);
            $id = $key->IDPENGGUNA;
            $dataupdate = [
                "KOTA" => $alamat['KOTA'],
                "KEC" => $alamat['KEC'],
                "DESA" => $alamat['DESA']
            ];
            $res = $this->UpdateAlamatPengguna($id, $dataupdate);
            echo $res . "</br>";
        }
        $result = $this->db->query("SELECT p.IDPENGGUNA, p.IDWILAYAH, p.KOTA, p.KEC, p.DESA, p.inserted_at FROM pengguna AS p order by p.NAMADEPAN");
        return $result->result();
    }
    function GetDataAlamatForUpdate($id)
    {
        // foreach ($datadesa as $data) {
        //     $param = strtoupper($data['DESA']);
        //     $cekdesa = $this->CekDataDesa($param);
        //     $paramreq = $data['IDPERMINTAAN'];
        //     $cekpengguna = $this->CekDataPengguna($paramreq);
        //     if ($cekdesa == "404") {
        //         echo $param + " not found </br>";
        //     } else {
        //         $idwilayah = $cekdesa['IDWILAYAH'];
        //         $kota = $cekdesa['KOTA'];
        //         $kec = $cekdesa['KEC'];
        //         $desa = $cekdesa['DESA'];
        //         $idpengguna = $cekpengguna['IDPENGGUNA'];
        //         $dataupdate = [
        //             "IDWILAYAH" => $idwilayah,
        //             "KOTA" => $kota,
        //             "KEC" => $kec,
        //             "DESA" => $desa
        //         ];
        //         // echo "[</br>IDPENGGUNA => $idpengguna ,</br>IDWILAYAH => $idwilayah ,</br>KOTA => $kota ,</br>KEC => $kec ,</br>DESA => $desa </br>],</br>";
        //         $res = $this->UpdateAlamatPengguna($idpengguna, $dataupdate);
        //         echo "$res </br>";
        //     }
        // }
        $result = $this->db->query("SELECT a.KOTA, a.KEC, a.DESA FROM tb_alamat AS a where a.IDWILAYAH = '" . $id . "'");
        return $result->row_array();
    }
    function UpdateAlamatPengguna($id, $dataupdate)
    {
        $this->db->where('IDPENGGUNA', $id);
        $query = $this->db->update("pengguna", $dataupdate);
        return $query;
    }

    function CekDataPenggunaByName($name)
    {
        // $handle = fopen("ScanDataPenggunaForDelete.txt", "w+");
        // foreach ($array as $key) {
        //     $cek = $this->CekDataPenggunaByName($key['NAMADEPAN']);
        //     if ($cek == "DeleteData") {
        //         $return = "Delete Data" . $key['IDPENGGUNA'] . "\n";
        //     } else {
        //         $return = "Save Data" . $key['IDPENGGUNA'] . "\n";
        //     }
        //     fwrite($handle, $return);
        // }
        // fclose($handle);
        // echo "Successfully ScanDataPengguna";
        $sql = "SELECT * FROM pengguna as p WHERE p.NAMADEPAN = '" . $name . "'";
        $query = $this->db->query($sql);
        $row = $query->num_rows();
        if ($row > 0) {
            return "DeleteData";
        } else {
            return "Skip";
        }
    }

    // function no 2
    function ScanDataPengguna()
    {
        $result = $this->db->query("SELECT p.IDPENGGUNA, p.NAMADEPAN, p.HP, p.IDWILAYAH, p.KOTA, p.KEC, p.DESA, p.inserted_at FROM pengguna AS p order by p.NAMADEPAN");
        $dataLopp = $result->result();
        $handle = fopen("ScanDataPengguna.txt", "w+");
        foreach ($dataLopp as $key) {
            $cek = $this->CekDataPenggunaJoin($key->IDPENGGUNA);
            if ($cek === "proses") {
                $return =
                    "[" .
                    "IDPENGGUNA => " . "'" . $key->IDPENGGUNA . "'" . "\n" .
                    "NAMADEPAN => " . "'" . $key->NAMADEPAN . "'" . "\n" .
                    "]," . "\n";
                // "HP : " . $key->HP . "\n" .
                // "IDWILAYAH : " . $key->IDWILAYAH . "\n" .
                // "KOTA : " . $key->KOTA . "\n" .
                // "KEC : " . $key->KEC . "\n" .
                // "DESA : " . $key->DESA . "\n" .
                // "inserted_at : " . $key->inserted_at . "\n\n";

                fwrite($handle, $return);
            }
        }
        fclose($handle);
        return "Scan Successfully";
    }
    function CekDataPenggunaJoin($id)
    {
        $sql = "SELECT p.IDPENGGUNA 
        from pengguna as p 
        join prosedure_permintaan_wifi as pw on p.IDPENGGUNA = pw.IDPENGGUNA
        WHERE p.IDPENGGUNA=" . "'" . $id . "'";
        $query = $this->db->query($sql);
        $row = $query->num_rows();
        if ($row > 0) {
            return "skip";
        } else {
            return "proses";
        }
    }

    // function no 1
    function ScanDuplicate()
    {
        $result = $this->db->query("SELECT pw.IDPERMINTAAN, pw.IDPENGGUNA, p.NAMADEPAN as PELANGGAN,
        p.HP, pw.IDPAKET, pw.IDBIAYA, p.IDWILAYAH,pw.STATUS
        FROM prosedure_permintaan_wifi AS pw
        JOIN pengguna AS p ON pw.IDPENGGUNA=p.IDPENGGUNA
        JOIN laporan_pemasangan_wifi AS lp ON lp.IDPENGGUNA=pw.IDPENGGUNA order by p.NAMADEPAN");
        $dataLopp = $result->result();

        $handle = fopen("ScanData.txt", "w+");
        foreach ($dataLopp as $key) {
            $IDPERMINTAAN = $key->IDPERMINTAAN;
            $IDPENGGUNA = $key->IDPENGGUNA;
            $PELANGGAN = $key->PELANGGAN;
            $HP = $key->HP;
            $IDPAKET = $key->IDPAKET;
            $IDBIAYA = $key->IDBIAYA;
            $IDWILAYAH = $key->IDWILAYAH;
            $STATUS = $key->STATUS;


            $cek_IDPAKET = $this->CekRelation($IDPAKET, 'KODEPAKET', 'paket');
            if ($cek_IDPAKET == "OK") {
                $SETIDPAKET = $IDPAKET;
            } else {
                $SETIDPAKET = $cek_IDPAKET;
            }
            $cek_IDBIAYA = $this->CekRelation($IDBIAYA, 'IDBIAYA', 'biaya_tagihan');
            if ($cek_IDBIAYA == "OK") {
                $SETIDBIAYA = $IDBIAYA;
            } else {
                $SETIDBIAYA = $cek_IDPAKET;
            }
            $cek_IDWILAYAH = $this->CekRelation($IDWILAYAH, 'IDWILAYAH', 'tb_alamat');
            if ($cek_IDWILAYAH == "OK") {
                $SETIDWILAYAH = $IDWILAYAH;
            } else {
                $SETIDWILAYAH = $cek_IDPAKET;
            }

            $return = "IDPERMINTAAN : " . $IDPERMINTAAN . "\n" .
                "IDPENGGUNA : " . $IDPENGGUNA . "\n" .
                "PELANGGAN : " . $PELANGGAN . "\n" .
                "HP : " . $HP . "\n" .
                "IDPAKET : " . $SETIDPAKET . "\n" .
                "IDBIAYA : " . $SETIDBIAYA . "\n" .
                "IDWILAYAH : " . $SETIDWILAYAH . "\n" .
                "STATUS : " . $STATUS . "\n\n";
            fwrite($handle, $return);
        }
        fclose($handle);
        return "Successfully backed up";
    }

    function CekRelation($id, $fild_id, $table)
    {
        $sql = "Select * from " . $table . " where " . $fild_id . " = " . "'" . $id . "'";
        $query = $this->db->query($sql);
        $row = $query->num_rows();
        if ($row > 0) {
            return "OK";
        } else {
            return $id . " ( Not Found )";
        }
    }

    function DeleteDuplicate($table, $fild, $id)
    {

        // foreach ($arraypengguna as $key) {
        // echo $key . "</br>";
        // $tablepengguna = "pengguna"; //2782 -> 1609 = 1173
        // $tableprosedure_permintaan_wifi = "prosedure_permintaan_wifi"; //1981 -> 808 = 1173
        // $tablelaporan_pemasangan_wifi = "laporan_pemasangan_wifi"; //1981 -> 808 = 1173
        // $tablesurvey_pemasangan_wifi = "survey_pemasangan_wifi"; //1981 -> 808 = 1173
        // $fild = "IDPENGGUNA";
        // echo $this->DeleteDuplicate($tablepengguna, $fild, $key) . "</br>";
        // }
        $sqlcek = "Select * from " . $table . " where " . $fild . " = '" . $id . "'";
        $querycek = $this->db->query($sqlcek);
        $rowcek = $querycek->num_rows();
        if ($rowcek > 0) {
            $sql = "delete from " . $table . " where " . $fild . " = '" . $id . "'";
            $query = $this->db->query($sql);
            return $query;
        } else {
            return "data tidak ada";
        }
    }
    function GeneretDataPenggunaNotFound($table, $notename)
    {
        $sql = $this->db->query("SELECT * from " . $table . "");
        $dataLopp = $sql->result();
        $handle = fopen($notename, "w+");
        foreach ($dataLopp as $key) {
            $cekpengguna = $this->db->query("SELECT * from pengguna where IDPENGGUNA = '" . $key->IDPENGGUNA . "'");
            $cek = $cekpengguna->num_rows();
            $pengguna = $cekpengguna->row_array();
            if ($cek < 1) {
                $return =
                    "[" .
                    "IDPENGGUNA => " . "'" . $key->IDPENGGUNA . "'" . "\n" .
                    "IDPERMINTAAN => " . "'" . $key->IDPERMINTAAN . "'" . "\n" .
                    "NAMADEPAN => " . "'" . $pengguna['NAMADEPAN'] . "'" . "\n" .
                    "]," . "\n";
                fwrite($handle, $return);
            }
        }
        fclose($handle);
        return "Scan Successfully";
    }

    function GeneretDataPenggunaNotFoundBylaporan_pemasangan_wifi($table, $notename)
    {
        // $sql = $this->db->query("SELECT tb1.IDPERMINTAAN ,tb1.IDPENGGUNA ,p.NAMADEPAN from " . $table . " AS tb1 JOIN pengguna AS p ON p.IDPENGGUNA = tb1.IDPENGGUNA");
        $sql = $this->db->query("SELECT p.IDPENGGUNA ,p.NAMADEPAN from " . $table . " p");
        $dataLopp = $sql->result();
        $handle = fopen($notename, "w+");
        foreach ($dataLopp as $key) {
            $cekpengguna = $this->db->query("SELECT IDPENGGUNA from prosedure_permintaan_wifi where IDPENGGUNA = '" . $key->IDPENGGUNA . "'");
            $cek = $cekpengguna->num_rows();
            if ($cek < 1) {
                $return =
                    "[" .
                    "IDPENGGUNA => " . "'" . $key->IDPENGGUNA . "'" . "\n" .
                    "NAMADEPAN => " . "'" . $key->NAMADEPAN . "'" . "\n" .
                    "]," . "\n";
                fwrite($handle, $return);
            }
        }
        fclose($handle);
        return "Scan Successfully";
    }
}
