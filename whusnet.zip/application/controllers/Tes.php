<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Tes extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));
		// cek_login();
	}
	function index($str='30') {
		// $data['session']= session();
		$tes = array(
			'tes1' => $str.'M/'.$str.'M',
			'tes2' => 'tes data',
		);
		$res = json_encode($tes);
		echo delBackSlash($res); die();
		echo "tes data / Uji coba <br/>".$data['session'];
	}

	function error() {
		$this->load->view('errors/_dataErrors404');
	}

	//  convert INT / FLOAT number from string format

	function convert() {
		$num = "3.25";
		// convert INT FLOAT
		$int = (int)$num;
		// convert INT number
		$float = (float)$num;

		// result data to array.
		$results = array(
			'number'=> $num,
			'result'=> array(
				'conver int'=> $int,
				'conver float'=> $float
			)
		);

		// conver data to json format
		$res = json_encode($results);
		echo $res;

		// result json
		// {"number":"3.25",
		// "result":{
		// 	"conver int":3,
		// 	"conver float":3.25
		// 	}
		// }

	}


	public function resizeImage($filename) {
		$source_path = $_SERVER['DOCUMENT_ROOT'] . '/upload/tesresize/' . $filename;
		$target_path = $_SERVER['DOCUMENT_ROOT'] . '/upload/tesresize/';
		$config_manip = array(
			'image_library' => 'gd2',
			'source_image' => $source_path,
			'new_image' => $target_path,
			'maintain_ratio' => TRUE,
			'width' => 500,
		);
		$this->load->library('image_lib', $config_manip);
		if (!$this->image_lib->resize()) {
			echo $this->image_lib->display_errors();
		}
		$this->image_lib->clear();
	}


	public function UploadImg() {
		$data = array('userfile' => "File { name: 'Screenshot_2022-06-27_14_39_15.png', lastModified: 1656315555512, webkitRelativePath: '', size: 267100, type: 'image/png'}" );
		// configurasi Upload
		$config['upload_path'] = 'upload/tesresize/';
		$config['allowed_types'] = 'gif|jpg|jpeg|png';
		//$config['max_size'] = 1024 * 8;
		$config['encrypt_name'] = TRUE;
		$this->load->library('upload', $config);
		$file_element_name = "Screenshot_2022-06-27_14_39_15.png";

		if ($this->upload->do_upload($file_element_name)) {
			$uploadData = $this->upload->data();
			$this->resizeImage($uploadData['file_name']);
			$dataInPengguna = $uploadData['file_name'];
		}

		print_r($dataInPengguna);die();
	}

	function getJatuhTempo(){
		$date=date("Y/m/d");
		//$date=date("2022/05/09");
		$checkdate = explode("/",$date);
		$datenow = $checkdate[2];
		//print_r($datenow);die();
		if ( $datenow > 10 ) {
			$getbulannext = date('Y/m/d', strtotime($date. ' + 1 month'));
			$bulannextt = explode("/",$getbulannext);
			$bulannext = $bulannextt[1];
			$tahunnext = $bulannextt[0];
			//print_r($bulannext);die();
			$jatuhtempo = "$tahunnext"."/".$bulannext."/"."10";
		} else {
			$tahunnow = $checkdate[0];
			$bulannow = $checkdate[1];
			$jatuhtempo = "$tahunnow"."/".$bulannow."/"."10";
		}
		print_r($jatuhtempo);die();
	}


	function removeZero() {
		$c = array ('62');
		$d = array ('0');
		$s = str_replace($d, '', $s); // Hilangkan karakter yang disebutkany $d
		$s = strtolower(str_replace($c, '', $s)); // Ganti spasi =>  - dan ubah huruf => kecil semua
		echo $s;
	}


	// function getNoOnuReady()
	// {
	// 	// query list no onu.
	// 	$sql   = $this->db->query("SELECT olt_slot_unregister.IDMESIN, olt_slot_unregister.INDEXONU, sr.NOONU FROM `olt_slot_unregister` JOIN olt_slot_register as sr on sr.IDMESIN=olt_slot_unregister.IDMESIN");
	// 	$query = $sql->result_array();
	// 	print_r($query);die();
	// 	foreach ($query as $v) {
	// 		$NOONU = $v['NOONU'].'<br/>';

	// 		// $check = str_replace('/', '', $v['NOONU']);
	// 		$checkindexonu = substr($v['INDEXONU'], 5, 1);
	// 		if($checkindexonu === ':')
	// 		{
	// 			$SLOTONU = substr($v['INDEXONU'], 4, 1).'<br/>';
	// 		} else {
	// 			$SLOTONU = substr($v['INDEXONU'], 4, 2).'<br/>';
	// 		}
	// 		echo $v['INDEXONU'].'<br/>';
	// 	}
	// 	// --

	// 	// noonu yang tidak berurutan
	// 	// (noslot-1)*128 + nomer belakang

	// }

	function tesno() {
		echo noonu1024();
	}

	public function login_withJWT()
	{
		$data['title']  = "Test login With Json Web Token";
		$this->load->view('_login_jwt', $data);
	}

	public function rupiah($angka){
		$hasil_rupiah = "" . number_format($angka,0,',','.');
		return $hasil_rupiah;
	}
	public function rupiah_format()
	{
		$angka = 1999;
		$angka_format = $this->rupiah($angka);
		echo $angka_format;
		// 1,999
	}

	function fiturgenerate() {
		echo "anda mendapatkan nomor ID : ".generateKodeForm("BR", "Tambah");
		die();
	}




	// api whatsapp by whatsva.id - with ci 3 & php 5.6
	function kirimtext() {
		$data = Array (
			'CREATEBY' => '121',
			'USERLEVEL' => 'Admin',
			'USERIDLEVEL' => '1',
			'IDPERMINTAAN' => 'RQ002745',
			'STATUS' => 'DIPROSES',
			'IDPENGGUNA' => 'PE000383',
			'PELANGGAN' => 'ahmad-fatoni-tes-pesan-wa-terbaru ',
			'NAMA_LENGKAP' => 'ahmad-fatoni-tes-pesan-wa-terbaru',
			'HP' => '6285236768521',
			'ALMT' => 'jl. tester no:40',
			'EMAIL' => 'tester@gmail.com',
			'KOTA' => 'KABUPATEN PONOROGO',
			'KEC' => 'PONOROGO',
			'DESA' => 'PINGGIRSARI',
			'ESTIMASIKEBUTUHAN' => 'rew',
			'KATEGORITINGKAT' => 'SEDANG',
			'KTP_SIM' => '543524524525',
			'JENISKELAMIN' => 'L',
			'LAT' => -'7.2484',
			'LONG' => '112.7419',
			'SPEEDUP' => '5000',
			'STATUSALAT' => 'BELI',
			'JENISJARINGAN' => 'KABEL',
			'FOTORUMAH' => '2dd89262808fdaa69f2862edad594c23.png',
			'FOTOKTP' => 'd4cae440ca53dc2ed97583adbeeb0316.png',
			'FOTOROOTER' => 'a8464711e01574d5673b0fe1e8efa251.png',
			'FOTOSPEED' => '3f637a31d1a5861ac33149d9ee560171.png',
			'FOTOFORMULIR' => '4f26a7c6fb043c15f4a0f5a6eb06031e.png',
			'FOTOTTDFORMULIR' => '0b9ee2446d6b7ce9cdb1fa6baa205a9d.png',
			'IDPAKET' => 'PK21000018',
			'NAMA_PAKET' => 'Dedicated 5 Mbps',
			'HARGA' => '500000',
			'FilterStatus' => 'DISURVEI',
			'TESTUP' => '12',
			'TESTDOWN' => '12',
			'PINGGATEWAY' => '12',
			'PINGGOOGLE' => '12',
			'IPADDR' => '12',
			'SNROOTER_FIBER' => '12',
			'NOMOR_ODP' => '12',
			'NOMOR_PORT_ODP' => '12',
			'NOMOR_PORT_OLT' => '12',
			'SIGNAL_WIRELESS' => '12',
			'BIAYABULANAN' => '166667',
			'BIAYAPASANG' => '11',
			'BIAYALAINLAIN' => '11',
			'TOTALBIAYA' => '166.689',
			'TOTAL' => '0',
			'ALATPASIF' => 'reew',
			'theme' => 'dark',
			'TGLSURVEY' => '2022-06-20 14:55:35',
			'SURVEYER' => 'testing-',
			'inserted_at' => '2022-06-17 11:10:42',
			'REGISTRATOR' => 'testing-',
			'TGLDIPROSES' => '2022-06-20 14:57:00',
			'PEMROSES' => 'testing-',
			'TGLDIACC' => '2022-06-20 14:56:48',
			'DIACCOLEH' => 'testing-',
			'VERIFIED_AT' => '2022-06-20 10:30:31',
			'VERIFIED' => 'testing-',
			'NAMADEPAN' => 'ahmad-fatoni-tes-pesan-wa-terbaru'
		);
		$curl = curl_init();
		$linkin = "http://review.whusnet.com/In/no/".md5($data['IDPERMINTAAN'])."";
		$tglajatuhtempo = date('Y-m-d', strtotime(date("Y/m/d"). ' + 10 day'));
		$data = '{
			"instance_key":"X45q2cL7Qq6p",
			"jid":"6285236768521",
			"message": "*TESTING* YTH. *_'.$data['NAMA_LENGKAP'].'_* \n Pendaftaran Pemasangan Internet sudah kami terima dengan rincian sbb : \n\n Nama Pelanggan : *'.$data['NAMA_LENGKAP'].'* \n Alamat : *'.$data['ALMT'].'* \n NoHP : *'.$data['HP'].'* \n Paket Internet : *'.$data['IDPAKET'].'* \n Jenis Kontrak : *'.$data['STATUSALAT'].'* \n Jenis Jaringan : *'.$data['JENISJARINGAN'].'* \n Biaya Bulanan : *'.toRupiah($data['BIAYABULANAN']).'* \n Tanggal Tagihan : *'.date("Y/m/d").'* \n Jatuh Tempo : *'.$tglajatuhtempo.'* \n Tagihan Awal : *'.$linkin.'* \n\n Jika anda membutuhkan bantuan jika ada kendala segera hub wa.me/62818415131 \n Teknisi Online 24jam - Hanya Hubungi Melalui Chat WA \n \n Untuk pembayaran bisa melalui CASH, TRANSFER. Informasi rekening hub wa.me/62817585853 \n Admin Online 8 Pagi - 4 Sore - Hanya Hubungi Melalui Chat WA \n\n Terima Kasih \n Ini adalah Sistem Otomatis PT Data Arta Sedaya. Jika ada pertanyaan silahkan balas. team kami akan segera merespon."
		}';
		// print_r($data);die();
		curl_setopt_array($curl, array(
			CURLOPT_URL => 'http://apiwa.whusnet.com/index.php/api/sendMessageText',
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'POST',
			CURLOPT_POSTFIELDS => $data,
		));
		// curl_exec($curl);
		$res = curl_exec($curl);
		print_r($res);die();
		curl_close($curl);
		echo $res;
	}

	function kirimtext_0() {
		$data = Array (
			'CREATEBY' => '121',
			'USERLEVEL' => 'Admin',
			'USERIDLEVEL' => '1',
			'IDPERMINTAAN' => 'RQ002745',
			'STATUS' => 'DIPROSES',
			'IDPENGGUNA' => 'PE000383',
			'PELANGGAN' => 'ahmad-fatoni-tes-pesan-wa-terbaru ',
			'NAMA_LENGKAP' => 'ahmad-fatoni-tes-pesan-wa-terbaru',
			'HP' => '6285236768521',
			'ALMT' => 'jl. tester no:40',
			'EMAIL' => 'tester@gmail.com',
			'KOTA' => 'KABUPATEN PONOROGO',
			'KEC' => 'PONOROGO',
			'DESA' => 'PINGGIRSARI',
			'ESTIMASIKEBUTUHAN' => 'rew',
			'KATEGORITINGKAT' => 'SEDANG',
			'KTP_SIM' => '543524524525',
			'JENISKELAMIN' => 'L',
			'LAT' => -'7.2484',
			'LONG' => '112.7419',
			'SPEEDUP' => '5000',
			'STATUSALAT' => 'BELI',
			'JENISJARINGAN' => 'KABEL',
			'FOTORUMAH' => '2dd89262808fdaa69f2862edad594c23.png',
			'FOTOKTP' => 'd4cae440ca53dc2ed97583adbeeb0316.png',
			'FOTOROOTER' => 'a8464711e01574d5673b0fe1e8efa251.png',
			'FOTOSPEED' => '3f637a31d1a5861ac33149d9ee560171.png',
			'FOTOFORMULIR' => '4f26a7c6fb043c15f4a0f5a6eb06031e.png',
			'FOTOTTDFORMULIR' => '0b9ee2446d6b7ce9cdb1fa6baa205a9d.png',
			'IDPAKET' => 'PK21000018',
			'NAMA_PAKET' => 'Dedicated 5 Mbps',
			'HARGA' => '500000',
			'FilterStatus' => 'DISURVEI',
			'TESTUP' => '12',
			'TESTDOWN' => '12',
			'PINGGATEWAY' => '12',
			'PINGGOOGLE' => '12',
			'IPADDR' => '12',
			'SNROOTER_FIBER' => '12',
			'NOMOR_ODP' => '12',
			'NOMOR_PORT_ODP' => '12',
			'NOMOR_PORT_OLT' => '12',
			'SIGNAL_WIRELESS' => '12',
			'BIAYABULANAN' => '166667',
			'BIAYAPASANG' => '11',
			'BIAYALAINLAIN' => '11',
			'TOTALBIAYA' => '166.689',
			'TOTAL' => '0',
			'ALATPASIF' => 'reew',
			'theme' => 'dark',
			'TGLSURVEY' => '2022-06-20 14:55:35',
			'SURVEYER' => 'testing-',
			'inserted_at' => '2022-06-17 11:10:42',
			'REGISTRATOR' => 'testing-',
			'TGLDIPROSES' => '2022-06-20 14:57:00',
			'PEMROSES' => 'testing-',
			'TGLDIACC' => '2022-06-20 14:56:48',
			'DIACCOLEH' => 'testing-',
			'VERIFIED_AT' => '2022-06-20 10:30:31',
			'VERIFIED' => 'testing-',
			'NAMADEPAN' => 'ahmad-fatoni-tes-pesan-wa-terbaru'
		);
		$ch = curl_init('http://apiwa.whusnet.com/index.php/api/sendMessageText');
		$linkin = "http://review.whusnet.com/In/no/".md5($data['IDPERMINTAAN'])."";
		$tglajatuhtempo = date('Y-m-d', strtotime(date("Y/m/d"). ' + 10 day'));

		$data = '{
			"instance_key":"X45q2cL7Qq6p",
			"jid":"6285236768521",
			"message": "*TESTING* YTH. *_'.$data['NAMA_LENGKAP'].'_* \n Pendaftaran Pemasangan Internet sudah kami terima dengan rincian sbb : \n\n Nama Pelanggan : *'.$data['NAMA_LENGKAP'].'* \n Alamat : *'.$data['ALMT'].'* \n NoHP : *'.$data['HP'].'* \n Paket Internet : *'.$data['IDPAKET'].'* \n Jenis Kontrak : *'.$data['STATUSALAT'].'* \n Jenis Jaringan : *'.$data['JENISJARINGAN'].'* \n Biaya Bulanan : *'.toRupiah($data['BIAYABULANAN']).'* \n Tanggal Tagihan : *'.date("Y/m/d").'* \n Jatuh Tempo : *'.$tglajatuhtempo.'* \n Tagihan Awal : *'.$linkin.'* \n\n Jika anda membutuhkan bantuan jika ada kendala segera hub wa.me/62818415131 \n Teknisi Online 24jam - Hanya Hubungi Melalui Chat WA \n \n Untuk pembayaran bisa melalui CASH, TRANSFER. Informasi rekening hub wa.me/62817585853 \n Admin Online 8 Pagi - 4 Sore - Hanya Hubungi Melalui Chat WA \n\n Terima Kasih \n Ini adalah Sistem Otomatis PT Data Arta Sedaya. Jika ada pertanyaan silahkan balas. team kami akan segera merespon."
		}';

		//print_r($data);die();
		curl_setopt($ch, CURLOPT_URL, 'http://apiwa.whusnet.com/index.php/api/sendMessageText');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
		curl_setopt($ch, CURLOPT_TIMEOUT_MS, 10);
		curl_setopt($ch, CURLOPT_ENCODING, '');
		curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
		curl_setopt($ch, CURLOPT_TIMEOUT, 0);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLINFO_HTTP_CODE, 'http://apiwa.whusnet.com/index.php/api/sendMessageText');

		$curl_errno = curl_errno($ch);
		$curl_error = curl_error($ch);
		$res = curl_exec($ch);
		curl_close($ch);
		// print_r($curl_errno);die();
		if ($curl_errno > 0) {
			echo "cURL Error ($curl_errno): $curl_error\n";
		} else {
			echo $res;
		}
	}


	function kirimtext_1() {
		// $this->config->load('confcompany', TRUE);
		// $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
		// $urlgateway = "http://demoapiwawhatsva.kazuyamedia.tech";
		$urlgateway = "http://apiwa.whusnet.com";
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => ''.$urlgateway.'/index.php/api/sendMessageText',
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'POST',
			CURLOPT_POSTFIELDS =>'{
				"instance_key":"MZoYLg7rCY3h",
				"jid":"6285236768521",
				"message":"hello Ton ini test demo api :D "
				}',
			));
			// $response = curl_exec($curl);

			curl_setopt($curl, CURLOPT_URL, ''.$urlgateway.'/index.php/api/sendMessageText');
			curl_setopt($curl, CURLOPT_FAILONERROR, true); // Required for HTTP error codes to be reported via our call to curl_error($ch)
			//...
			$response = curl_exec($curl);
			if (curl_errno($curl)) {
				$error_msg = curl_error($curl);
				$error_no = curl_errno($curl);
			}
			curl_close($curl);

			if (isset($error_no)) {
				// TODO - Handle cURL error accordingly
				print_r($error_msg.'<br/>');
				print_r($error_no);
			}

			// curl_close($curl);
			echo $response;
		}


		function kirimtext_2() {

			$this->config->load('confcompany', TRUE);
			$urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway

			ini_set('max_execution_time', 10); // prevents 30 seconds from being fatal

			$ch = curl_init();

			curl_setopt($ch, CURLOPT_TIMEOUT, 15); // curl timeout remains at 30 seconds
			curl_setopt($ch, CURLOPT_URL, ''.$urlgateway.'/index.php/api/sendMessageText');
			curl_exec($ch);

			if ($error_number = curl_errno($ch)) {
				if (in_array($error_number, array(CURLE_OPERATION_TIMEDOUT, CURLE_OPERATION_TIMEOUTED))) {
					print "curl timed out";
				}
			} else {
				$curl = curl_init();
				curl_setopt_array($curl, array(
					CURLOPT_URL => ''.$urlgateway.'/index.php/api/sendMessageText',
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_ENCODING => '',
					CURLOPT_MAXREDIRS => 10,
					CURLOPT_TIMEOUT => 0,
					CURLOPT_FOLLOWLOCATION => true,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_CUSTOMREQUEST => 'POST',
					CURLOPT_POSTFIELDS =>'{
						"instance_key":"MZoYLg7rCY3h",
						"jid":"6283845478148",
						"message":"hello broo tess pesan pembayaran"
						}',
					));
					$response = curl_exec($curl);
					curl_close($curl);
					echo $response;
				}
				curl_close($ch);
			}




			function test_timeout() {
				if (!isset($_GET['foo'])) {
					// Client.
					$ch = curl_init('http://http://localhost:8088/smw_masternew/Tes/test_timeout?foo=bar');
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
					curl_setopt($ch, CURLOPT_TIMEOUT_MS, 200);
					$data = curl_exec($ch);
					$curl_errno = curl_errno($ch);
					$curl_error = curl_error($ch);
					curl_close($ch);
					if ($curl_errno > 0) {
						echo "cURL Error ($curl_errno): $curl_error\n";
					} else {

						$this->config->load('confcompany', TRUE);
						$urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
						$curl = curl_init();
						curl_setopt_array($curl, array(
							CURLOPT_URL => ''.$urlgateway.'/index.php/api/sendMessageText',
							CURLOPT_RETURNTRANSFER => true,
							CURLOPT_ENCODING => '',
							CURLOPT_MAXREDIRS => 10,
							CURLOPT_TIMEOUT => 0,
							CURLOPT_FOLLOWLOCATION => true,
							CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
							CURLOPT_CUSTOMREQUEST => 'POST',
							CURLOPT_POSTFIELDS =>'{
								"instance_key":"MZoYLg7rCY3h",
								"jid":"6283845478148",
								"message":"hello broo tess pesan pembayaran"
								}',
							));
							$response = curl_exec($curl);
							curl_close($curl);
							echo $response;
							echo "Data received: $data\n";

						}
					} else {
						// Server.
						sleep(10);
						echo "Done.";
					}
				}

				function sendDokumen(){
					$curl = curl_init();

					curl_setopt_array($curl, array(
						CURLOPT_URL => 'http://localhost:8088/Panel_WhatsApp/index.php/api/sendDocumentUrl',
						CURLOPT_RETURNTRANSFER => true,
						CURLOPT_ENCODING => '',
						CURLOPT_MAXREDIRS => 10,
						CURLOPT_TIMEOUT => 0,
						CURLOPT_FOLLOWLOCATION => true,
						CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
						CURLOPT_CUSTOMREQUEST => 'POST',
						CURLOPT_POSTFIELDS =>'{
							"instance_key":"mhWDb2ZuKy7M",
							"jid":"6285236768521",
							"documentUrl":"http://pustaka.unp.ac.id/file/abstrak_kki/EBOOKS/23%20kiat%20hidup%20bahagia.pdf"
							}',
						));

						$response = curl_exec($curl);

						curl_close($curl);
						echo $response;
					}

					function sendCoordinate(){
						$curl = curl_init();

						curl_setopt_array($curl, array(
							CURLOPT_URL => 'http://localhost:8088/Panel_WhatsApp/index.php/api/sendLocation',
							CURLOPT_RETURNTRANSFER => true,
							CURLOPT_ENCODING => '',
							CURLOPT_MAXREDIRS => 10,
							CURLOPT_TIMEOUT => 0,
							CURLOPT_FOLLOWLOCATION => true,
							CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
							CURLOPT_CUSTOMREQUEST => 'POST',
							CURLOPT_POSTFIELDS =>'{

								"instance_key":"mhWDb2ZuKy7M",

								"jid":"6285236768521",

								"coordinates":{

									"lat": -7.5964593,
									"long": 111.4516499

									}

									}',
								));

								$response = curl_exec($curl);

								curl_close($curl);
								echo $response;

							}

							function listOptionMessage(){
								$curl = curl_init();

								curl_setopt_array($curl, array(
									CURLOPT_URL => 'http://localhost:8088/Panel_WhatsApp/index.php/api/sendListMessage',
									CURLOPT_RETURNTRANSFER => true,
									CURLOPT_ENCODING => '',
									CURLOPT_MAXREDIRS => 10,
									CURLOPT_TIMEOUT => 0,
									CURLOPT_FOLLOWLOCATION => true,
									CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
									CURLOPT_CUSTOMREQUEST => 'POST',
									CURLOPT_POSTFIELDS =>'{

										"instance_key":"mhWDb2ZuKy7M",

										"jid":"6285236768521",

										"buttonText": "hello",

										"description": "ini list message",

										"sections": [

											{

												"title": "judul list",

												"rows": [

													{

														"title": "Sub list 1",

														"description": "descript 1",

														"rowId": "1"

														},

														{

															"title": "sub list 2",

															"description": "descript 2",

															"rowId": "2"

															}

															]

															}

															]}',
														));

														$response = curl_exec($curl);

														curl_close($curl);
														echo $response;

													}

													function sendButtonMessage() {
														$curl = curl_init();
														curl_setopt_array($curl, array(
															CURLOPT_URL => 'http://localhost:8088/Panel_WhatsApp/index.php/api/sendButtonMessage',
															CURLOPT_RETURNTRANSFER => true,
															CURLOPT_ENCODING => '',
															CURLOPT_MAXREDIRS => 10,
															CURLOPT_TIMEOUT => 0,
															CURLOPT_FOLLOWLOCATION => true,
															CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
															CURLOPT_CUSTOMREQUEST => 'POST',
															CURLOPT_POSTFIELDS =>'{

																"instance_key":"mhWDb2ZuKy7M",

																"jid":"6285236768521",

																"contentText": "Apakah kamu mempunyai uang ?",

																"footerText": "jawab dengan jujur",

																"buttons": [

																	{

																		"buttonId": "btn1",

																		"buttonText": {

																			"displayText": "Yes"

																			},

																			"type": 1

																			},

																			{

																				"buttonId": "btn2",

																				"buttonText": {

																					"displayText": "No"

																					},

																					"type": 1

																					}

																					]

																					}',
																				));

																				$response = curl_exec($curl);

																				curl_close($curl);
																				echo $response;

																			}


																			function kirimpesanfile() {
																				$curl = curl_init();

																				curl_setopt_array($curl, array(
																					CURLOPT_URL => 'http://localhost:8088/Panel_WhatsApp/index.php/api/sendImageUrl',
																					CURLOPT_RETURNTRANSFER => true,
																					CURLOPT_ENCODING => '',
																					CURLOPT_MAXREDIRS => 10,
																					CURLOPT_TIMEOUT => 0,
																					CURLOPT_FOLLOWLOCATION => true,
																					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
																					CURLOPT_CUSTOMREQUEST => 'POST',
																					CURLOPT_POSTFIELDS =>'{
																						"instance_key":"mhWDb2ZuKy7M",
																						"jid":"6285236768521",
																						"imageUrl":"https://www.greenscene.co.id/wp-content/uploads/2021/09/One-Piece-11-696x497.jpg",
																						"caption":"hello mas apa kabs 03"
																						}',
																					));

																					$response = curl_exec($curl);

																					curl_close($curl);
																					echo $response;
																				}

																				function printpage() {
																					$data['title'] = 'Tes data print';
																					// $session    = session();
																					$data['session']    = session();
																					$this->load->view('tesPrint', $data);
																				}

																				function printpage2() {
																					$data['title'] = 'Tes data print';
																					$data['session']    = session();
																					// $session    = session();
																					$this->template->load('_template','filePrint', $data);
																				}

																				function sandSms() {
																					$this->load->helper('Textmagic/textmagic-cli');
																					$client = new TextmagicRestClient('<USERNAME>', '<APIV2_KEY>');
																					$result = ' ';
																					try {
																						$result = $client->messages->create(
																							array(
																								'text' => 'Hello from TextMagic PHP',
																								'phones' => implode(', ', array('99900000'))
																							)
																						);
																					}
																					catch (\Exception $e) {
																						if ($e instanceof RestException) {
																							print '[ERROR] ' . $e->getMessage() . "\n";
																							foreach ($e->getErrors() as $key => $value) {
																								print '[' . $key . '] ' . implode(',', $value) . "\n";
																							}
																						} else {
																							print '[ERROR] ' . $e->getMessage() . "\n";
																						}
																						return;
																					}
																					echo $result['id'];
																				}

																				function multiImgFile() {
																					$data['title'] = 'Fungsi Upload Image';
																					$this->template->load('_template','_uploadmultiImg', $data);
																					// $this->load->view('_uploadImg', $data);
																				}

																				function imgFile() {
																					$data['title'] = 'Fungsi Upload Image';
																					$this->template->load('_template','_uploadImg', $data);
																				}

																				function testQR_code() {
																					$data['title'] = 'Test QR Code';
																					$data['r'] = 'Toni elek koyok kebo gudel... !';
																					$data['session']    = session();
																					$this->template->load('_template','_Tes_QR_code', $data);
																				}

																				// TEST API FROM MIKHMON
																				function testKoneksiforMikmon() {

																					$this->load->library('RouterosAPI');

																					$iphost		= "192.168.88.1";
																					$userhost	= "admin";
																					$passwdhost	= "1234";

																					$API = new RouterosAPI();
																					$API->debug = false;
																					if ($API->connect($iphost, $userhost, $passwdhost)){
																						$_SESSION["connect"] = "<b class='text-green'>Connected</b>";
																						echo "Tersambung";
																						die();
																					} else {
																						echo "tidak tersambung"; die();
																					}
																				}

																				function pingRouter() {
																					$data = array(
																						"hostname" 		=> "192.168.88.1",
																						"target" 		=> "192.168.88.21",
																						"username" 		=> "admin",
																						"password" 		=> "1234",
																					);
																					if ($con = $this->routerosapi->connect($hostname=$data['hostname'], $username=$data['username'], $password=$data['password'])) {
																						$this->routerosapi->write('/Tools/Ping',false);
																						$this->routerosapi->write(''.$data['target'], false);
																						$READ  = 	$this->routerosapi->read(false);
																						$ARRAY = 	$this->routerosapi->parseResponse($READ);
																						echo "success";
																						$this->routerosapi->disconnect();
																					}
																				}

																				function func_conn_router() {
																					$data = array(
																						"hostname" => "103.242.105.91",
																						"username" => "AripTuri",
																						"password" => "FGjk786*2",
																						'port' => 6565,
																					);
																					$con = $this->routerosapi->connect($hostname=$data['hostname'], $username=$data['username'], $password=$data['password'], $port=$data['port']);
																					$session_router = array(
																						"host"  		=> $hostname,
																						"username"  => $username,
																						"password"  => $password,
																						"port"  	=> $port,
																						"statusrouter" => $con,
																					);

																					if ($session_router['statusrouter']=="") {

																						print_r($session_router);
																						echo "Gagal tersambung"; die();
																					}else {
																						print_r($session_router);
																						echo "tersambung"; die();
																					}



																					if ( $con !== true ) {
																						echo "Gagal tersambung"; die();
																					}
																					echo "tersambung"; die();

																					echo json_encode(array('res'=>$con, 'session_res' => $session_router));
																				}

																				function connectionIpClient() {
																					$data = array(
																						"hostname" 		=> "192.168.88.1",
																						"target" 		=> "192.168.88.12",
																						"username" 		=> "admin",
																						"password" 		=> "1234",
																						'name' 			=> "tes",
																						'port' 			=> "8728",
																						'limit'			=> "256k",
																						// 'mac_address' 	=> "F0:4D:A2:C1:9E:11",
																						'profile' 		=> "tes-profile",
																						'comment' 		=> "Ahmad-Fatoni-WIRELESS-D1",
																						'disabled' 		=> "false",
																						'maxlimit' 	  	=> "256k",
																					);
																					if ($con = $this->routerosapi->connect($hostname=$data['hostname'], $username=$data['username'], $password=$data['password'], $port=$data['port'])) {
																						// $this->routerosapi->write('/queue/simple/add',false);
																						$this->routerosapi->write('/queue/simple/update', false);
																						$this->routerosapi->write('=name='.$data['name'],false);
																						$this->routerosapi->write('=target='.$data['target'], false);
																						$this->routerosapi->write('=max-limit='.$data['limit'], false);
																						$this->routerosapi->write('=comment='.$data['comment'],true);         // coment
																						$this->routerosapi->write('=disabled=yes');

																						$READ = 	$this->routerosapi->read(false);
																						$ARRAY = 	$this->routerosapi->parseResponse($READ);
																						print_r($ARRAY);
																						echo "success";
																						$this->routerosapi->disconnect();

																					}
																				}


																				function simpleAdd_queue() {
																					$data = array(
																						"hostname" 		=> "192.168.88.1",
																						"target" 		=> "192.168.88.21",
																						"username" 		=> "admin",
																						"password" 		=> "1234",
																						'port' 			=> "8728",
																						'name' 			=> "tes",
																						'mac_address' 	=> "F0:4D:A2:C1:9E:11",
																						'profile' 		=> "tes-profile",
																						'comment' 		=> "",
																						'disabled' 		=> "disable",
																						'maxlimit' 	  	=> "1M",
																					);
																					if ($con = $this->routerosapi->connect($hostname=$data['hostname'], $username=$data['username'], $password=$data['password'], $port=$data['port'])) {
																						$this->routerosapi->write('/queue/simple/add',false);
																						$this->routerosapi->write('=name='.$data['name'], false);
																						$this->routerosapi->write('=target='.$data['target'],false);   // IP
																						$this->routerosapi->write('=max-limit='.$data['maxlimit'],false);   //   2M/2M   [TX/RX]
																						$this->routerosapi->write('=comment='.$data['comment'],true);         // coment
																						$READ = 	$this->routerosapi->read(false);
																						$ARRAY = 	$this->routerosapi->parseResponse($READ);
																						print_r($ARRAY);
																						echo "success";
																						$this->routerosapi->disconnect();

																					}
																				}

																				// get url / data with  = CURL function / TEST KONEKSI
																				function connrouter_curl() {
																					echo $this->curl->simple_get(base_url('Tes/func_conn_router'));
																				}


																				public function process_login(){

																					if ($this->routerosapi->connect($hostname="192.168.88.1", $username="admin", $password="1234"))
																					{
																						$data = array(
																							'hostname_mikrotik'=> $hostname,
																							'username_mikrotik' => $username,
																							'password_mikrotik' => $password,
																							'login' => TRUE);
																							$this->session->set_userdata($data);
																							redirect('hotspot');
																							// echo "tersambung..!";
																						}
																						else
																						{
																							$this->session->set_flashdata('message', 'Login gagal. Pastikan hostname, username dan password yang Anda masukkan benar!');
																							// redirect('login');
																							echo "gagal"; die();
																						}
																					}

																					function coba(){
																						$data['session']= session();
																						$data['title'] = 'Data Uji Coba';

																						$this->template->load('_template','_uploadmultiImg', $data);
																					}
																					function hapusBackSlash(){
																						$url = "http:\/\/tesdata.com\/images";

																						echo $url.'<br/>';
																						echo 'Hapus Back Slash URL : '.delBSlash($url);
																						die();
																					}


																					/* ====  */
																					function tesDataAjax(){
																						$data['session']= session();

																						$data['title'] = "LIST JABATAN";

																						$this->template->load('_template','tesAjax', $data);
																					}
																					function getDataContoh(){
																						$this->load->model('ModelContoh', 'model');
																						$res = $this->model->getKategori();
																						echo json_encode($res);
																					}


																					function tesKonfikSession()
																					{
																						$data = configApp('Tes data', 'konfigurasi session app');

																						$data['title'] = "LIST JABATAN";

																						$data['Tes'] = $this->session->userdata('userdata');

																						$this->template->load('_template','tesAjax', $data);
																					}

																					function configApp($title='tes', $c_des=null)
																					{
																						// $this->load->helper('configsession');
																						// 	$session = session();

																						// $id = $this->session->userdata('IDUSERS');
																						// print_r($id);die();


																						/*  note
																						nilai satu

																						*/



																						$id  = $this->session->userdata('IDUSERS');

																						// $CI = get_instance();
																						$this->load->model('M_auth');
																						$auth = $this->M_auth->get_by_id($id);
																						print_r($auth);die();
																						$site = $this->M_auth->listing();
																						$data = array(
																							'TITLE' => $title.' | '.$site['nama_website'],
																							'LOGO' => $site['logo'],
																							'FAVICON' => $site['favicon'],
																							'email' => $site['email'],
																							'NO_TELP' => $site['no_telp'],
																							'ALAMAT' => $site['alamat'],
																							'FACEBOOK' => $site['facebook'],
																							'INSTAGRAM' => $site['instagram'],
																							'KEYWORDS' => $site['keywords'],
																							'METATEXT' => $site['metatext'],
																							'ABOUT' => $site['about'],
																							'SITE' => $site,
																							'C_JUDUL' => $title,
																							'C_DES' => $c_des,
																							'userdata' => $auth,
																						);
																						print_r($data);die();
																						return $data;
																					}




																					//menampilkan ip address menggunakan function getenv()
																					function get_client_ip() {
																						$ipaddress = '';
																						if (getenv('HTTP_CLIENT_IP'))
																						$ipaddress = getenv('HTTP_CLIENT_IP');
																						else if(getenv('HTTP_X_FORWARDED_FOR'))
																						$ipaddress = getenv('HTTP_X_FORWARDED_FOR');
																						else if(getenv('HTTP_X_FORWARDED'))
																						$ipaddress = getenv('HTTP_X_FORWARDED');
																						else if(getenv('HTTP_FORWARDED_FOR'))
																						$ipaddress = getenv('HTTP_FORWARDED_FOR');
																						else if(getenv('HTTP_FORWARDED'))
																						$ipaddress = getenv('HTTP_FORWARDED');
																						else if(getenv('REMOTE_ADDR'))
																						$ipaddress = getenv('REMOTE_ADDR');
																						else
																						$ipaddress = 'IP tidak dikenali';
																						return $ipaddress;
																					}


																					//menampilkan ip address menggunakan function $_SERVER
																					function get_client_ip_2() {
																						$ipaddress = '';
																						if (isset($_SERVER['HTTP_CLIENT_IP']))
																						$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
																						else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
																						$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
																						else if(isset($_SERVER['HTTP_X_FORWARDED']))
																						$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
																						else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
																						$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
																						else if(isset($_SERVER['HTTP_FORWARDED']))
																						$ipaddress = $_SERVER['HTTP_FORWARDED'];
																						else if(isset($_SERVER['REMOTE_ADDR']))
																						$ipaddress = $_SERVER['REMOTE_ADDR'];
																						else
																						$ipaddress = 'IP tidak dikenali';
																						return $ipaddress;
																					}

																					//menampilkan jenis web browser pengunjung
																					function get_client_browser() {
																						$browser = '';
																						if(strpos($_SERVER['HTTP_USER_AGENT'], 'Netscape'))
																						$browser = 'Netscape';
																						else if (strpos($_SERVER['HTTP_USER_AGENT'], 'Firefox'))
																						$browser = 'Firefox';
																						else if (strpos($_SERVER['HTTP_USER_AGENT'], 'Chrome'))
																						$browser = 'Chrome';
																						else if (strpos($_SERVER['HTTP_USER_AGENT'], 'Opera'))
																						$browser = 'Opera';
																						else if (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE'))
																						$browser = 'Internet Explorer';
																						else
																						$browser = 'Other';
																						return $browser;
																					}

																					function IPnya() {
																						$ipaddress = '';
																						if (getenv('HTTP_CLIENT_IP'))
																						$ipaddress = getenv('HTTP_CLIENT_IP');
																						else if(getenv('HTTP_X_FORWARDED_FOR'))
																						$ipaddress = getenv('HTTP_X_FORWARDED_FOR');
																						else if(getenv('HTTP_X_FORWARDED'))
																						$ipaddress = getenv('HTTP_X_FORWARDED');
																						else if(getenv('HTTP_FORWARDED_FOR'))
																						$ipaddress = getenv('HTTP_FORWARDED_FOR');
																						else if(getenv('HTTP_FORWARDED'))
																						$ipaddress = getenv('HTTP_FORWARDED');
																						else if(getenv('REMOTE_ADDR'))
																						$ipaddress = getenv('REMOTE_ADDR');
																						else
																						$ipaddress = 'IP Tidak Dikenali';
																						return $ipaddress;
																					}


																					function cekip() // CEK IP.   &&  PHYSICAL ADDRESS.
																					{
																						$_IP_SERVER = $_SERVER['SERVER_ADDR'];
																						$_IP_ADDRESS = $_SERVER['REMOTE_ADDR'];
																						if($_IP_ADDRESS == $_IP_SERVER)
																						{
																							ob_start();
																							system('ipconfig /all');
																							$_PERINTAH  = ob_get_contents();
																							ob_clean();
																							$_PECAH = strpos($_PERINTAH, "Ethernet adapter Ethernet");
																							$_PECAH = strpos($_PERINTAH, "Physical");
																							$_HASIL = substr($_PERINTAH,($_PECAH+36),17);  // ambil MAC Adreess  ||   Physical Adreess

																							echo "IP Anda : </br>".$_IP_ADDRESS."</br>
																							MAC ADDRESS eth 0 Anda : </br>".$_HASIL; // MAC Adreess  ||   Physical Adreess
																						}
																						die();
																					}


																					function generatePass() // CEK IP.   &&  PHYSICAL ADDRESS.
																					{
																						$pass = "6";

																						if($pass !== "")
																						{
																							$pass = randomPass($pass);
																							echo $pass.'<br/>';
																							echo sha1($pass);
																						}
																						die();
																					}
																				}
																				/* End of file Home.php */
																				/* Location: ./application/controllers/Home.php */
