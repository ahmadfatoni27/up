<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_Absensi extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('configsession','my'));
		$this->load->model(
			array(
				'absensi/M__Absensi'=>'model',
			)
		);
	}
	function index(){
		$data['title'] = "Data Yang telah di Survei";
		$data['session']= session();
		$this->template->load('_template', 'absensi/@_Absensi', $data);
	}
	// QRCODE FUNCTION
	function Absen_Pegawai() {
		$id = $this->uri->segment(4);
		print_r($id);die();
		// input ke riwayat absensi dengan timestime dengan id pengguna dan id uniq
	}

}?>
