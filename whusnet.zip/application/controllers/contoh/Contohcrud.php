<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Contohcrud extends CI_Controller
{
	function __construct(){
		parent::__construct();
		// $absensi = $this->load->database('db_absensi', TRUE);
		// $db = $this->load->database('default', TRUE);
		$this->load->helper(array('login','configsession','my')); cek_login();
		$this->load->model('contoh/M_Contoh','model');
	}
	function index()
	{
		$data['title'] = "Data Merk";
		$data['session']= session();
		$this->template->load('_template', 'contoh/@_contoh',$data);
	}
	function getData(){
		$data = array(
			'start' => $_POST['start'],
			'length' => $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filtertext' => $_POST['filtertext']);
			$res = $this->model->getDataAll($data);
			echo json_encode($res);
		}


		public function getDataFromDB_ABSENSI(){
			$res = $this->model->GetBedaDB();
			print_r($res);die();
			echo json_encode($user2);
		}

		public function getIDNOPORTODP(){
			// OK
			$id = generateKodeODP('ODPLOC','tambah');
			// /OK
			print_r($res);die();
		}


		public function resizeImage($filename) {
			$source_path = $_SERVER['DOCUMENT_ROOT'] . '/upload/tesresize/' . $filename;
			$target_path = $_SERVER['DOCUMENT_ROOT'] . '/upload/tesresize/';
			$config_manip = array(
				'image_library' => 'gd2',
				'source_image' => $source_path,
				'new_image' => $target_path,
				'maintain_ratio' => TRUE,
				'width' => 450,
			);
			$this->load->library('image_lib', $config_manip);
			if (!$this->image_lib->resize()) {
				echo $this->image_lib->display_errors();
			}
			$this->image_lib->clear();
		}


		function save(){

			$config['upload_path'] = 'upload/tesresize/';
			$config['allowed_types'] = 'gif|jpg|jpeg|png';
			//$config['max_size'] = 1024 * 8;
			$config['encrypt_name'] = TRUE;
			$this->load->library('upload', $config);
			$file_element_name = "userfile";

			$dataBarang = array(
				'KODEBARANG'    => '1',
				'MACADDRESS'    => $_POST['MACADDRESS'],
				'SERIALNUMBER'  => $_POST['SERIALNUMBER'],
				'NAMABARANG'    => $_POST['NAMABARANG'],
			);


			if ($this->upload->do_upload($file_element_name)) {
				$uploadData = $this->upload->data();
				$this->resizeImage($uploadData['file_name']);
				$dataBarang['FOTO'] = $uploadData['file_name'];
			}

			print_r($dataBarang);die();


			echo json_encode($res);
		}

		function checkId(){
			$data = json_decode(file_get_contents('php://input'), true);
			$check = $this->model->checkId($data['id']);
			$res = array( 'res' => $check);echo json_encode($res);
		}


	}?>
