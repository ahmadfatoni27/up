<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once APPPATH . '/core/MYController.php';

class CronPesanWA extends MYController
{
  protected $cron           = 'apikeuangan_buktitransaksitagihan'; // this is table name.
  protected $tb_nolimitcron = 'tb_nolimitcron'; 		// this is table name.
  protected $param          = 'IDUNIQ';             // this is parameter update table.
  protected $paramWA        = 'IDTRANSAKSI';             // this is parameter update table.
  protected $paramstart     = 'ID'; 			      // this is parameter update table.
  /**
  * This is default constructor of the class
  */
  public function __construct()
  {
    parent::__construct();
  }

  public function index() {
    // insert table with auto.
    // $keyValue   = $this->input->post('key');
    // $check      = $this->checkKey($keyValue);
    // check bulan hari ini dan bulan pada tb limit cron
    // get month
    $checkbulan = $this->checkstartlenght(); // from tb_nolimitcron
    $checkbulan = $checkbulan["BULAN"];
    $checkbulan = explode("-",$checkbulan);
    $checkbulan = $checkbulan[1]; // end get month
    $now = date("m"); // month now.
    if ($checkbulan !== $now) {
      echo "bulan tidak sama maka harus update";
      $data = array(
        'ID'    => "2",
        'START' => 0,
        'BULAN' => date("Y-m-d"),
      );
      $query = $this->update($this->tb_nolimitcron, $data, $this->paramstart); // table_name, data_insert , parameter_update.
      $this->res(200, 'start data is reseted!'); die(); // bisa data / query result.
    }
    // if($check === true){
      $checkstartlenght = $this->checkstartlenght(); // from tb_nolimitcron
      $start            = $checkstartlenght["START"];
      $lenght           = $checkstartlenght["LENGHT"];
      $bulantblimit     = $checkstartlenght["BULAN"];
      $datainputqweri   = $this->getDatacron($start,$lenght);
      // print_r($datainputqweri);die();
      $date             = date("Y-m-d H:i:s");
      $pesan            = $this->getDataPesan();
      if ($datainputqweri=="null") {
        $this->res(204); // bisa data / query result.
      }else {
        foreach($datainputqweri as $v){
          $idcek           = $v->IDTRANSAKSI;
          $ceknotivwa      = $this->ceknotivwa($idcek);
          if ($ceknotivwa!="next") {
            if ($v->FLAG==0){
              if ($v->HP==="") {
                $this->res(404, 'no HP null'); // bisa data / query result.
              }else{
                $checkKeyactive = $this->keyActive();
                if ($checkKeyactive==='no connect') {
                  $res = json_encode(array('status' => FALSE, 'res' => $checkKeyactive));
                  echo $res;
                }else{
                  //jalankan fungsi cron kirim pesan dan update notivwa menjadi 1
                  $this->config->load('confcompany', TRUE);
                  $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration, custom configuration in config/confcompany.php
                  /* SENDING MESSAGE WA */
                  $curl = curl_init();
                  // AMBIL urlgatewaywa, api Whatsapp from setup confcompany.
                  $CURLOPT_URL = ''.$urlgateway.'/index.php/api/sendMessageText';
                  // BUAT CURLOPT_POSTFIELDS /  DATA YANG AKAN DI POST KE API WHATSAPP.
                  $data = '{
                     "instance_key":  "'.$this->keyActive().'" ,
                     "jid": "'.$v->HP.'",
                     "message": "Pelanggan a.n *'.$v->NAMADEPAN.'*\n No.Pelanggan : _*'.$v->IDTRANSAKSI.'*_ . \n'.$pesan['TEMPLATEMESSAGE'].'\nTotal tagihan anda : '.toRupiah($v->BAYAR).'"
                   }';
                   curl_setopt_array($curl, array(
                    CURLOPT_URL => $CURLOPT_URL,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS => $data,
                  ));
                  // curl_exec($curl);
                   $res = curl_exec($curl);
                   curl_close($curl);
                   /* END SENDING MESSAGE WA */
                   $data = array(
                    "IDTRANSAKSI"  => $v->IDTRANSAKSI,
                    'notivwa'      => "1",
                  ); 
                  // $this->model->updateTiketMasuk($data);
                  $query = $this->update($this->cron, $data, $this->paramWA); // table_name, data_insert , parameter_update.
                 }
               }
             }else{
              // jalankan fungsi next
              $data  = array(
              "IDUNIQ"         => $v->IDUNIQ,
              "IDTRANSAKSI"    => $v->IDTRANSAKSI,
              "IDPERMINTAAN"   => $v->IDPERMINTAAN,
              "NOINDEXTAGIHAN" => $v->NOINDEXTAGIHAN,
              "BAYAR"          => $v->BAYAR,
              "BULANTAGIHAN"   => $v->BULANTAGIHAN,
              "FLAG"           => $v->FLAG,
            );
            $query = $this->update($this->cron, $data, $this->param); // table_name, data_insert , parameter_update.
             }
           }else{
            //jalankan function next
            $data  = array(
              "IDUNIQ"         => $v->IDUNIQ,
              "IDTRANSAKSI"    => $v->IDTRANSAKSI,
              "IDPERMINTAAN"   => $v->IDPERMINTAAN,
              "NOINDEXTAGIHAN" => $v->NOINDEXTAGIHAN,
              "BAYAR"          => $v->BAYAR,
              "BULANTAGIHAN"   => $v->BULANTAGIHAN,
              "FLAG"           => $v->FLAG,
            );
            $query = $this->update($this->cron, $data, $this->param); // table_name, data_insert , parameter_update.
           }
         }
          // update total start in tb_limitcron
         $data = array(
          'ID'    => "2",
          'START' => $start+$lenght,
          'BULAN' => date("Y-m-d"),
        );
          $query = $this->update($this->tb_nolimitcron, $data, $this->paramstart);// table_name, data_insert , parameter_update.
          $this->res(200, $query); // bisa data / query result.
        }
    //   } else{
    //   $this->res(404, 'Check your key!'); // bisa data / query result.
    // }
  }


  function keyActive(){
    $this->config->load('confcompany', TRUE);
    $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
    $curl = curl_init();
    $res = "".$urlgateway."/custom/Devices/getKeyDevice/key";
    curl_setopt_array($curl, array(
      CURLOPT_URL => $res,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    ));
    $response = curl_exec($curl); curl_close($curl);
    return $response = json_decode($response);
  }
  /*  CUSTOM = urlgateway*/
  function urlgateway(){
    $this->config->load('confcompany', TRUE);
    $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
    $curl = curl_init();
    $url = "".$urlgateway."/custom/Devices/getUrl_getway";
    curl_setopt_array($curl, array(
      CURLOPT_URL => $url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    ));
    $response = curl_exec($curl); curl_close($curl);
    return $response = json_decode($response);
  }
  /*  END CUSTOM = urlgateway*/

  public function ceknotivwa($idcek){
    $WHERE= "IDTRANSAKSI = '".$idcek."'";
    $sql = "SELECT notivwa FROM apikeuangan_buktitransaksitagihan
    WHERE $WHERE GROUP BY IDTRANSAKSI ";
    $query = $this->db->query($sql);
    $data = $query->row_array();
    if ($data['notivwa']>0) {
      return "next";
    }else {
      return "proses";
    }
  }

  //6281233929606

  public function getDatacron($start,$lenght){
    $sql = "SELECT c.*, p.IDPENGGUNA, p.NAMADEPAN, p.HP
    FROM apikeuangan_buktitransaksitagihan AS c
    JOIN biaya_tagihan AS bt on bt.IDPERMINTAAN=c.IDPERMINTAAN AND bt.IDBIAYA=c.IDTRANSAKSI
    JOIN pengguna as p on p.IDPENGGUNA=bt.IDPELANGGAN LIMIT ".$start.",".$lenght."";
    $query = $this->db->query($sql);
    $data = $query->result();
    $cek = $query->num_rows();
    if ($cek>0) {
      return $data;
    }else {
      return "null";
    }
  }

  public function checkstartlenght(){
    $sql = "SELECT tb.START , tb.LENGHT , tb.BULAN FROM tb_nolimitcron AS tb
    WHERE tb.ID=2";
    $query = $this->db->query($sql);
    $data = $query->row_array();
    return $data;
  }

  public function getDataPesan(){
    $sql = "SELECT p.TEMPLATEMESSAGE FROM wa_template_pesan as p
    WHERE p.ALIAS = 'notif-tagihan-bulanan'"; 
    $query = $this->db->query($sql);
    $data = $query->row_array();
    return $data;
  }



} ?>
