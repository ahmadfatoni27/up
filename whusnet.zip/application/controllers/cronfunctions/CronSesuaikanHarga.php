<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once APPPATH . '/core/MYController.php';

class CronSesuaikanHarga extends MYController
{
  protected $table = 'biaya_tagihan'; // this is table name.
  protected $param  = 'IDBIAYA'; // this is param delete.
  /**
  * This is default constructor of the class
  */
  public function __construct()
  {
    parent::__construct();
  }

  public function index() {
    $getDataTagihan = $this->getDataSesusaikanBiaya(); // from tb tagihan
    $dataTagihan = $getDataTagihan['data']; // from tb tagihan
    // hapus data by id uniq tagihan
    if ($dataTagihan == "datakosong") {
      $this->res(204); // bisa data query result.
    }else{
      foreach ($dataTagihan as $v) {

        $idpaket = $v->IDPAKET;
        $tglInser = $v->TGLINSERT;
        $totalbiayabaru = $v->HARGA + $v->BIAYAPASANG + $v->BIAYALAINLAIN;
        $cekbayarawal = $this->cekBayarAwal($v->IDPERMINTAAN);
        $totalbiayabarupelangganbaru = $this->GetTagihanAwal($idpaket,$tglInser) + $v->BIAYAPASANG + $v->BIAYALAINLAIN;
        $cekparam = array(
          "totalbiayabaru" => $totalbiayabaru,
          "totalbiayabarupelangganbaru" => $totalbiayabarupelangganbaru,
          "BIAYABULANAN" => $v->BIAYABULANAN,
          "BIAYAPASANG" => $v->BIAYAPASANG,
          "BIAYALAINLAIN" => $v->BIAYALAINLAIN,
          "HARGAPAKET" => $v->HARGA,
          "IDBIAYA" => $v->IDBIAYA,
        );
        // print_r($cekbayarawal);die();
        if ($cekbayarawal == 'dataada') {
          if ($v->BIAYABULANAN == $v->HARGA) {
            if ($v->TOTALBIAYA == $totalbiayabaru) {
              // echo "skip </br>";
              $this->res(200, true); // bisa data.
            } else {
              // echo "update biaya tagihan dan total biaya </br>";
              $data  = array(
                "IDBIAYA"  =>$v->IDBIAYA,
                "TOTALBIAYA"  =>$totalbiayabaru,
              );
              $query = $this->update($this->table, $data, $this->param); // table_name, data_insert , parameter_update.
            }
          } else {
            // echo "update biaya tagihan di biaya bulanan dan total biaya </br>";
            $data  = array(
              "IDBIAYA"  =>$v->IDBIAYA,
              "BIAYABULANAN"  =>$v->HARGA,
              "TOTALBIAYA"  =>$totalbiayabaru,
            );
            $query = $this->update($this->table, $data, $this->param); // table_name, data_insert , parameter_update.
          }
        } else {
          if ($v->BIAYABULANAN == $totalbiayabarupelangganbaru) {
            if ($v->TOTALBIAYA == $totalbiayabaru) {
              // echo "skip totalbiayabarupelangganbaru </br>";
              $this->res(200, true); // bisa data.
            } else {
              // echo "update biaya tagihan dan total biaya totalbiayabarupelangganbaru </br>";
              $data  = array(
                "IDBIAYA"  =>$v->IDBIAYA,
                "TOTALBIAYA"  =>$totalbiayabarupelangganbaru,
              );
              $query = $this->update($this->table, $data, $this->param); // table_name, data_insert , parameter_update.
            }
          } else {
            // echo "update biaya tagihan di biaya bulanan dan total biaya totalbiayabarupelangganbaru </br>";
            $data  = array(
              "IDBIAYA"  =>$v->IDBIAYA,
              "BIAYABULANAN"  =>$v->HARGA,
              "TOTALBIAYA"  =>$totalbiayabarupelangganbaru,
            );
            $query = $this->update($this->table, $data, $this->param); // table_name, data_insert , parameter_update.
          }
        }
      }
    }
  }


  public function getDataSesusaikanBiaya(){
    $sql = "SELECT bt.IDBIAYA, CONCAT(p.NAMADEPAN,p.NAMABELAKANG) as NAMAPELANGGAN, p.KOTA , p.KEC , p.DESA , p.HP , p.ALMT , bt.BIAYAPASANG , bt.BIAYABULANAN ,
    bt.BIAYALAINLAIN , bt.TOTALBIAYA , p.FOTO, pw.IDPAKET, pk.HARGA,bt.IDPERMINTAAN, bt.TGLINSERT
    FROM biaya_tagihan as bt
    JOIN pengguna as p on p.IDPENGGUNA=bt.IDPELANGGAN
    JOIN prosedure_permintaan_wifi as pw on pw.IDPENGGUNA=p.IDPENGGUNA and pw.IDBIAYA=bt.IDBIAYA
    JOIN paket as pk on pk.KODEPAKET=pw.IDPAKET";
    $query = $this->db->query($sql);
    $data = $query->result();
    $count = $query->num_rows();
    if ($count>0) {
      $res = array(
        "data" => $data,
        "count" => $count,
      );
      return $res;
    }else {
      return "datakosong";
    }
  }


  public function cekBayarAwal($IDTRANSAKSI){
    $sql = "SELECT b.IDPERMINTAAN FROM apikeuangan_buktitransaksipemasangan as b WHERE b.IDPERMINTAAN='".$IDTRANSAKSI."'";
    $query = $this->db->query($sql);
    $count = $query->num_rows();
    if ($count>0) {
      return "dataada";
    }else {
      return "datakosong";
    }
  }

  public function GetTagihanAwal($idpaket , $tglInser) {
		$CI = get_instance();
		$CI->load->model('HelperModel');
		$Idpaket = $idpaket;
    $tglInser = $tglInser;
		$Getpaket = $CI->HelperModel->getdatapaket($Idpaket);
		$Hargapaket = $Getpaket['HARGA'];

    $timestamp = strtotime($tglInser);

    // --------------- RUMUS ----------------------
		$checkdate = date("Y/m/d", $timestamp);
		// $checkdate = "2024/02/29";
		$Y = date("Y", $timestamp);
		// $Y = "2024";
		$M = date("m", $timestamp);
		// $M = '02';
		$datenow = date("d", $timestamp);
		// $datenow = "29";
		// get next day
		$getnextday = date('Y/m/d',strtotime('+1 days',strtotime($checkdate))) . PHP_EOL;
		$nextday = substr($getnextday,8);
		// get jumlah tgl bulan ini
		$jumlah_tgl_bulan_ini=cal_days_in_month(CAL_GREGORIAN,$M,$Y);
		//  get harga paket perhari
		$Perharipaket=$Hargapaket/$jumlah_tgl_bulan_ini;
		//  get sisa hari ketika pemasangan wifi
		$Totalbiaya=($jumlah_tgl_bulan_ini-$datenow);
		if ($nextday == 01) {
			//  jika hari esok sudah tgl 1
			$Sisabiayapaket=$Perharipaket*1;
		} else {
			//  jika hari esok belum tgl 1
			$Sisabiayapaket = $Totalbiaya*$Perharipaket;
		}
		// --------------- END RUMUS ----------------------
		return round($Sisabiayapaket);
	}






} ?>
