<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once APPPATH . '/core/MYController.php';

class CronTagihanBulanan extends MYController
{
  protected $cron               = 'apikeuangan_buktitransaksitagihan'; // this is table name.
  protected $tb_nolimitcron     = 'tb_nolimitcron'; 		// this is table name.
  protected $param              = 'IDUNIQ';             // this is parameter update table.
  protected $paramstart         = 'ID'; 			      // this is parameter update table.
  protected $biaya_tagihan      = 'biaya_tagihan'; 			      // this is parameter update table.
  protected $parambiaya_tagihan = 'IDBIAYA'; 			      // this is parameter update table.


  /**
  * This is default constructor of the class
  */
  public function __construct()
  {
    parent::__construct();
  }

  public function index() {
    // insert table with auto.
    $keyValue   = $this->input->post('key');
    $check      = $this->checkKey($keyValue);
    // print_r($check);
    // die();
    // check bulan hari ini dan bulan pada tb limit cron
    // get month
    $checkbulan = $this->checkstartlenght(); // from tb_nolimitcron
    $checkbulan = $checkbulan["BULAN"];
    $checkbulan = explode("-",$checkbulan);
    $checkbulan = $checkbulan[1];
    // end get month
    $now = date("m"); // month now.

    if ($checkbulan !== $now) {
      echo "bulan tidak sama maka harus update";
      $data = array(
        'ID'    => "1",
        'START' => 1,
        'BULAN' => date("Y-m-d"),
      );
      $query = $this->update($this->tb_nolimitcron, $data, $this->paramstart); // table_name, data_insert , parameter_update.
      $this->res(200, 'start data is reseted!'); die(); // bisa data / query result.
    }

    if($check === true){
      $checkstartlenght = $this->checkstartlenght(); // from tb_nolimitcron
      $start            = $checkstartlenght["START"];
      $lenght           = $checkstartlenght["LENGHT"];
      $bulantblimit     = $checkstartlenght["BULAN"];
      $datainputwuqry = $this->getDatacron($start,$lenght);
      $date = date("Y-m-d H:i:s");
      if ($datainputwuqry=="null") {
        $this->res(204); // bisa data / query result.
      }else {
        foreach ($datainputwuqry as $v) {
          $idcek           = $v->IDTRANSAKSI;
          $bayartotal      = $this->bayartotal($idcek);
          $bayarbulanan    = $this->bayarbulanan($idcek);
          // print_r($bayartotal);die();
          $explode         = explode("-",$v->BULANTAGIHAN);
          $cekbulanhariini = date("m");
          $cekbulantagihan = $explode[1];
          $bayarpemasangan = $this->bayarpemasangan($idcek);
          $cekbulantagihanterakhir = $this->cekbulantagihanterakhir($idcek,$cekbulanhariini);
          if ($cekbulantagihanterakhir!="next") {
            if ($bayarpemasangan == "belumbayar") { //pengecekan bukti transaksi pemasangan awal
              if ($v->FLAG == 0) {
                $data  = array(
                  "IDUNIQ"         => uniqid(),
                  "IDTRANSAKSI"    => $v->IDTRANSAKSI,
                  "IDPERMINTAAN"   => $v->IDPERMINTAAN,
                  "NOINDEXTAGIHAN" => $v->JUM,
                  "BAYAR"          => $bayarbulanan['BIAYABULANAN'],
                  "BULANTAGIHAN"   => $date,
                  "FLAG"           => "0",
                );
                $query = $this->insert($this->cron, $data); // table_name, data_insert.
                $dataupdatebiayatagihan = array(
                  "IDBIAYA"     => $v->IDTRANSAKSI,
                  "BIAYABULANAN"=> $bayarbulanan['BIAYABULANAN'],
                );
                $query = $this->update($this->biaya_tagihan, $dataupdatebiayatagihan, $this->parambiaya_tagihan); // table_name, data_insert , parameter_update.
              }else {
                $data  = array(
                  "IDUNIQ"         => $v->IDUNIQ,
                  "IDTRANSAKSI"    => $v->IDTRANSAKSI,
                  "IDPERMINTAAN"   => $v->IDPERMINTAAN,
                  "NOINDEXTAGIHAN" => "0",
                  "BAYAR"          => $bayarbulanan['BIAYABULANAN'],
                  "BULANTAGIHAN"   => $date,
                  "FLAG"           => "0",
                );
                $query = $this->update($this->cron, $data, $this->param); // table_name, data_insert , parameter_update.
                $dataupdatebiayatagihan = array(
                  "IDBIAYA"     => $v->IDTRANSAKSI,
                  "BIAYABULANAN"=> $bayarbulanan['BIAYABULANAN'],
                );
                $query = $this->update($this->biaya_tagihan, $dataupdatebiayatagihan, $this->parambiaya_tagihan); // table_name, data_insert , parameter_update.
              }
            }
            if ($bayarpemasangan == "sudahbayar"){ //pengecekan bukti transaksi pemasangan awal
              if ($v->FLAG == 0) { // FLAG 0 = belum bayar
                $data  = array(
                  "IDUNIQ"         => uniqid(),
                  "IDTRANSAKSI"    => $v->IDTRANSAKSI,
                  "IDPERMINTAAN"   => $v->IDPERMINTAAN,
                  "NOINDEXTAGIHAN" => $v->JUM, // auto menambahkan 1 = artinya tambah  tunggakan
                  "BAYAR"          => $bayarbulanan['BIAYABULANAN'],
                  "BULANTAGIHAN"   => $date,
                  "FLAG"           => "0",
                );
                $query = $this->insert($this->cron, $data); // table_name, data_insert.
                $dataupdatebiayatagihan = array(
                  "IDBIAYA"     => $v->IDTRANSAKSI,
                  "BIAYABULANAN"=> $bayarbulanan['BIAYABULANAN'],
                );
                $query = $this->update($this->biaya_tagihan, $dataupdatebiayatagihan, $this->parambiaya_tagihan); // table_name, data_insert , parameter_update.
              }else {
                $data  = array(
                  "IDUNIQ"         => $v->IDUNIQ,
                  "IDTRANSAKSI"    => $v->IDTRANSAKSI,
                  "IDPERMINTAAN"   => $v->IDPERMINTAAN,
                  "NOINDEXTAGIHAN" => "0",
                  "BAYAR"          => $bayarbulanan['BIAYABULANAN'],
                  "BULANTAGIHAN"   => $date,
                  "FLAG"           => "0",
                );
                $query = $this->update($this->cron, $data, $this->param); // table_name, data_insert , parameter_update.
                $dataupdatebiayatagihan = array(
                  "IDBIAYA"     => $v->IDTRANSAKSI,
                  "BIAYABULANAN"=> $bayarbulanan['BIAYABULANAN'],
                );
                $query = $this->update($this->biaya_tagihan, $dataupdatebiayatagihan, $this->parambiaya_tagihan); // table_name, data_insert , parameter_update.
              }
            }
          }else {
            $data  = array(
              "IDUNIQ"         => $v->IDUNIQ,
              "IDTRANSAKSI"    => $v->IDTRANSAKSI,
              "IDPERMINTAAN"   => $v->IDPERMINTAAN,
              "NOINDEXTAGIHAN" => $v->NOINDEXTAGIHAN,
              "BAYAR"          => $v->BAYAR,
              "BULANTAGIHAN"   => $v->BULANTAGIHAN,
              "FLAG"           => $v->FLAG,
            );
            $query = $this->update($this->cron, $data, $this->param); // table_name, data_insert , parameter_update.
          }
        }
        // update total start in tb_limitcron
         $data = array(
          'ID'    => "1",
          'START' => $start+$lenght,
          'BULAN' => date("Y-m-d"),
        );
        $query = $this->update($this->tb_nolimitcron, $data, $this->paramstart); // table_name, data_insert , parameter_update.
        $this->res(200, $query); // bisa data / query result.
      }
    } else{
      $this->res(404, 'Check your key!'); // bisa data / query result.
    }
  }



  public function cekbulantagihanterakhir($idcek,$cekbulanhariini){
    $WHERE= "IDTRANSAKSI = '".$idcek."' and MONTH(INSERTED_AT) = ".$cekbulanhariini."";
    $sql = "SELECT * FROM apikeuangan_buktitransaksitagihan
    WHERE $WHERE GROUP BY IDTRANSAKSI ";
    $query = $this->db->query($sql);
    $data = $query->row_array();
    if ($data>1) {
      return "next";
    }else {
      return "proses";
    }
  }
  public function getDatacron($start,$lenght){
    $sql = "SELECT c.*, COUNT(c.NOINDEXTAGIHAN) AS JUM
    FROM apikeuangan_buktitransaksitagihan AS c
    join prosedure_permintaan_wifi as pw on c.IDPERMINTAAN=pw.IDPERMINTAAN
    where pw.JENISMEMBER='0' and pw.IDPERMINTAAN = 'RQ000247'
    GROUP BY c.IDTRANSAKSI ORDER BY `BULANTAGIHAN` DESC LIMIT ".$start.",".$lenght."";
    // $sql = "SELECT c.*, COUNT(c.NOINDEXTAGIHAN) AS JUM FROM apikeuangan_buktitransaksitagihan AS c
    // GROUP BY c.IDTRANSAKSI ORDER BY `BULANTAGIHAN` DESC LIMIT ".$start.",".$lenght."";
    $query = $this->db->query($sql);
    $data = $query->result();
    $cek = $query->num_rows();
    if ($cek>0) {
      return $data;
    }else {
      return "null";
    }
  }
  public function bayarpemasangan($idcek){
    $sql = "SELECT c.IDPERMINTAAN, c.TGLBAYAR
    FROM apikeuangan_buktitransaksipemasangan AS c
    WHERE c.IDPERMINTAAN='".$idcek."'";
    $query = $this->db->query($sql);
    $data = $query->row_array();
    if ($data>0) {
      return "sudahbayar";
    }else {
      return "belumbayar";
    }
  }
  public function bayarbulanan($idcek){
    $sql = "SELECT p.HARGA as BIAYABULANAN
    FROM biaya_tagihan AS c
    JOIN prosedure_permintaan_wifi as pp on  c.IDPERMINTAAN = pp.IDPERMINTAAN
    JOIN paket as p on  p.KODEPAKET = pp.IDPAKET
    WHERE c.IDBIAYA='".$idcek."'";
    $query = $this->db->query($sql);
    $data = $query->row_array();
    // print_r($data);die();
    return $data;
  }
  public function bayartotal($idcek){
    $sql = "SELECT c.TOTALBIAYA FROM biaya_tagihan AS c
    WHERE c.IDBIAYA='".$idcek."'";
    $query = $this->db->query($sql);
    $data = $query->row_array();
    return $data;
  }
  public function checkstartlenght(){
    $sql = "SELECT tb.START , tb.LENGHT , tb.BULAN FROM tb_nolimitcron AS tb
    WHERE tb.ID=1";
    $query = $this->db->query($sql);
    $data = $query->row_array();
    return $data;
  }
  // public function resettblimit($resettblimit){
  //   $explode=explode("-",$resettblimit);
  //   $now = date("m");
  //   $bulantblimit = $explode[1];
  //   if ($bulantblimit != $now) {
  //     $data = array(
  //       'ID'    => "1",
  //       'START' => 1,
  //       'BULAN' => date("Y-m-d"),
  //     );
  //     $query = $this->update($this->tb_nolimitcron, $data, $this->paramstart); // table_name, data_insert , parameter_update.
  //   }else {
  //     return false;
  //   }
  // }




  public function getData(){
    // $data = array(
    //   'start' 	=> $_POST['start'],
    //   'length' 	=> $_POST['length'],
    //   'filtervalue' => $_POST['filtervalue'],
    //   'filtertext' 	=> $_POST['filtertext']
    // );
    $query = $this->query('c.id', 'cron AS c', '');
    $queryAll = $query;    	// select_field, table_name, where_data
    $sql      = $query;			    // select_field, table_name, where_data
    echo $this->resDataAll($queryAll, $sql);
  }

  public function getDataSelect()
  {
    $sql = $this->query('*', 'cron', 'id='.$_POST['id'].'');
    echo $this->resultSelect($sql);
  }




} ?>
