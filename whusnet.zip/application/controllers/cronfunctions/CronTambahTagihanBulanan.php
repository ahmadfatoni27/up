<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once APPPATH . '/core/MYController.php';

class CronTambahTagihanBulanan extends MYController
{
  protected $cron           = 'apikeuangan_buktitransaksitagihan'; // this is table name.
  protected $cronfrom       = 'biaya_tagihan'; // this is table name.
  protected $param          = 'IDBIAYA';             // this is parameter update table.
  protected $tb_nolimitcron = 'tb_nolimitcron'; 		// this is table name.
  protected $paramstart     = 'ID'; 			      // this is parameter update table.
  /**
  * This is default constructor of the class
  */
  public function __construct()
  {
    parent::__construct();
  }

  public function index() {
    $checkbulan = $this->checkstartlenght(); // from tb_nolimitcron
    $checkbulan = $checkbulan["BULAN"];
    $checkbulan = explode("-",$checkbulan);
    $checkbulan = $checkbulan[1];
    $now = date("m"); // month now.

    if ($checkbulan !== $now) {
      echo "bulan tidak sama maka harus update";
      $data = array(
        'ID'    => "5",
        'START' => 0,
        'BULAN' => date("Y-m-d"),
      );
      $query = $this->update($this->tb_nolimitcron, $data, $this->paramstart); // table_name, data_insert , parameter_update.
      $this->res(200, 'start data is reseted!'); die(); // bisa data / query result.
    }

    $checkstartlenght = $this->checkstartlenght(); // from tb_nolimitcron
    $start            = $checkstartlenght["START"];
    $lenght           = $checkstartlenght["LENGHT"];
    $bulantblimit     = $checkstartlenght["BULAN"];
    $dataquery        = $this->getDatacron($start,$lenght);
    $datainputquery   = $dataquery['data'];
    $counttotal       = $dataquery['count'];
    $sisacount        = $lenght-$counttotal;
    // print_r($sisacount);die();
    // $date             = date("Y-m-d H:i:s");

    if ($datainputquery=="null") {
      $this->res(204); // bisa data / query result.
    }else {
      foreach ($datainputquery as $v) {
        $idcek=$v->IDPERMINTAAN;
        $cek  = $this->cekData($idcek);
        $cekBiayaAwal  = $this->cekDataBiayaAwal($idcek);
        $tgl  = $v->TGLINSERT;
        $date = substr($tgl,0,10);
        // print_r($date);die();
        if ($cek=="belumada") {
          if ($cekBiayaAwal=="belumada") {
            $data  = array(
              "IDUNIQ"        =>uniqid(),
              "IDTRANSAKSI"   =>$v->IDBIAYA,
              "IDPERMINTAAN"  =>$v->IDPERMINTAAN,
              "NOINDEXTAGIHAN"=>"0",
              "BAYAR"         =>$v->TOTALBIAYA,
              "BULANTAGIHAN"  =>$date,
              "FLAG"          =>"0",
              "notivwa"       =>"0",
            );
          } else {
            $data  = array(
              "IDUNIQ"        =>uniqid(),
              "IDTRANSAKSI"   =>$v->IDBIAYA,
              "IDPERMINTAAN"  =>$v->IDPERMINTAAN,
              "NOINDEXTAGIHAN"=>"0",
              "BAYAR"         =>$v->BIAYABULANAN,
              "BULANTAGIHAN"  =>$date,
              "FLAG"          =>"0",
              "notivwa"       =>"0",
            );
          }
          $query = $this->insert($this->cron, $data); // table_name, data_insert.
        }else {
          // skip
          $data  = array(
            "IDBIAYA"       =>$v->IDBIAYA,
            "IDPERMINTAAN"  =>$v->IDPERMINTAAN,
          );
          $query = $this->update($this->cronfrom, $data, $this->param); // table_name, data_insert , parameter_update.
        }
      }
      // update total start in tb_limitcron
      if ($sisacount!=0) {
       $data = array(
        'ID'    => "5",
        'START' => $start+$counttotal,
        'BULAN' => date("Y-m-d"),
      );
     }else{
       $data = array(
        'ID'    => "5",
        'START' => $start+$lenght,
        'BULAN' => date("Y-m-d"),
      );
     }
      $query = $this->update($this->tb_nolimitcron, $data, $this->paramstart); // table_name, data_insert , parameter_update.
      $this->res(200, $query); // bisa data / query result.
    }
  }




  public function getDatacron($start,$lenght){
    $sql = "SELECT c.*
    FROM biaya_tagihan AS c
    join prosedure_permintaan_wifi as p on p.IDPERMINTAAN=c.IDPERMINTAAN
    where p.STATUS = 'ACTIVE' and p.STATUSPASANG = 'Berhasil'
    LIMIT ".$start.",".$lenght."";
    $query = $this->db->query($sql);
    $data = $query->result();
    $count = $query->num_rows();
    if ($count>0) {
      $res = array(
        "data" => $data,
        "count" => $count,
      );
      return $res;
    }else {
      return "null";
    }
  }


  public function checkstartlenght(){
    $sql = "SELECT tb.START , tb.LENGHT , tb.BULAN FROM tb_nolimitcron AS tb
    WHERE tb.ID=5";
    $query = $this->db->query($sql);
    $data = $query->row_array();
    return $data;
  }

  public function cekData($idcek){
    $where = "c.IDTRANSAKSI='".$idcek."'";
    $sql = "SELECT c.*
    FROM apikeuangan_buktitransaksitagihan AS c
    where $where";
    $query = $this->db->query($sql);
    $cek = $query->num_rows();
    if ($cek>0) {
      return "datasudahada";
    }else {
      return "belumada";
    }
  }

  public function cekDataBiayaAwal($idcek){
    $where = "c.IDPERMINTAAN='".$idcek."'";
    $sql = "SELECT c.*
    FROM apikeuangan_buktitransaksipemasangan AS c
    where $where";
    $query = $this->db->query($sql);
    $cek = $query->num_rows();
    if ($cek>0) {
      return "datasudahada";
    }else {
      return "belumada";
    }
  }








  public function getData(){
    // $data = array(
    //   'start' 	=> $_POST['start'],
    //   'length' 	=> $_POST['length'],
    //   'filtervalue' => $_POST['filtervalue'],
    //   'filtertext' 	=> $_POST['filtertext']
    // );
    $query = $this->query('c.id', 'cron AS c', '');
    $queryAll = $query;    	// select_field, table_name, where_data
    $sql      = $query;			    // select_field, table_name, where_data
    echo $this->resDataAll($queryAll, $sql);
  }

  public function getDataSelect()
  {
    $sql = $this->query('*', 'cron', 'id='.$_POST['id'].'');
    echo $this->resultSelect($sql);
  }




} ?> 
