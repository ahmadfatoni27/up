<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once APPPATH . '/core/MYController.php';

class CronUpdateBukti extends MYController
{
  protected $cron           = 'apikeuangan_buktitransaksipemasangan'; // this is table name.
  protected $cronskip       = 'prosedure_permintaan_wifi'; // this is table name.
  protected $param          = 'IDPERMINTAAN';             // this is parameter update table.
  protected $tb_nolimitcron = 'tb_nolimitcron'; 		// this is table name.
  protected $paramstart     = 'ID'; 			      // this is parameter update table.
  /**
  * This is default constructor of the class
  */
  public function __construct()
  {
    parent::__construct();
  }

  public function index() {
    $checkbulan = $this->checkstartlenght(); // from tb_nolimitcron
    $checkbulan = $checkbulan["BULAN"];
    $checkbulan = explode("-",$checkbulan);
    $checkbulan = $checkbulan[1];
    $now = date("m"); // month now.

    if ($checkbulan !== $now) {
      echo "bulan tidak sama maka harus update";
      $data = array(
        'ID'    => "6",
        'START' => 0,
        'BULAN' => date("Y-m-d"),
      );
      $query = $this->update($this->tb_nolimitcron, $data, $this->paramstart); // table_name, data_insert , parameter_update.
      $this->res(200, 'start data is reseted!'); die(); // bisa data / query result.
    }

    $checkstartlenght = $this->checkstartlenght(); // from tb_nolimitcron
    $start            = $checkstartlenght["START"];
    $lenght           = $checkstartlenght["LENGHT"];
    $bulantblimit     = $checkstartlenght["BULAN"];
    $dataquery        = $this->getDatacron($start,$lenght);

    // print_r($datainputquery);die();
    if ($dataquery=="null") {
      $this->res(204); // bisa data / query result.
    }else {
      $datainputquery   = $dataquery['data'];
      $counttotal       = $dataquery['count'];
      $sisacount        = $lenght-$counttotal;
      foreach ($datainputquery as $v) {
        $idcek=$v->IDPERMINTAAN;
        $cek  = $this->cekData($idcek);
        if ($cek=="belumada") {
          $data  = array(
            "IDPERMINTAAN"  =>$v->IDPERMINTAAN,
          );
          $query = $this->insert($this->cron, $data); // table_name, data_insert.
        }else {
          // skip
          $data  = array(
            "IDPERMINTAAN"  =>$v->IDPERMINTAAN,
          );
          $query = $this->update($this->cronskip, $data, $this->param); // table_name, data_insert , parameter_update.
        }
      }
      // update total start in tb_limitcron
      if ($sisacount!=0) {
        $data = array(
          'ID'    => "6",
          'START' => $start+$counttotal,
          'BULAN' => date("Y-m-d"),
        );
      }else{
        $data = array(
          'ID'    => "6",
          'START' => $start+$lenght,
          'BULAN' => date("Y-m-d"),
        );
      }
      $query = $this->update($this->tb_nolimitcron, $data, $this->paramstart); // table_name, data_insert , parameter_update.
      $this->res(200, $query); // bisa data / query result.
    }
  }




  public function getDatacron($start,$lenght){
    $sql = "SELECT pw.IDPERMINTAAN, pw.IDPENGGUNA, concat(pk.NAMA_PAKET,' - ', fRupiah(pk.HARGA)) as NAMA_PAKET, p.NAMADEPAN as PELANGGAN,
    REPLACE(p.NAMADEPAN, '-', ' ') as NAMA_LENGKAP, p.NAMABELAKANG, p.TLP, p.HP, p.ALMT, p.EMAIL, p.KOTA, p.KEC, p.DESA, pw.STATUSPASANG, pw.UBAHKONEKSI,
    pw.STATUSALAT, pw.JENISJARINGAN, lp.IPADDR
    FROM prosedure_permintaan_wifi AS pw
    JOIN paket AS pk ON pw.IDPAKET=pk.KODEPAKET
    JOIN pengguna AS p ON pw.IDPENGGUNA=p.IDPENGGUNA
    JOIN laporan_pemasangan_wifi AS lp ON lp.IDPENGGUNA=pw.IDPENGGUNA
    where pw.`STATUS`='ACTIVE' LIMIT ".$start.",".$lenght."";
    // print_r($sql);die();
    $query = $this->db->query($sql);
    $data = $query->result();
    $count = $query->num_rows();
    if ($count>0) {
      $res = array(
        "data" => $data,
        "count" => $count,
      );
      return $res;
    }else {
      return "null";
    }
  }
  public function checkstartlenght(){
    $sql = "SELECT tb.START , tb.LENGHT , tb.BULAN FROM tb_nolimitcron AS tb
    WHERE tb.ID=6";
    $query = $this->db->query($sql);
    $data = $query->row_array();
    return $data;
  }
  public function cekData($idcek){
    $where = "c.IDPERMINTAAN='".$idcek."'";
    $sql = "SELECT c.*
    FROM apikeuangan_buktitransaksipemasangan AS c
    where $where";
    $query = $this->db->query($sql);
    $cek = $query->num_rows();
    if ($cek>0) {
      return "datasudahada";
    }else {
      return "belumada";
    }
  }


}?>
