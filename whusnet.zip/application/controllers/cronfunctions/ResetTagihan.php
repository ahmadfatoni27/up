<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once APPPATH . '/core/MYController.php';

class ResetTagihan extends MYController
{
  protected $tableReset1 = 'apikeuangan_buktitransaksitagihan'; // this is table name.
  protected $tableReset2 = 'apikeuangan_buktitransaksiterkumpul'; // this is table name.
  protected $paramReset  = 'IDTRANSAKSI'; // this is param delete.
  /**
  * This is default constructor of the class
  */
  public function __construct()
  {
    parent::__construct();
  }

  public function index() {
    // get data tagihan by flag != 2
    $getDataTagihan = $this->getDataTagihan(); // from tb tagihan
    $dataTagihan = $getDataTagihan['data']; // from tb tagihan
    // hapus data by id uniq tagihan
    if ($dataTagihan == "datakosong") {
      $this->res(204); // bisa data / query result.
    }else{
      foreach ($dataTagihan as $v) {
        $id = $v->IDTRANSAKSI;
        $cektable1 = $this->Cekdatatable1($id);
        $cektable2 = $this->Cekdatatable2($id);
        $hasilcektable = array(
          'cektable1' => $cektable1,
          'cektable2' => $cektable2,
         );
        // print_r($hasilcektable);die();
        $data = array('IDTRANSAKSI' => $id);
        if ($cektable1=="ok" && $cektable2=="ok") {
          // echo "delete 2 table </br>";
          $query = $this->deletemulti($this->tableReset1, $this->tableReset2, $data, $this->paramReset); // table_name, data_insert , parameter_update.
        } elseif ($cektable1=="ok" && $cektable2=="tidakada") {
          // echo "delete table apikeuangan_buktitransaksitagihan </br>";
          $query = $this->delete($this->tableReset1, $data, $this->paramReset); // table_name, data_insert , parameter_update.
        } else {
          // echo "delete table apikeuangan_buktitransaksiterkumpul </br>";
          $query = $this->delete($this->tableReset2, $data, $this->paramReset); // table_name, data_insert , parameter_update.
        }
      }
    }
  }


  public function getDataTagihan(){
    $sql = "SELECT c.*
    FROM apikeuangan_buktitransaksitagihan AS c
    where c.FLAG = '1' or c.FLAG = '0' GROUP BY c.IDTRANSAKSI";
    $query = $this->db->query($sql);
    $data = $query->result();
    $count = $query->num_rows();
    if ($count>0) {
      $res = array(
        "data" => $data,
        "count" => $count,
      );
      return $res;
    }else {
      return "datakosong";
    }
  }

  public function Cekdatatable1($id){
    $sql = "SELECT tb1.IDTRANSAKSI FROM apikeuangan_buktitransaksitagihan AS tb1 WHERE tb1.IDTRANSAKSI = '".$id."'";
    $query = $this->db->query($sql);
    $count = $query->num_rows();
    if ($count>0) {
      return "ok";
    } else {
      return "tidakada";
    }

  }

  public function Cekdatatable2($id){
    $sql = "SELECT tb1.IDTRANSAKSI FROM apikeuangan_buktitransaksiterkumpul AS tb1 WHERE tb1.IDTRANSAKSI = '".$id."'";
    $query = $this->db->query($sql);
    $count = $query->num_rows();
    if ($count>0) {
      return "ok";
    } else {
      return "tidakada";
    }

  }





} ?>
