<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class TestCron extends CI_Controller 
{
  protected $cron = 'cron'; 			// this is table name.
  protected $key = '53nh46u74m3nt3';	// key cronjob.
    /**
     * This is default constructor of the class
     */
   public function __construct()
   {
     parent::__construct();
   }

    public function index()
    {
      // insert table with auto.
      $keyValue = $this->input->post('key');
      $check 	= $this->checkKey($keyValue);
       if($check === true)
        {
            $data  = array( 
              "name" => uniqid(), // variable data insert
            );
         	$query = $this->insert($this->cron, $data); // table_name, data_insert.
		    echo $res = $this->res(200);
        }
        else
        {
		    echo $res = $this->res(404);
        }
    }
    
  
  
  
  
  public function getData(){
   // $data = array(
   //   'start' 	=> $_POST['start'],
   //   'length' 	=> $_POST['length'],
   //   'filtervalue' => $_POST['filtervalue'],
   //   'filtertext' 	=> $_POST['filtertext']
   // );
    
   	$queryAll = $this->query('*', 'cron', '');    	// select_field, table_name, where_data
   	$sql = $this->query('*', 'cron', ''); 			// select_field, table_name, where_data
    
	echo $this->resDataAll($queryAll, $sql);
  }
  
  public function getDataSelect(){
    $sql = $this->query('*', 'cron', 'id='.$_POST['id'].'');
    echo $this->resultSelect($sql);
  }
  
  //function do_update() {
  // $data  = array(
  // 	"name" 	  => $_POST['name'], 
  // 	"command" => $_POST['command']  
  // );
  //  
  // $set = array(
  //   'table' => $this->cron, 
  //    'field' => "id", 
  //    'value' => $_POST['id']
  // );
  // $set = var_dump($set);
  //  echo $this->update($data, $set);
  // }
  
  
  
  
  
  
  
  
  // CUSTOM CONTROLLERS ON CLASS EXTENDS
   protected function checkKey($keyValue=''){
     	$key = $this->key;
   		$res = password_verify($key, $keyValue);
     	if($key === $keyValue){
        	return true;
        } else { return false; }
   }
   
   protected function res( $code = '' ) {
     if( $code === 200 ) { // if res_code = 200
         $response = array('code' => 200, 'status' => 'true', 'info' => 'success');
         $res = array('res' => $response);
         return json_encode($res);
     }
     if( $code === REST_Controller::HTTP_NOT_FOUND ) { // if res_code = 404
         $response = array('code' => REST_Controller::HTTP_NOT_FOUND, 'status' => 'false', 'info' => 'not allowed');
         $res = array('res' => $response);
         return json_encode($res);
     }
   }
  
  protected function insert($table, $data){
  		return $this->db->insert($table, $data);
  }
 // function update($set, $data){
 //   	$f = 'id'; $v = '4'; $t = $table;
  //  	$this->db->where($f, $v);
  //  	$query = $this->db->update($t, $data);
  //  	return $query;
//	}
  
  protected function query($select, $table, $where){
    	if($where == ""){ $where = ''; } else { $where = "WHERE ".$where; }
  		return $sql = $this->db->query("SELECT ".$select." FROM ".$table.' '.$where);
  }
  
  protected function resDataAll($sql, $queryAll) {
   	$data = $sql->result();
	$total = $queryAll->num_rows();
   	$dataRecord = array(
			"RecordsTotal" => $total,
			"RecordsFiltered" => $total,
			"Data" => $data,
	); 
    return $res = json_encode( $dataRecord ); 
  }
  
 	protected function resultSelect($sql){
		$res = $sql->result(); return json_encode($res = array('res'=>$res));
	}
  

  
  
  
  
/*

CREATE TABLE `cron` (
  `id` int(5) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `command` varchar(255) NOT NULL,
  `interval_sec` int(10) NOT NULL,
  `last_run_at` timestamp NULL DEFAULT current_timestamp(),
  `next_run_at` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `cron`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `cron`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;
COMMIT;

*/
  
  
  
  
  
  
} ?>





