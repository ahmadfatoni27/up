<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

require_once APPPATH . '/core/MYController.php';

class TestCron_now extends MYController 
{
  protected $cron = 'cron'; 			    // this is table name.
  protected $key = '53nh46u74m3nt3';	// key cronjob.
    /**
     * This is default constructor of the class
     */
   public function __construct()
   {
     parent::__construct();
   }

    public function index()
    {
      // insert table with auto.
      $keyValue = $this->input->post('key');

      $check 	= $this->checkKey($keyValue);

       if($check === true)
        {
            $data  = array( 
              "name" => uniqid(), // variable data insert
            );

         	$query = $this->insert($this->cron, $data); // table_name, data_insert.

		      $this->res(200, $query); // bisa data / query result. 

        } 
        else 
        {

		      $this->res(404, $query); // bisa data / query result. 

        }
    }
    
  
  
  
  
  public function getData(){
   // $data = array(
   //   'start' 	=> $_POST['start'],
   //   'length' 	=> $_POST['length'],
   //   'filtervalue' => $_POST['filtervalue'],
   //   'filtertext' 	=> $_POST['filtertext']
   // );
    $query = $this->query('c.id', 'cron AS c', '');
   	$queryAll = $query;    	// select_field, table_name, where_data
   	$sql      = $query;			    // select_field, table_name, where_data
    
	   echo $this->resDataAll($queryAll, $sql);
  }
  
  public function getDataSelect()
  {

    $sql = $this->query('*', 'cron', 'id='.$_POST['id'].'');

    echo $this->resultSelect($sql);

  }

  
   
  
} ?>





