<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Controll_newUser_registration extends CI_Controller
{

  function __construct(){
		parent::__construct();
		// $this->load->helper(array('login','configsession','my'));cek_login();
		// $this->load->model('master/M__merk','model');
	}

	function index(){
		$data['title'] = "Form Pendaftaran Pengguna Baru";
		// print session = $session['sessionName']; sessionname in configsession_helper file.
		// $data['session']= session();
		$this->template->load('customersApp/_templateCustomersApp', 'customersApp/@newuser_registration', $data);
	}



}
?>
