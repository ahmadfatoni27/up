<?php
/**
 * @Author: Arif Efendi - Kazuya Media Indonesia
 * @Date:   2021-08-12 20:09:31
 * @Last Modified by:   kazuya
 * @Last Modified time: 2021-08-26 11:19:21
 */
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_riwayatTiketGagal extends CI_Controller
{
  function __construct() {
    parent::__construct();
    $this->load->helper(array('login','configsession','my')); cek_login();
    $this->load->model('gangguan/M__tiketriwayat','model');
  }
  function index()
  {
    $data['title'] = "Data Tambah Riwayat Tiket Gagal";
    $data['session']= session();
    $this->template->load('_template', 'gangguan/@_dataTiketRiwayatGagal',$data);
  }
  function getData()
  {
    $data = array(
      'start' => $_POST['start'],
      'length' => $_POST['length'],
      'filtervalue' => $_POST['filtervalue'],
      'filtertext' => $_POST['filtertext']);
    $res = $this->model->getDataAll_gagal($data); echo json_encode($res);
  }
  function getDataSelect() {
    $res = $this->model->getSelectConfirmGagalId($_POST['id']); echo json_encode($res);
  }
  function confirm(){
    $data = json_decode(file_get_contents('php://input'), true);
    $dataapi = array(
      'apikey'     => $data['apikey'],
      'nomorsender'=> $data['nomorsender'],
      'nomor'      => $data['HP'],
      'message'    => $data['TEMPLATEMESSAGEWA'],
    );
    $data = array(
      'NOTIKET'    => $data['NOTIKET'],
      'KONFIRMASI' => "1",
    );
    $api_key = $dataapi['apikey'];
    $sender = $dataapi['nomorsender'];
    $number = $dataapi['nomor'];
    $message = $dataapi['message'];
    // print_r($message);die();
    kirimPesanwaTes($api_key,$sender,$number,$message);
    $res = $this->model->confirmGagal($data); echo $res;

  }
}