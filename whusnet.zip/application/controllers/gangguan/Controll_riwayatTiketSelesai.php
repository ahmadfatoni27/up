<?php
/**
 * @Author: Arif Efendi - Kazuya Media Indonesia
 * @Date:   2021-08-12 20:09:31
 * @Last Modified by:   kazuya
 * @Last Modified time: 2021-08-26 11:19:17
 */
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_riwayatTiketSelesai extends CI_Controller
{
  function __construct() {
    parent::__construct();
    $this->load->helper(array('login','configsession','my')); cek_login();
    $this->load->model('gangguan/M__tiketriwayat','model');
  }
  function index()
  {
    $data['title'] = "Data Tambah Riwayat Tiket Selesai";
    $data['session']= session();
    $this->template->load('_template', 'gangguan/@_dataTiketRiwayatSelesai',$data);
  }
  function getData() { $data = array(
    'start' => $_POST['start'],
    'length' => $_POST['length'],
    'filtervalue' => $_POST['filtervalue'],
    'filtertext' => $_POST['filtertext']);
  $res = $this->model->getDataAll_selesai($data);echo json_encode($res);
}
function getDataSelect() { $res = $this->model->getSelectConfirmId($_POST['id']); echo json_encode($res); }
function confirm(){
  $data = json_decode(file_get_contents('php://input'), true);
  $dataapi = array(
    'apikey'     => $data['apikey'],
    'nomorsender'=> $data['nomorsender'],
    'nomor'      => $data['HP'],
    'message'      => $data['TEMPLATEMESSAGE'],
  );
  $data = array(
    'NOTIKET'    => $data['NOTIKET'],
    'KONFIRMASI' => "1",
  );

  $api_key = $dataapi['apikey'];
  $sender = $dataapi['nomorsender'];
  $number = $dataapi['nomor'];
  $message = $dataapi['message'];
    // print_r($message);die();
    // kirimPesanwaTes($api_key,$sender,$number,$message);
  $dataapiwa = [
      'api_key' => $api_key,  // 68172c4edaca837ea3c2ff948a57ccc28c9db3a8
      'sender'  => $sender,   // 6283845478148
      'number'  => $number,   // 085236768521
      'message' => $message,  // 'Hello Bos'
    ];
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => "http://apikuwa.whusnet.com/api/send-message.php",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_POSTFIELDS => json_encode($dataapiwa))
  );
    $res = curl_exec($curl);
    curl_close($curl);
    return $res;

    $res = $this->model->confirm($data); echo $res;

  }
  function filterTemplateWA() { $res = $this->model->getdrawTemplateWA(); $res = array('res' => $res); echo json_encode($res); }
  function selectsapikey() { $res = $this->model->getapikey(); $res = array('res' => $res); echo json_encode($res); }
  function selectsapinomor() { $res = $this->model->getapinomor(); $res = array('res' => $res); echo json_encode($res); }

}
