<?php
/**
 * @Author: Arif Efendi - Kazuya Media Indonesia
 * @Date:   2021-08-12 20:09:31
 * @Last Modified by:   kazuya
 * @Last Modified time: 2021-08-26 11:19:13
 */
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_tambahtiket extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->helper(array('login','configsession','my')); cek_login();
    $this->load->model('gangguan/M__tambahtiket','model');
  }
  function index()
  {
    $data['title'] = "Data Tambah Tiket baru";
    $data['session']= session();
    $this->template->load('_template', 'gangguan/@_dataTambahTiket',$data);
  }
  function getData(){
    $data = array(
      'start' => $_POST['start'],
      'length' => $_POST['length'],
      'filtervalue' => $_POST['filtervalue'],
      'filtertext' => $_POST['filtertext']);
    $res = $this->model->getDataAll($data);
    echo json_encode($res);
  }
  // filter select options
  function selectKategoriTiket() { $res = $this->model->getselectsKategoriTiket(); echo json_encode($res); }
  //  token input
  function filterPelanggan() { $res = $this->model->getfilterPelanggan($_GET['q']); echo json_encode($res); }
  function save(){
    // $data = json_decode(file_get_contents('php://input'), true);
    // if($check == "OK") {
    $data = array(
      'NOTIKET'         => generateKodeForm('TI','Tambah'),
      'IDPELANGGAN'     => $_POST['IDPENGGUNA'],
      'IDKATEGORITIKET' => $_POST['KATEGORITIKET'],
      'KELUHAN'         => $_POST['KELUHAN'],
      'GANGGUANLAIN'    => $_POST['LAINNYA'],
      'INSERTEDAT'      => $_POST['INSERTEDAT'],
      'INSERTEDBY'      => $_POST['CREATEBY'],
    );
  // }
      // insert to table
    $this->model->insert($data);
    $res = array('res' => $data);
    echo json_encode($res);
  }
}