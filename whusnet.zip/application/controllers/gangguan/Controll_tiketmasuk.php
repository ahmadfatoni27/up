<?php
/**
 * @Author: Arif Efendi - Kazuya Media Indonesia
 * @Date:   2021-08-12 20:16:38
 * @Last Modified by:   kazuya
 * @Last Modified time: 2021-08-26 11:18:33
 */
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_tiketmasuk extends CI_Controller
{	
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my')); cek_login();
		$this->load->model('gangguan/M__tiketmasuk','model');
      	$this->config->load('confcompany', TRUE);
	}
	function index()
	{
		$data['title'] = "Data Tiket Masuk";
		$data['session']= session();
		$this->template->load('_template', 'gangguan/@_dataTiketMasuk',$data);
	}
	function getData(){
		$data = array(
			'start' => $_POST['start'],
			'length' => $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filtertext' => $_POST['filtertext']);
		$res = $this->model->getDataAll($data);
		echo json_encode($res);
	}
	function getDataReport() {
		$res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
	}
	function process() {
		if ($_POST['HP'] === "") {
			$res = array('status' => '404', 'info' => "no HP null" );
			echo json_encode($res);
		} else {
			
			$checkKeyactive = $this->keyActive();
          // echo $checkKeyactive; die(); 
			if ($checkKeyactive === 'no connect')
			{ 
				$res = json_encode(array('status' => FALSE, 'res' => $checkKeyactive));
				echo $res; die();
			} else { 
				if ($checkKeyactive == null) 
				{
					$res = json_encode(array('status' => $checkKeyactive, 'res' => 'urlgateway is null'));
					echo $res; die();
				} else {
					// $res = json_encode(array('status' => TRUE, 'res' => $checkKeyactive)); echo $res;
					$this->config->load('confcompany', TRUE);
					$urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration, custom configuration in config/confcompany.php
					/* SENDING MESSAGE WA */
					$curl = curl_init();
      				// AMBIL urlgatewaywa, api Whatsapp from setup confcompany.
					$CURLOPT_URL = ''.$urlgateway.'/index.php/api/sendMessageText';
      				// BUAT CURLOPT_POSTFIELDS /  DATA YANG AKAN DI POST KE API WHATSAPP.
					$data = '
					{
						"instance_key":  "'.$this->keyActive().'" ,
						"jid": "'.$_POST["HP"].'",
						"message": "Pelanggan a.n *'.$_POST['NAMADEPAN'].'*\n No.Pelanggan : _*'.$_POST['IDPELANGGAN'].'*_ . \n'.$_POST['TEMP_MESSAGE_PROSES'].'"
					}';
					curl_setopt_array($curl, array(
						CURLOPT_URL => $CURLOPT_URL,
						CURLOPT_RETURNTRANSFER => true,
						CURLOPT_ENCODING => '',
						CURLOPT_MAXREDIRS => 10,
						CURLOPT_TIMEOUT => 30,
						CURLOPT_FOLLOWLOCATION => true,
						CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
						CURLOPT_CUSTOMREQUEST => 'POST',
						CURLOPT_POSTFIELDS => $data,
					));
					// curl_exec($curl);
					$res = curl_exec($curl);
					curl_close($curl);
					/* END SENDING MESSAGE WA */
					$data = array(
						'NOTIKET' => $_POST['NOTIKET'],
						'PROCESSEDBY' => $_POST['CREATEBY'],
						'PROCESSEDAT' => $_POST['PROCESSEDAT'],
					);
					$this->model->updateTiketMasuk($data);
					$this->model->insertProsesTiket($data);
					echo $res;
				}
			}
		}
	}
  	// end - custom api
	function keyActive(){
		$this->config->load('confcompany', TRUE);
		$urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
		$curl = curl_init();
		$res = "".$urlgateway."/custom/Devices/getKeyDevice/key";
		curl_setopt_array($curl, array(
			CURLOPT_URL => $res,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		));
		$response = curl_exec($curl); curl_close($curl);
		return $response = json_decode($response);
	}
	/*  CUSTOM = urlgateway*/
	// function urlgateway(){
    //   	$urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
	// 	$curl = curl_init();
	// 	$url = "".$urlgateway."/custom/Devices/getUrl_getway";
	// 	curl_setopt_array($curl, array(
	// 		CURLOPT_URL => $url,
	// 		CURLOPT_RETURNTRANSFER => true,
	// 		CURLOPT_ENCODING => '',
	// 		CURLOPT_MAXREDIRS => 10,
	// 		CURLOPT_TIMEOUT => 0,
	// 		CURLOPT_FOLLOWLOCATION => true,
	// 		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	// 	));
	// 	$response = curl_exec($curl); curl_close($curl);
	// 	return $response = json_decode($response);
	// }
	/*  END CUSTOM = urlgateway*/
  // end - custom api

}
