<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_tiketproses extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->helper(array('login','configsession','my')); cek_login();
    $this->load->model('gangguan/M__tiketproses','model');
  }
  function index()
  {
    $data['title'] = "Data Tambah Tiket baru";
    $data['session']= session();
    $this->template->load('_template', 'gangguan/@_dataTiketProses',$data);
  }
  function getData(){
    $data = array(
      'start' => $_POST['start'],
      'length' => $_POST['length'],
      'filtervalue' => $_POST['filtervalue'],
      'filtertext' => $_POST['filtertext']);
    $res = $this->model->getDataAll($data);
    echo json_encode($res);
  }
  function getDataReport() {
    $res = $this->model->getSelectProcessId($_POST['id']); echo json_encode($res);
  }
  // GET DATA TEMPLATE WHATSAPP.
  function getDataTemplateWa_selesai() {
    $res = $this->model->selectDataTemplateWa($code = 'temp-wa-selesai'); 
    echo $res = json_encode($res = array('temp' => $res));
  }
  function getDataTemplateWa_proses() {
    $res = $this->model->selectDataTemplateWa($code = 'temp-wa-proses'); 
    echo $res = json_encode($res = array('temp' => $res));
  }
  // function getDataTemplateWa_gagal() {  
  //   $res = $this->model->selectDataTemplateWa($code = 'temp-wa-gagal'); 
  //   echo $res = json_encode($res = array('temp' => $res));
  // }
  function saveSukses(){
    $config['upload_path'] = 'upload/fototiketgangguan/';
    $config['allowed_types'] = 'gif|jpg|jpeg|png';
      // $config['max_size'] = 1024 * 8;
    $config['encrypt_name'] = TRUE;
    $this->load->library('upload', $config);
    $FILE_FOTOKARYAWAN = 'FOTOKARYAWAN';
    $FILE_FOTOKONEKSI = 'FOTOKONEKSI';
    $notiket = $_POST['NOTIKET'];
    $updateDataProses = array(
        'NOTIKET'     => $notiket, // 1 = sukes ; 2 = gagal
        'FLAG'        =>  1, // 1 = sukes ; 2 = gagal
      );
    $insertDataRiwayat = array(
      'NOTIKET'         => $notiket,
      'CATATANTEKNISI'  => $_POST['CATATANTEKNISI'],
      'FINISHEDBY'      => $_POST['CREATEBY'],
      'FINISHEDAT'      => $_POST['FINISHEDAT'],
    );
    // Upload FOTOKTP
    if ($this->upload->do_upload($FILE_FOTOKARYAWAN)) {
      $uploadData1 = $this->upload->data();
      $insertDataRiwayat['FOTOKARYAWAN'] = $uploadData1['file_name'];
    }
    if ($this->upload->do_upload($FILE_FOTOKONEKSI)) {
      $uploadData2 = $this->upload->data();
      $insertDataRiwayat['FOTOKONEKSI'] = $uploadData2['file_name'];
    }
    // SENDING MESSAGE TO NUMBER WA
    $checkkey = $this->keyActive();
    if ($checkkey === 'no connect') {
      $res = $checkkey;  
    } else {
      // $this->model->insertSukses($insertDataRiwayat);
      // $this->model->updateProses($notiket, $updateDataProses);
      // sending wa
      $curl = curl_init();
      // AMBIL url api review, yang telah di setting di aplikasi -> setting umum - setting url review.
      $urlreview = ''.$_POST["URL_REVIEW"].'/T/no/'.md5($_POST["NOTIKET"]).'';
      // AMBIL url api Whatsapp secara auto.
      $CURLOPT_URL = ''.$this->urlgateway().'/index.php/api/sendMessageText';
      // BUAT CURLOPT_POSTFIELDS /  DATA YANG AKAN DI POST KE API WHATSAPP.
      $data = '
      {
        "instance_key":  "'.$this->keyActive().'" ,
        "jid": "'.changeZerohp($_POST["HP"]).'",
        "message": "Pelanggan a.n *'.$_POST['NAMADEPAN'].'*.\n No.Pelanggan : _*'.$_POST['IDPELANGGAN'].'*_ .  \n'.$_POST['TEMP_MESSAGE_SUKSES'].'\n\n*Link Ulasan* : '.$urlreview.'" 
      }';
      curl_setopt_array($curl, array(
        CURLOPT_URL => $CURLOPT_URL,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => $data,
      ));
      $res = curl_exec($curl);
      curl_close($curl);
    }
    echo $res;
  }

  function saveGagal() {
    $config['upload_path'] = 'upload/fototiketgangguan/';
    $config['allowed_types'] = 'gif|jpg|jpeg|png';
      // $config['max_size'] = 1024 * 8;
    $config['encrypt_name'] = TRUE;
    $this->load->library('upload', $config);
    $FILE_FOTOKARYAWAN = 'FOTOKARYAWAN';
    $FILE_FOTOKONEKSI  = 'FOTOKONEKSI';
    $notiket = $_POST['NOTIKET'];
    $upadateDataProses = array(
        'FLAG'         =>  $_POST['FLAG'], // 1 = sukes ; 2 = gagal
        'FINISHEDAT'   =>  $_POST['FINISHEDAT'],
      );
    $insertDataRiwayat = array(
      'NOTIKET'         => $notiket,
      'CATATANTEKNISI'  => $_POST['CATATANTEKNISI'],
      'FAILEDBY'        => $_POST['CREATEBY'],
      'FAILEDAT'        => $_POST['FINISHEDAT'],
    );
      // Upload FOTOKTP
    if ($this->upload->do_upload($FILE_FOTOKARYAWAN)) {
      $uploadData1 = $this->upload->data();
      $insertDataRiwayat['FOTOKARYAWAN'] = $uploadData1['file_name'];
    }
    if ($this->upload->do_upload($FILE_FOTOKONEKSI)) {
      $uploadData2 = $this->upload->data();
      $insertDataRiwayat['FOTOKONEKSI'] = $uploadData2['file_name'];
    }
    $res = $this->model->insertGagal($insertDataRiwayat);
    $res = $this->model->updateProses($notiket, $upadateDataProses);
    echo $res;
  }



  // CUSTOM API
  function keyActive(){
    $curl = curl_init();
    $res = "http://localhost:8088/Panel_WhatsApp/custom/Devices/getKeyDevice/key";
    curl_setopt_array($curl, array(
      CURLOPT_URL => $res,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    ));
    $response = curl_exec($curl); curl_close($curl);
    return $response = json_decode($response);
  }
  function urlgateway(){
    $curl = curl_init();
    $url = "http://localhost:8088/Panel_WhatsApp/custom/Devices/getUrl_getway";
    curl_setopt_array($curl, array(
      CURLOPT_URL => $url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    ));
    $response = curl_exec($curl); curl_close($curl);
    return $response = json_decode($response);
  }
  // CUSTOM API


}