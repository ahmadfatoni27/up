<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_tiketproses extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->helper(array('login','configsession','my')); cek_login();
    $this->load->model('gangguan/M__tiketproses','model');
  }
  function index()
  {
    $data['title'] = "Data Tambah Tiket baru";
    $data['session']= session();
    $this->template->load('_template', 'gangguan/@_dataTiketProses',$data);
  }
  function getData(){
    $data = array(
      'start' => $_POST['start'],
      'length' => $_POST['length'],
      'filtervalue' => $_POST['filtervalue'],
      'filtertext' => $_POST['filtertext']);
    $res = $this->model->getDataAll($data);
    echo json_encode($res);
  }
  function getDataReport() {
    $res = $this->model->getSelectProcessId($_POST['id']); echo json_encode($res);
  }
  // GET DATA TEMPLATE WHATSAPP.
  function getDataTemplateWa_selesai() {
    $res = $this->model->selectDataTemplateWa($code = 'temp-wa-selesai'); 
    echo $res = json_encode($res = array('temp' => $res));
  }
  //  function filterTemplateWA() { 
  //   $res = $this->model->getdrawTemplateWA(); $res = array('res' => $res); echo json_encode($res); 
  // }
  function getDataTemplateWa_proses() {
    $res = $this->model->selectDataTemplateWa($code = 'temp-wa-proses'); 
    echo $res = json_encode($res = array('temp' => $res));
  }
  
  // function getDataTemplateWa_gagal() {  
  //   $res = $this->model->selectDataTemplateWa($code = 'temp-wa-gagal'); 
  //   echo $res = json_encode($res = array('temp' => $res));
  // }
  function saveSukses() {
    $config['upload_path'] = 'upload/fototiketgangguan/';
    $config['allowed_types'] = 'gif|jpg|jpeg|png';
      // $config['max_size'] = 1024 * 8;
    $config['encrypt_name'] = TRUE;
    $this->load->library('upload', $config);
    $FILE_FOTOKARYAWAN = 'FOTOKARYAWAN';
    $FILE_FOTOKONEKSI = 'FOTOKONEKSI';
    $notiket = $_POST['NOTIKET'];
    $updateDataProses = array(
        'NOTIKET'     => $notiket, // 1 = sukes ; 2 = gagal
        'FLAG'        =>  1, // 1 = sukes ; 2 = gagal
      );
    $insertDataRiwayat = array(
      'NOTIKET'         => $notiket,
      'CATATANTEKNISI'  => $_POST['CATATANTEKNISI'],
      'FINISHEDBY'      => $_POST['CREATEBY'],
      'FINISHEDAT'      => $_POST['FINISHEDAT'],
    );
    // Upload FOTOKTP
    if ($this->upload->do_upload($FILE_FOTOKARYAWAN)) {
      $uploadData1 = $this->upload->data();
      $insertDataRiwayat['FOTOKARYAWAN'] = $uploadData1['file_name'];
    }
    if ($this->upload->do_upload($FILE_FOTOKONEKSI)) {
      $uploadData2 = $this->upload->data();
      $insertDataRiwayat['FOTOKONEKSI'] = $uploadData2['file_name'];
    }

    if ($_POST['HP'] === "") {
      $res = array('status' => '404', 'info' => "no HP null" );
      echo json_encode($res);
    } else {
      $checkKeyactive = $this->keyActive();
      if ($checkKeyactive === 'no connect')
      { 
        $res = json_encode(array('status' => FALSE, 'res' => $checkKeyactive));
        echo $res;
      } else { 
        if ($checkKeyactive == null) 
        {
          $res = json_encode(array('status' => $checkKeyactive, 'res' => 'urlgateway is null'));
          echo $res;
        } else {
          // $res = json_encode(array('status' => TRUE, 'res' => $checkKeyactive)); echo $res; die();
          $this->config->load('confcompany', TRUE);
          $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration, custom configuration in config/confcompany.php
          /* SENDING MESSAGE WA */
          $curl = curl_init();
          $urlreview = ''.$_POST["URL_REVIEW"].'/T/no/'.md5($_POST["NOTIKET"]).'';
          // AMBIL urlgatewaywa, api Whatsapp from setup confcompany.
          $CURLOPT_URL = ''.$urlgateway.'/index.php/api/sendMessageText';
          // BUAT CURLOPT_POSTFIELDS /  DATA YANG AKAN DI POST KE API WHATSAPP.
          $data = '
          {
            "instance_key":  "'.$this->keyActive().'" ,
            "jid": "'.$_POST["HP"].'",
            "message": "Pelanggan a.n *'.$_POST['NAMADEPAN'].'*.\n No.Pelanggan : _*'.$_POST['IDPELANGGAN'].'*_ .  \n'.$_POST['TEMPLATEMESSAGE'].'\n\n*Link Ulasan* : '.$urlreview.'"
          }';
            // "message": "Pelanggan a.n *'.$_POST['NAMADEPAN'].'*.\n No.Pelanggan : _*'.$_POST['IDPELANGGAN'].'*_ .  \n'.$_POST['TEMPLATEMESSAGE'].'"
          //print_r($data); die();
          curl_setopt_array($curl, array(
            CURLOPT_URL => $CURLOPT_URL,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $data,
          ));
          // curl_exec($curl);
          $res = curl_exec($curl);
          curl_close($curl);
          /* END SENDING MESSAGE WA */
          $data = array(
            'NOTIKET' => $_POST['NOTIKET'],
            'PROCESSEDBY' => $_POST['CREATEBY'],
            'PROCESSEDAT' => $_POST['PROCESSEDAT'],
          ); 
          $this->model->insertSukses($insertDataRiwayat);
         $this->model->updateProses($notiket, $updateDataProses);
          echo $res;
        }
      }
    }
  }

  function saveGagal() {
    $config['upload_path'] = 'upload/fototiketgangguan/';
    $config['allowed_types'] = 'gif|jpg|jpeg|png';
      // $config['max_size'] = 1024 * 8;
    $config['encrypt_name'] = TRUE;
    $this->load->library('upload', $config);
    $FILE_FOTOKARYAWAN = 'FOTOKARYAWAN';
    $FILE_FOTOKONEKSI  = 'FOTOKONEKSI';
    $notiket = $_POST['NOTIKET'];
    $upadateDataProses = array(
        'FLAG'         =>  $_POST['FLAG'], // 1 = sukes ; 2 = gagal
        'FINISHEDAT'   =>  $_POST['FINISHEDAT'],
      );
    $insertDataRiwayat = array(
      'NOTIKET'         => $notiket,
      'CATATANTEKNISI'  => $_POST['CATATANTEKNISI'],
      'FAILEDBY'        => $_POST['CREATEBY'],
      'FAILEDAT'        => $_POST['FINISHEDAT'],
    );
      // Upload FOTOKTP
    if ($this->upload->do_upload($FILE_FOTOKARYAWAN)) {
      $uploadData1 = $this->upload->data();
      $insertDataRiwayat['FOTOKARYAWAN'] = $uploadData1['file_name'];
    }
    if ($this->upload->do_upload($FILE_FOTOKONEKSI)) {
      $uploadData2 = $this->upload->data();
      $insertDataRiwayat['FOTOKONEKSI'] = $uploadData2['file_name'];
    }
    $res = $this->model->insertGagal($insertDataRiwayat);
    $res = $this->model->updateProses($notiket, $upadateDataProses);
    echo $res;
  }

  // CUSTOM API
  function keyActive(){
    $this->config->load('confcompany', TRUE);
    $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
    $curl = curl_init();
    $res = "".$urlgateway."/custom/Devices/getKeyDevice/key";
    curl_setopt_array($curl, array(
      CURLOPT_URL => $res,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    ));
    $response = curl_exec($curl); curl_close($curl);
    return $response = json_decode($response);
  }

  // function urlgateway(){
  //   $curl = curl_init();
  //   $url = "http://localhost:8088/Panel_WhatsApp/custom/Devices/getUrl_getway";
  //   curl_setopt_array($curl, array(
  //     CURLOPT_URL => $url,
  //     CURLOPT_RETURNTRANSFER => true,
  //     CURLOPT_ENCODING => '',
  //     CURLOPT_MAXREDIRS => 10,
  //     CURLOPT_TIMEOUT => 0,
  //     CURLOPT_FOLLOWLOCATION => true,
  //     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  //   ));
  //   $response = curl_exec($curl); curl_close($curl);
  //   return $response = json_decode($response);
  // }
  // CUSTOM API

}