<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_Mapping extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->helper(array('login','configsession','my')); cek_login();
    $this->load->model('mapingOdp/M_Mapping','model');
  }
  function index()
  {
    $data['title'] = "Data Mapping";
    $data['session']= session();
    $this->template->load('_template', 'mapingOdp/@_dataMapping',$data);
  }
  function GetDataOdp() {
    $data = array(
      'start' => $_POST['start'],
      'length' => $_POST['length'],
      'filtervalue' => $_POST['filtervalue'],
      'filtertext' => $_POST['filtertext'],
    );
    $res = $this->model->GetDataOdp($data);
    echo json_encode($res);
  }
  function GetPelangganOdp(){
    $data = array(
      'start' => $_POST['start'],
      'length' => $_POST['length'],
      'filtervalue' => $_POST['filtervalue'],
      'filtertext' => $_POST['filtertext'],
      // 'id' => $_POST['id'],
    );
    $res = $this->model->GetPelangganOdp($data);
    echo json_encode($res);
  }
  function savelocation(){
    $data = json_decode(file_get_contents('php://input'), true);
    $nomor_odp = $data['NOMOR_ODP'];
    $cekdatalocation = $this->model->CekDataLocation($nomor_odp);
    if ($cekdatalocation['STATUS']=='ada') {
      $id = $cekdatalocation['IDUNIQ']['IDLOCATION'];
      $dataUpdateLocation = array(
        'IDLOCATION'=> $id,
        'LATITUDE' => $data['LATITUDE'],
        'LONGITUDE'=> $data['LONGITUDE'],
      );
      $res = $this->model->UpdateLocation($dataUpdateLocation);
    } else {
      $id = uniqid();
      $dataInsert = array(
        'IDLOCATION'=> $id,
        'LATITUDE' => $data['LATITUDE'],
        'LONGITUDE'=> $data['LONGITUDE'],
      );
      $dataUpdate = array(
        'NOMOR_ODP'=> $data['NOMOR_ODP'],
        'IDODPLOCATION'=> $id,
      );
      $tesdata = array(
        'data1' => $dataInsert,
        'data2' => $dataUpdate,
      );
      $res = $this->model->InsertAndUpdate($dataInsert, $dataUpdate);
    }
    $res = array("result" => $res);
    echo json_encode($res);
  }
  function getLatLong() {
    $res = $this->model->getSelectLatLong(); $res = array('res' => $res); echo json_encode($res);
  }// filter select options

}?>
