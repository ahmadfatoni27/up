<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class C_aksesjabatan extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession'));
		$this->load->model('MenuDataModel');
		cek_login();
	}
	function index(){
		$data['title'] = "Data Akses Jabatan";
		// print session = $session['sessionName']; sessionname in configsession_helper file.
		$data['session']= session();
		$data['menu'] = $this->MenuDataModel->getAllMenu();
		$data['menu'] = json_encode($data['menu']);
		$this->template->load('_template', '_aksesjabatan', $data);
	}
	function getData(){
		$data = array( 'start' => $_POST['start'],
			'length' => $_POST['length']);
		$res = $this->MenuDataModel->getDataMenuAkses($data);
		echo json_encode($res);
	}
	function getDataSelect(){
		$data = json_decode(file_get_contents('php://input'), true);
		$res = $this->MenuDataModel->getMenuAkses($data['id']);
		echo json_encode($res);
	}
	function filterMenu(){
		$res = $this->MenuDataModel->getFilterMenu($_GET['q']);
		echo json_encode($res);
	}
	function save(){
		$data = json_decode(file_get_contents('php://input'), true);
		$listmenu = json_decode($data['listdata'], true);
		$datadel = array( 'JABATANID' => $data["JABATANID"]);
		$this->MenuDataModel->deleteAllAkses($datadel);
		foreach ($listmenu as $v){
			// echo $v["menuid"];
			$datamenu = array(
				'JABATANID'=>$data["JABATANID"],
				'menuid'=>$v["menuid"],
				'status'=>$v["status"],
			);
			$this->MenuDataModel->updateMenuAkses($datamenu);
		}
		echo json_encode(array("res"=>"OK"));
	}

	function checkId(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->MenuDataModel->checkId($data['id']);
		$res = array( 'res' => $check);
		echo json_encode($res);
	}

}
?>
