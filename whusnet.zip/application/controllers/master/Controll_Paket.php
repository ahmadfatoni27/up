<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_Paket extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->helper(array('login','configsession','my'));cek_login();
    $this->load->model('master/M__Paket','model');
  }
  function index()
  {
    $data['title'] = "Data Paket";
    $data['session']= session();
    $this->template->load('_template', 'master/@_dataPaket',$data);
  }
  function getData(){
    $data = array( 'start' => $_POST['start'],
    'length' => $_POST['length'],
    'filtervalue' => $_POST['filtervalue'],
    'filtertext' => $_POST['filtertext']);
    $res = $this->model->getDataAll($data); echo json_encode($res);
  }
  function getDataSelect(){
    $res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
  }
  function filterJenisPaket(){ $res = $this->model->getselectsJenisPaket(); echo json_encode($res); } // filter select options
  function filterKategoriPaket(){ $res = $this->model->getselectsKategoriPaket(); echo json_encode($res); } // filter select options
  function save(){
    $data = json_decode(file_get_contents('php://input'), true);
    $check = $this->model->checkId($data['KODEPAKET']);
    if($check == "OK"){
      $data = array(
        'KODEPAKET' => generateKodeForm('PK','tambah'),
        'NAMA_PAKET' =>  $data['NAMA_PAKET'],
        'JENIS_PAKET' =>  $data['JENIS_PAKET'],
        'KATEGORI_PAKET' =>  $data['KATEGORI_PAKET'],
        'HARGA' =>   $data['HARGA'],
        'SPEEDUP' =>  $data['SPEEDUP'],
        'SPEEDDOWN' =>   $data['SPEEDDOWN'],
        'LIMITUP' =>   $data['LIMITUP'],
        'LIMITDOWN' =>   $data['LIMITDOWN'],
        'BONUS' =>   $data['BONUS'],
        'KETERANGAN' => $data['KETERANGAN'],
        'PROFILOLT' => $data['PROFILOLT'],
        'PROFILPPP' => $data['PROFILPPP'],
      );
      // insert to table kategori
      $this->model->insert($data);
    }
    $res = array("result" => $check);
    echo json_encode($res);
  }
  function update(){
    $data = json_decode(file_get_contents('php://input'), true);
    if ($data['HARGABARU']!="") {
      $harga = $data['HARGABARU'];
    }else {
      $harga = $data['HARGA'];
    }
    // get id biaya untuk update biaya tagihan
    $idbiaya = $this->model->getidbiaya($data);
    if ($idbiaya!="") {
      foreach ($idbiaya as $k) {
        $idp = $k['IDPERMINTAAN'];
        $idb = $k['IDBIAYA'];
        // update biaya bulanan di tb biaya_tagihan
        $databulanan = array(
          'IDPERMINTAAN' =>   $idp,
          'IDBIAYA'      =>   $idb,
          'BIAYABULANAN' =>   $harga,
        );
        $this->model->Updatebiayabulanan($databulanan);
        $gettotalbayar = $this->model->gettotalbayar($idp, $idb);
        $total = $gettotalbayar['BIAYAPASANG']+$gettotalbayar['BIAYABULANAN']+$gettotalbayar['BIAYALAINLAIN'];
        $datatotal = array(
          'IDPERMINTAAN' =>   $idp,
          'IDBIAYA'      =>   $idb,
          'TOTALBIAYA'   =>   $total,
        );
        $this->model->Updatebiayatotal($datatotal);
        $bukti = $this->model->CekBuktiTransaksi($idb);
        if ($bukti>0) {
          $dataTagihan = array(
            'IDPERMINTAAN'=> $idp,
            'IDTRANSAKSI' => $idb,
            'BAYAR'       => $harga,
          );
          $this->model->UpdateBayartagihan($dataTagihan);
        }else{
          $dataTagihan0 = array(
            'IDPERMINTAAN'=> $idp,
            'IDTRANSAKSI' => $idb,
            'BAYAR'       => $total,
          );
          $this->model->UpdateBayartagihan0($dataTagihan0);
          $dataTagihan1 = array(
            'IDPERMINTAAN'=> $idp,
            'IDTRANSAKSI' => $idb,
            'BAYAR'       => $harga,
          );
          $this->model->UpdateBayartagihan1($dataTagihan1);
        }
      }
      $data = array(
        'KODEPAKET' =>  $data['KODEPAKET'],
        'NAMA_PAKET' =>  $data['NAMA_PAKET'],
        'JENIS_PAKET' =>  $data['JENIS_PAKET'],
        'KATEGORI_PAKET' =>  $data['KATEGORI_PAKET'],
        'HARGA' =>   $harga,
        'SPEEDUP' =>  $data['SPEEDUP'],
        'SPEEDDOWN' =>   $data['SPEEDDOWN'],
        'LIMITUP' =>   $data['LIMITUP'],
        'LIMITDOWN' =>   $data['LIMITDOWN'],
        'BONUS' =>   $data['BONUS'],
        'KETERANGAN' => $data['KETERANGAN'],
        'PROFILOLT' => $data['PROFILOLT'],
        'PROFILPPP' => $data['PROFILPPP'],
      );
      $res = $this->model->update($data); echo $res;
    }else{
      $data = array(
        'KODEPAKET' =>  $data['KODEPAKET'],
        'NAMA_PAKET' =>  $data['NAMA_PAKET'],
        'JENIS_PAKET' =>  $data['JENIS_PAKET'],
        'KATEGORI_PAKET' =>  $data['KATEGORI_PAKET'],
        'HARGA' =>   $harga,
        'SPEEDUP' =>  $data['SPEEDUP'],
        'SPEEDDOWN' =>   $data['SPEEDDOWN'],
        'LIMITUP' =>   $data['LIMITUP'],
        'LIMITDOWN' =>   $data['LIMITDOWN'],
        'BONUS' =>   $data['BONUS'],
        'KETERANGAN' => $data['KETERANGAN'],
        'PROFILOLT' => $data['PROFILOLT'],
        'PROFILPPP' => $data['PROFILPPP'],
      );
      $res = $this->model->update($data); echo $res;
    }
  }
  function delete(){
    $data = json_decode(file_get_contents('php://input'), true);
    $data = array( 'KODEPAKET' => $data['id']);
    $res = $this->model->delete($data);
    echo $res;
  }
  function checkId(){
    $data = json_decode(file_get_contents('php://input'), true);
    // print_r($data['id']);die();
    $check = $this->model->checkId($data['id']);
    $res = array( 'res' => $check);echo json_encode($res);
  }
}
?>
