<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_barang extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->helper(array('login','configsession','my')); cek_login();
    $this->load->model('master/M__barang','model');
  }
  function index()
  {
    $data['title'] = "Data Merk";
    $data['session']= session();
    $this->template->load('_template', 'master/@_dataBarang',$data);
  }
  function getData(){
    $data = array(
      'start' => $_POST['start'],
      'length' => $_POST['length'],
      'filtervalue' => $_POST['filtervalue'],
      'filtertext' => $_POST['filtertext']);
      $res = $this->model->getDataAll($data);
      echo json_encode($res);
    }
  function getDataSelect(){
		$res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
	}
  function save(){
		$data = json_decode(file_get_contents('php://input'), true);
		// $check = $this->model->checkId($data['IDMERK']);
    $GK_MERKBARANG = generateKodeForm('MR','tambah');
    $KODEBARANG = generateKodeForm('BR','tambah');
		// if($check == "OK") {
      $dataMerk = array(
        'IDMERK'            => $GK_MERKBARANG,
        // 'KATEGORIBARANG'    => $data['KODEKATEGORIBARANG'],
        'NAMABARANG'        => $data['NAMABARANG'],
        // 'MODEL'             => $data['MODEL'],
        // 'TYPE'              => $data['TYPE'],
        'SERIALNUMBER'      => $data['SERIALNUMBER'],
        // 'VERSI'             =>  $data['VERSI'],
      );
      $dataBarang = array(
        'KODEBARANG'    => $KODEBARANG,
        'MERKBARANG'    => $GK_MERKBARANG,
        // 'UKURAN'        => $data['UKURAN'],
        'UNIT'          => '1',
        // 'IP'            => $data['IP'],
        // 'MASK'          => $data['MASK'],
        'MACADDRESS'    => $data['MACADDRESS'],
        // 'HARGABELI'     => $data['HARGABELI'],
      );
      $dataStatusBarang = array(
        'KODEBARANG'    => $KODEBARANG,
        'STATUSBARANG'  => 'TERSEDIA', // TERSEDIA
        'IDMERK'        => $GK_MERKBARANG, //
        // 'STATUSKEADAAN', // BARU / HABIS PAKAI
      );
			// insert to table
			$res = $this->model->insert($dataBarang, $dataMerk, $dataStatusBarang);
      echo json_encode($res);
		}

	function update(){
		$data = json_decode(file_get_contents('php://input'), true);
    $dataMerk = array(
      'IDMERK'            => $data['IDMERK'],
      'KATEGORIBARANG'    => $data['KODEKATEGORIBARANG'],
      'NAMABARANG'        => $data['NAMABARANG'],
      'MODEL'             => $data['MODEL'],
      'TYPE'              => $data['TYPE'],
      'SERIALNUMBER'      => $data['SERIALNUMBER'],
      // 'VERSI'             => $data['VERSI'],
    );
    $dataBarang = array(
      'KODEBARANG'    => $data['KODEBARANG'],
      'MERKBARANG'    => $data['IDMERK'],
      'UKURAN'        => $data['UKURAN'],
      'UNIT'          => '1',
      'IP'            => $data['IP'],
      'MASK'          => $data['MASK'],
      'MACADDRESS'    => $data['MACADDRESS'],
      'HARGABELI'     => $data['HARGABELI'],
    );

    $res = $this->model->updateBarang($dataBarang, $data);
    $res = $this->model->updateMerk($dataMerk, $data);
    echo $res;
	}
	function delete(){
		$data = json_decode(file_get_contents('php://input'), true);
    $IDMERK = array('IDMERK' => $data['id']);
    $MERKBARANG = array('MERKBARANG' => $data['id']);
		$IDMERKSTATUSBARANG = array('IDMERK' => $data['id']);
		$res = $this->model->delete($IDMERK,$MERKBARANG, $IDMERKSTATUSBARANG); echo $res;
	}
	function checkId(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['id']);
		$res = array( 'res' => $check);echo json_encode($res);
	}

  //  token input
  function filterKategoriBarang() {
    $res = $this->model->getfilterKategoriBarang($_GET['q']); echo json_encode($res);
  }

}
  ?>
