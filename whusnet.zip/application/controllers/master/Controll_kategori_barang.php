<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_kategori_barang extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->model('master/M__KategoriBarang','model');
	}
	function index(){
		$data['title'] = "Data kategori";
		// print session = $session['sessionName']; sessionname in configsession_helper file.
		$data['session']= session();
		$this->template->load('_template', 'master/@_dataKategoriBarang', $data);
	}
	function getData(){
		$data = array( 'start' => $_POST['start'],
			'length' => $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filtertext' => $_POST['filtertext']);
		$res = $this->model->getDataAll($data);
		echo json_encode($res);
	}
	function getDataSelect(){
		$res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
	}
	function save(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['KODEKATEGORIBARANG']);
		if($check == "OK"){
			$data = array(
        'KODEKATEGORIBARANG' =>  $data['KODEKATEGORIBARANG'],
        'BARANG' =>  $data['BARANG'],
      );
			// print_r($data);die();
			// insert to table kategori
			$this->model->insert($data);
		}
		$res = array("result" => $check);
		echo json_encode($res);
	}
	function update(){
		$data = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'KODEKATEGORIBARANG' =>  $data['KODEKATEGORIBARANG'],
			'BARANG' =>  $data['BARANG'],
		);
		// print_r($data);die();
		$res = $this->model->update($data); echo $res;
	}
	function delete(){
		$data = json_decode(file_get_contents('php://input'), true);
		$data = array( 'KODEKATEGORIBARANG' => $data['id']);
		$res = $this->model->delete($data);
		echo $res;
	}
	function checkId(){
		$data = json_decode(file_get_contents('php://input'), true);
		// print_r($data['id']);die();
		$check = $this->model->checkId($data['id']);
		$res = array( 'res' => $check);echo json_encode($res);
	}
}
