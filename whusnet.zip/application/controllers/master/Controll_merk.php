<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_merk extends CI_Controller
{
  function __construct(){
    parent::__construct();
    // $this->load->helper(array('login','configsession','my'));cek_login();
    $this->load->model('master/M__merk','model');
  }
  function index()
  {
    $data['title'] = "Data Merk";
    // $data['session']= session();
    $this->template->load('_template', 'master/@_dataMerk',$data);
  }
  function getData(){
    $data = array( 'start' => $_POST['start'],
    'length' => $_POST['length'],
    'filtervalue' => $_POST['filtervalue'],
    'filtertext' => $_POST['filtertext']);
    $res = $this->model->getDataAll($data);
    echo json_encode($res);
  }
  function getDataSelect(){
		$res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
	}
  function save(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['IDMERK']);
		if($check == "OK"){
      $data = array(
        'IDMERK' => generateKodeForm('MRK','tambah'),
        'KATEGORIBARANG' =>  $data['KATEGORIBRANG'],
        'NAMABARANG' =>  $data['NAMABARANG'],
        'MODEL' =>  $data['MODEL'],
        'TYPE' =>   $data['TYPE'],
        'SERIALNUMBER' =>  $data['SERIALNUMBER'],
        'VERSI' =>   $data['VERSI'],
      );
			// insert to table kategori
			$this->model->insert($data);
		}
		$res = array("result" => $check);
		echo json_encode($res);
	}
	function update(){
		$data = json_decode(file_get_contents('php://input'), true);
		// print_r($data);die();
		$res = $this->model->update($data); echo $res;
	}
	function delete(){
		$data = json_decode(file_get_contents('php://input'), true);
		$data = array( 'IDMERK' => $data['id']);
		$res = $this->model->delete($data);
		echo $res;
	}
	function checkId(){
		$data = json_decode(file_get_contents('php://input'), true);
		// print_r($data['id']);die();
		$check = $this->model->checkId($data['id']);
		$res = array( 'res' => $check);echo json_encode($res);
	}
}
  ?>
