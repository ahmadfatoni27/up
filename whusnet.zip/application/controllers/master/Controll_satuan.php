<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_satuan extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));
		// cek_login();
		$this->load->model('master/M__satuan','model');
	}
	function index(){
		$data['title'] = "Data Merk";
		// print session = $session['sessionName']; sessionname in configsession_helper file.
		// $data['session']= session();
		$this->template->load('_template', 'master/@_dataSatuan', $data);
	}
	function getData(){
		$data = array( 'start' => $_POST['start'],
			'length' => $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filtertext' => $_POST['filtertext']);
		$res = $this->model->getDataAll($data);
		echo json_encode($res);
	}
	function getDataSelect(){
		$res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
	}
	function save() {
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['IDSATUAN']);
		if($check == "OK"){
			// insert to table satuan
			$this->model->insert($data);
		}
		$res = array("result" => $check);
		echo json_encode($res);
	}
	function update(){
		$data = json_decode(file_get_contents('php://input'), true);
		$res = $this->model->update($data); echo $res;
	}
	function delete(){
		$data = json_decode(file_get_contents('php://input'), true);
		$data = array( 'IDSATUAN' => $data['id']);
		$res = $this->model->delete($data);
		echo $res;
	}
}
