<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_antrianProses extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->helper(array('login', 'configsession', 'my'));
    //$this->load->helper(array('configsession', 'my'));
    cek_login();
    $this->load->model(
      array(
        'pelanggan/M__antrianProses' => 'model',
        'QRcode/QRcode_Model' => 'QRcode',
        'CheckModel' => 'CheckData',
      )
    );
  }
  function index()
  {
    $data['title'] = "Data Yang telah di Survei";
    // print session = $session['sessionName']; sessionname in configsession_helper file.
    $data['session'] = session();
    $this->template->load('_template', 'pelanggan/proses/@_dataAntrianProses', $data);
  }
  function keyActive()
  {
    $this->config->load('confcompany', TRUE);
    $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
    $curl = curl_init();
    $res = "" . $urlgateway . "/custom/Devices/getKeyDevice/key";
    curl_setopt_array($curl, array(
      CURLOPT_URL => $res,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    return $response = json_decode($response);
  }
  /*  CUSTOM = urlgateway*/
  function urlgateway()
  {
    $this->config->load('confcompany', TRUE);
    $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
    $curl = curl_init();
    $url = "" . $urlgateway . "/custom/Devices/getUrl_getway";
    curl_setopt_array($curl, array(
      CURLOPT_URL => $url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    return $response = json_decode($response);
  }
  /*  END CUSTOM = urlgateway*/
  function getData()
  {
    $data = array(
      'start' => $_POST['start'],
      'length' => $_POST['length'],
      'filtervalue' => $_POST['filtervalue'],
      'filterstatus' => $_POST['filterstatus'],
      'filtertext' => $_POST['filtertext']
    );
    $res = $this->model->getDataAll($data);
    echo json_encode($res);
  }
  function filterPakets()
  {
    $res = $this->CheckData->getdrawPaket();
    $res = array('res' => $res);
    echo json_encode($res);
  }
  function getDataSelect()
  {
    $res = $this->model->getSelectId($_POST['id']);
    echo json_encode($res);
  }
  function getDataDetailAlats()
  {
    $data = json_decode(file_get_contents('php://input'), true);
    $rest   = $this->CheckData->getDetilAlats($data['IDPERMINTAAN']);
    echo json_encode($rest);
  }
  function getDataSelectVerifikasiAdmin()
  {
    $res = $this->model->getSelectIdVerifikasiAdmin($_POST['id']);
    echo json_encode($res);
  }
  // proses ke tim pasang
  function verifikasiProses()
  {
    // $data = json_decode(file_get_contents('php://input'), true);
    $dataPermintaan = array(
      'STATUSPASANG'     => 'Verifikasi Proses', // di proses / di ACC oleh Admin
      'DIACC'       => $_POST['CREATEBY'],
      'TGLDIACC'      => date("Y/m/d H:i:s"),
    );
    // print_r($dataPermintaan);die();
    // insert riwayat tindakan untuk pelanggan
    $dataRiwayatPelanggan = array(
      'ID'         => uniqid(),
      'IDPERMINTAAN'     => $_POST['IDPERMINTAAN'],
      "CREATEBY"      => $_POST['CREATEBY'],
      'STATUSTINDAKAN'  => "Verifikasi Proses",
      'TGLTINDAKAN'     => date("Y/m/d H:i:s"),
    );
    $datapel = $this->model->getSelectId($_POST['IDPERMINTAAN']);
    $message = $datapel[0];
    //print_r($message->HP);die();
    if ($message->HP == "") {
      $this->res(404, 'no HP null'); // bisa data / query result.
    } else {
      $checkKeyactive = $this->keyActive();
      if ($checkKeyactive === 'no connect') {
        $res = json_encode(array('status' => FALSE, 'res' => $checkKeyactive));
        echo $res;
      } else {
        //jalankan fungsi cron kirim pesan dan update notivwa menjadi 1
        $this->config->load('confcompany', TRUE);
        $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration, custom configuration in config/confcompany.php
        /* SENDING MESSAGE WA */
        $curl = curl_init();
        // AMBIL urlgatewaywa, api Whatsapp from setup confcompany.
        $CURLOPT_URL = '' . $urlgateway . '/index.php/api/sendMessageText';
        // BUAT CURLOPT_POSTFIELDS /  DATA YANG AKAN DI POST KE API WHATSAPP.
        $data = '{
          "instance_key":  "' . $this->keyActive() . '" ,
          "jid": "' . $message->HP . '",
          "message": "Yth Pelanggan a.n *_' . $message->NAMA_LENGKAP . '_* \n Kami informasikan Status Permintaan Pemasangan anda saat ini sbb. \n *Permintaan sudah di Verifikasi admin, Teknisi sudah di jadwalkan untuk melakukan installasi.* \n Mohon Bersabar Menunggu. \n \n Terima Kasih \n Ini adalah Sistem Otomatis PT Data Arta Sedaya. Jika ada pertanyaan silahkan balas. team kami akan segera merespon."
        }';
        curl_setopt_array($curl, array(
          CURLOPT_URL => $CURLOPT_URL,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $data,
        ));
        // curl_exec($curl);
        $ress = curl_exec($curl);
        curl_close($curl);
        /* END SENDING MESSAGE WA */
      }
    }
    $res   = $this->model->startAction($dataPermintaan, $dataRiwayatPelanggan);
    echo $res;
  }
  function startProses()
  {
    $dataPermintaan = array(
      'STATUSPASANG' => 'Proses Pasang',
      'DIPROSES'     => $_POST['CREATEBY'],
      'TGLDIPROSES'  => date("Y/m/d H:i:s"),
    );
    // insert riwayat tindakan untuk pelanggan
    $dataRiwayatPelanggan = array(
      'ID'   => uniqid(),
      'IDPERMINTAAN'   => $_POST['IDPERMINTAAN'],
      "CREATEBY"      => $_POST['CREATEBY'],
      'STATUSTINDAKAN' => "Dalam Proses Pasang",
      'TGLTINDAKAN'   => date("Y/m/d H:i:s"),
    );
    $res   = $this->model->startAction($dataPermintaan, $dataRiwayatPelanggan);
    echo $res;
  }
  function putuskan()
  {
    $data = json_decode(file_get_contents('php://input'), true);
    // update data prosedure_permintaan_wifi
    $dataPermintaan = array(
      'IDPERMINTAAN' => $data['IDPERMINTAAN'],
      'STATUSPASANG' => 'Gagal',
      'updated_at'  => date("Y/m/d H:i:s"),
    );
    // insert riwayat tindakan untuk pelanggan
    $dataRiwayatPelanggan = array(
      'ID'   => uniqid(),
      'IDPERMINTAAN'   => $data['IDPERMINTAAN'],
      "CREATEBY"      => $data['CREATEBY'],
      'STATUSTINDAKAN' => "Gagal",
      'ALASAN'        => $data['ALASANGAGAL'],
      'TGLTINDAKAN'   => date("Y/m/d H:i:s"),
    );
    $res = $this->model->pembatalan($dataPermintaan, $dataRiwayatPelanggan);
    echo $res;
  }
  function filterAlat()
  {
    $res = $this->CheckData->getFilterAlat($_GET['q']);
    echo json_encode($res);
  }
  function filterPengguna()
  {
    $res = $this->model->getFilterPengguna($_GET['q']);
    echo json_encode($res);
  }
  function mulaiPemasangan()
  {
    $data = json_decode(file_get_contents('php://input'), true);
    $data = array(
      'IDPERMINTAAN' => $data['IDPERMINTAAN'],
      'DIPROSES'  => $data['CREATEBY'], /* ID STAF SESUAI JABATAN sebagai SPV teknis */
      'TGLDIPROSES'  => date("Y/m/d H:i:s")
    );
    // update to table
    $res =  $this->model->updatePemasangan($data);
    echo json_encode($res);
  }
  public function resizeImage($filename)
  {
    $source_path = $_SERVER['DOCUMENT_ROOT'] . '/upload/proses/' . $filename;
    $target_path = $_SERVER['DOCUMENT_ROOT'] . '/upload/proses/';
    $config_manip = array(
      'image_library' => 'gd2',
      'source_image' => $source_path,
      'new_image' => $target_path,
      'maintain_ratio' => TRUE,
      'width' => 450,
    );
    $this->load->library('image_lib', $config_manip);
    if (!$this->image_lib->resize()) {
      echo $this->image_lib->display_errors();
    }
    $this->image_lib->clear();
  }
  function laporPemasangan()
  {
    // $data = json_decode(file_get_contents('php://input'), true);
    // configurasi
    $config['upload_path'] = './upload/proses/';
    $config['allowed_types'] = 'gif|jpg|jpeg|png';
    // $config['max_size'] = 1024 * 8;
    $config['encrypt_name'] = TRUE;
    $this->load->library('upload', $config);
    // $file_element_name = 'userfile';
    $file_FOTOROOTER   = "FOTOROOTER";
    // $file_FOTOKABEL		= "FOTOKABEL";
    $file_FOTOTOWER   = "FOTOTOWER";
    $file_FOTOSPEED   = "FOTOSPEED";
    $file_FOTOFORMULIR   = "FOTOFORMULIR";
    $file_FOTOTTDFORMULIR   = "FOTOTTDFORMULIR";
    // $file[] = "userfile";
    // -----------------------------------
    // insert riwayat tindakan untuk pelanggan
    $dataRiwayatPelanggan = array(
      'ID'   => uniqid(),
      'IDPERMINTAAN'   => $_POST['IDPERMINTAAN'],
      "CREATEBY"      => $_POST['CREATEBY'],
      'STATUSTINDAKAN' => "Terpasang",
      'TGLTINDAKAN'   => date("Y/m/d H:i:s"),
    );
    // echo json_encode($dataRiwayatPelanggan); die();

    $updateProsedur = array( // update tb prosedur pemasangan wifi
      "IDPERMINTAAN" => $_POST['IDPERMINTAAN'], // this where
      "DILAPORKAN" => $_POST['CREATEBY'],
      "STATUSPASANG" => 'Terpasang',
      'STATUS'      => "DIPROSES",
      'IDPAKET'      => $_POST['KODEPAKET'],
      "TGLSELESAI"     => date("Y/m/d H:i:s")
    );
    // echo json_encode($updateProsedur);die();

    $updateAlatPasif = array( // update tb survey pemasangan wifi
      "IDPERMINTAAN" => $_POST['IDPERMINTAAN'], // this where
      "ALATPASIF"    => $_POST['ALATPASIF']
    );
    // echo json_encode($updateProsedur);die();

    $updateLaporan = array( // update tb laporan pemasangan
      "IDREPORT"     => uniqid('lp'),
      "IDPENGGUNA"   => $_POST['IDPENGGUNA'], // this where
      "IDPERMINTAAN" => $_POST['IDPERMINTAAN'], // this where
      "SINYAL"       => $_POST['STATUSSINYAL'],
      "JENIS"       => $_POST['JENISJARINGAN'],
      "TESTUP"       => $_POST['SPEEDUP_TEST'],
      "TESTDOWN"    => $_POST['SPEEDDOWN_TEST'],

      "PINGGATEWAY"     => $_POST['PINGGATEWAY'],
      "PINGGOOGLE"       => $_POST['PINGGOOGLE'],
      "IPADDR"           => $_POST['IPADDR'],
      "MACADDR_ANTENA"   => $_POST['MACADDR_ANTENA'],
      "MACADDR_ROOTER"   => $_POST['MACADDR_ROOTER'],
      "SNROOTER_FIBER"   => $_POST['SNROOTER_FIBER'],
      "NOMOR_ODP"       => $_POST['NOMOR_ODP'],
      "NOMOR_PORT_ODP"   => $_POST['NOMOR_PORT_ODP'],
      "NOMOR_PORT_OLT"   => $_POST['NOMOR_PORT_OLT'],
      "SIGNAL_WIRELESS" => $_POST['SIGNAL_WIRELESS'],
      "SIGNAL_KABEL"     => $_POST['SIGNAL_KABEL'],
      "KETERANGAN"       => $_POST['KETERANGAN'],
      "LOKASIPEMANCAR"   => $_POST['LOKASIPEMANCAR'],
    );
    // print_r($updateLaporan);die();

    if ($this->upload->do_upload($file_FOTOROOTER)) {
      $uploadDatats = $this->upload->data();
      $this->resizeImage($uploadDatats['file_name']);
      $updateLaporan['FOTOROOTER'] = $uploadDatats['file_name']; // Foto Router Terpasang.
    }
    // if ($this->upload->do_upload($file_FOTOKABEL)){
    // 	$uploadDataa = $this->upload->data();
    // 	$updateLaporan['FOTOKABEL'] = $uploadDataa['file_name']; // Foto Jalur Kabel.
    // }
    if ($this->upload->do_upload($file_FOTOTOWER)) {
      $uploadDatas = $this->upload->data();
      $this->resizeImage($uploadDatas['file_name']);
      $updateLaporan['FOTOTOWER'] = $uploadDatas['file_name']; // Foto Rumah Tampak Antena.
    }
    if ($this->upload->do_upload($file_FOTOSPEED)) {
      $uploadData = $this->upload->data();
      $this->resizeImage($uploadData['file_name']);
      $updateLaporan['FOTOSPEED'] = $uploadData['file_name']; // Foto Jalur Kabel.
    }
    if ($this->upload->do_upload($file_FOTOFORMULIR)) {
      $uploadDatta = $this->upload->data();
      $this->resizeImage($uploadDatta['file_name']);
      $updateLaporan['FOTOFORMULIR'] = $uploadDatta['file_name']; // Foto Formulir.
    }
    if ($this->upload->do_upload($file_FOTOTTDFORMULIR)) {
      $uploadDatta = $this->upload->data();
      $this->resizeImage($uploadDatta['file_name']);
      $updateLaporan['FOTOTTDFORMULIR'] = $uploadDatta['file_name']; // Foto FormulirTtd.
    }
    // print_r($_POST['LISTALAT']); die();
    $res = $this->model->riwayatTindakan($dataRiwayatPelanggan);
    $res = $this->model->updateProsedur($updateProsedur);
    $res = $this->model->updateAlatPasif($updateAlatPasif);
    $res = $this->model->updateLaporan($updateLaporan);
    $listalat = json_decode($_POST['LISTALAT'], true);
    if ($listalat != '') {
      // insert multi data on 'status pengguna barang'
      foreach ($listalat as $v) {
        if ($v['KODEBARANG'] != '') {
          $insertDataMulti = array( // tb riwayat_status_pengguna_barang
            "ID"          => uniqid(),
            "KODEBARANG" => $v['KODEBARANG'],
            "MERKBARANG" => $v['MERKBARANG'],
            "KETERANGAN" => 'DI' . $_POST['STATUSALAT'], // disewa, dibeli, kembali
            "IDPERMINTAAN"   => $_POST['IDPERMINTAAN'],
            "IDPENGGUNA"     => $_POST['IDPENGGUNA'],
          );
          $res = $this->model->insertDataMulti($insertDataMulti);
          $updateStatusBarang = array( // tb status_barang
            "KODEBARANG"     => $v['KODEBARANG'], // this where
            // "IDMERK" 		=> $v['IDMERK'], // this where
            "IDPERMINTAAN"     => $_POST['IDPERMINTAAN'],
            "STATUSBARANG"   => 'DI' . $_POST['STATUSALAT'],
            "STATUSKEADAAN" => $v['STATUSKEADAAN'],
          );
          $res = $this->model->updateStatusBarang($updateStatusBarang);
          // print_r(array('data'=>$insertDataMulti)); die();
        }
      } // END FOREACH

      // $tes = array(
      //   'updateProsedur' => $updateProsedur,
      //   'updateAlatPasif' => $updateAlatPasif,
      //   'updateLaporan' => $updateLaporan,
      //   'insertDataMulti' => $insertDataMulti,
      //   'updateStatusBarang' => $updateStatusBarang,
      // );
      // print_r($tes);die();

    }
    echo json_encode($res);
  }

  public function updateBiaya()
  {
    $data = json_decode(file_get_contents('php://input'), true);
    //print_r($data);die();
    $IDBIAYA = generateKodeForm('IN', 'Tambah');
    // $KODE = substr($data['IDPERMINTAAN'],4);
    // $TRANSAKSITAG = $IDBIAYA."/".$KODE;
    $dataPermintaan = array( // UPDATE tb prosedure_permintaan_wifi
      'IDPERMINTAAN'   => $data['IDPERMINTAAN'],
      'STATUSPASANG'   => 'Berhasil',
      'STATUS'     => 'ACTIVE',
      'updated_at'   => date("Y/m/d H:i:s"),
      'IDBIAYA'     => $IDBIAYA,
      'VERIFIED'     => $data['CREATEBY'],
      'VERIFIED_AT'   => date("Y/m/d H:i:s"),
    );
    // insert riwayat tindakan untuk pelanggan
    $dataRiwayatPelanggan = array( // riwayat_pelanggan
      'ID'       => uniqid(),
      'IDPERMINTAAN'   => $data['IDPERMINTAAN'],
      "CREATEBY"    => $data['CREATEBY'],
      'STATUSTINDAKAN' => "Berhasil Active",
      'TGLTINDAKAN'   => date("Y/m/d H:i:s"),
    );
    $dataBiayaTagihan = array( //INSERT tb baiya_tagihan
      'IDBIAYA'     => $IDBIAYA,
      'IDPELANGGAN'   => $data['IDPENGGUNA'],
      'IDPERMINTAAN'   => $data['IDPERMINTAAN'],
      'BIAYAPASANG'   => $data['BIAYAPASANG'],
      'BIAYABULANAN'   => $data['BIAYABULANAN'],
      'BIAYALAINLAIN' => $data['BIAYALAINLAIN'],
      'TOTALBIAYA'   => bilangan($data['TOTALBIAYA']),
    );
    // // TAMBAHAN BARU
    $dataBuktiTagihan = array( //INSERT tb buktitransaksitagihan
      'IDUNIQ'     => uniqid(),
      'IDTRANSAKSI'   => $IDBIAYA,
      'IDPERMINTAAN'   => $data['IDPERMINTAAN'],
      'BAYAR'     => bilangan($data['TOTALBIAYA']),
      'BULANTAGIHAN'   => date("Y/m/d")
    );

    // print_r($dataBuktiTagihan);die();
    // END TAMBAHAN BARU
    // $res = array(
    // 	"dataPermintaan" 				=> $dataPermintaan,
    // 	"dataRiwayatPelanggan" 	=> $dataRiwayatPelanggan,
    // 	"dataBiayaTagihan" 			=> $dataBiayaTagihan,
    // );
    if ($data['HP'] == "") {
      $this->res(404, 'no HP null'); // bisa data / query result.
    } else {
      $checkKeyactive = $this->keyActive();
      if ($checkKeyactive === 'no connect') {
        $res = json_encode(array('status' => FALSE, 'res' => $checkKeyactive));
        echo $res;
      } else {
        //jalankan fungsi cron kirim pesan dan update notivwa menjadi 1
        $this->config->load('confcompany', TRUE);
        $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration, custom configuration in config/confcompany.php
        /* SENDING MESSAGE WA */
        $curl = curl_init();
        // AMBIL urlgatewaywa, api Whatsapp from setup confcompany.
        $CURLOPT_URL = '' . $urlgateway . '/index.php/api/sendMessageText';

        $linkin = "http://review.whusnet.com/In/no/" . md5($data['IDPERMINTAAN']) . "";
        $checkdate = explode("/", $dataBuktiTagihan['BULANTAGIHAN']);
        $datenow = $checkdate[2];
        //print_r($datenow);die();
        if ($datenow > 10) {
          $getbulannext = date('Y/m/d', strtotime($dataBuktiTagihan['BULANTAGIHAN'] . ' + 1 month'));
          $bulannextt = explode("/", $getbulannext);
          $bulannext = $bulannextt[1];
          $tahunnext = $bulannextt[0];
          //print_r($bulannext);die();
          $jatuhtempo = "$tahunnext" . "/" . $bulannext . "/" . "10";
        } else {
          $tahunnow = $checkdate[0];
          $bulannow = $checkdate[1];
          $jatuhtempo = "$tahunnow" . "/" . $bulannow . "/" . "10";
        }
        $datapesan = '{
          "instance_key":  "' . $this->keyActive() . '" ,
          "jid": "' . $data['HP'] . '",
          "message": "YTH. *_' . $data['NAMA_LENGKAP'] . '_* \n Pendaftaran Pemasangan Internet sudah kami terima dengan rincian sbb : \n\n Nama Pelanggan : *' . $data['NAMA_LENGKAP'] . '* \n Alamat : *' . $data['ALMT'] . '* \n NoHP : *' . $data['HP'] . '* \n Paket Internet : *' . $data['IDPAKET'] . '* \n Jenis Kontrak : *' . $data['STATUSALAT'] . '* \n Jenis Jaringan : *' . $data['JENISJARINGAN'] . '* \n Biaya Bulanan Awal (Prorata) : *' . toRupiah($data['BIAYABULANAN']) . '* \n Tanggal Tagihan : *' . date("Y/m/d") . '* \n Jatuh Tempo : *' . $jatuhtempo . '* \n Tagihan Awal : *' . $linkin . '* \n\n Jika anda membutuhkan bantuan jika ada kendala segera hub wa.me/62818415131 \n Teknisi Online 24jam - Hanya Hubungi Melalui Chat WA \n \n Untuk pembayaran bisa melalui CASH, TRANSFER. Informasi rekening hub wa.me/62817585853 \n Admin Online 8 Pagi - 4 Sore - Hanya Hubungi Melalui Chat WA \n\n Terima Kasih \n Ini adalah Sistem Otomatis PT Data Arta Sedaya. Jika ada pertanyaan silahkan balas. team kami akan segera merespon."
        }';
        //print_r($datapesan);die();
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'http://apiwa.whusnet.com/index.php/api/sendMessageText',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $datapesan,
        ));
        // curl_exec($curl);
        $ress = curl_exec($curl);
        curl_close($curl);
        //print_r($ress);die();

        /* END SENDING MESSAGE WA */
      }
    }
    $res = $this->model->insertBiayaTagihan($data, $dataBiayaTagihan, $dataPermintaan, $dataRiwayatPelanggan, $dataBuktiTagihan);
    echo $res;
  }

  //  token input
  function filterKategoriBarang()
  {
    $res = $this->model->getfilterKategoriBarang($_GET['q']);
    echo json_encode($res);
  }

  function GetTagihanAwal()
  {
    $idpaket = $_POST['id'];
    $res = GetTagihanAwal($idpaket);
    echo json_encode($res);
    //print_r($res);die();
  }
}
