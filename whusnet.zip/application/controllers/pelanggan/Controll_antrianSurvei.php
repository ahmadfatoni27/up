<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_antrianSurvei extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->helper(array('login','configsession','my'));cek_login();
    $this->load->model(array(
      'pelanggan/M__antrianSurvei' => 'model',
      'CheckModel' => 'CheckData',
    )
  );
}
function index(){
  $data['title'] = "Data Yang telah di Survei";
  // print session = $session['sessionName']; sessionname in configsession_helper file.
  $data['session']= session();
  $this->template->load('_template', 'pelanggan/survei/@_dataAntrianSurvei', $data);
}

function keyActive(){
  $this->config->load('confcompany', TRUE);
  $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
  $curl = curl_init();
  $res = "".$urlgateway."/custom/Devices/getKeyDevice/key";
  curl_setopt_array($curl, array(
    CURLOPT_URL => $res,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  ));
  $response = curl_exec($curl); curl_close($curl);
  return $response = json_decode($response);
}
/*  CUSTOM = urlgateway*/
function urlgateway(){
  $this->config->load('confcompany', TRUE);
  $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
  $curl = curl_init();
  $url = "".$urlgateway."/custom/Devices/getUrl_getway";
  curl_setopt_array($curl, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  ));
  $response = curl_exec($curl); curl_close($curl);
  return $response = json_decode($response);
}
/*  END CUSTOM = urlgateway*/
function getData(){
  $data = array( 'start' => $_POST['start'],
  'length' 		 => $_POST['length'],
  'filtervalue'=> $_POST['filtervalue'],
  'filtertext' => $_POST['filtertext'],
);
$res = $this->model->getDataAll($data); echo json_encode($res);
}
function filterPakets() {
  $res = $this->CheckData->getdrawPaket(); $res = array('res' => $res); echo json_encode($res);
}

function getDataSelect(){
  $res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
}
public function resizeImage($filename) {
      $source_path = $_SERVER['DOCUMENT_ROOT'] . '/upload/survei/' . $filename;
      $target_path = $_SERVER['DOCUMENT_ROOT'] . '/upload/survei/';
      $config_manip = array(
        'image_library' => 'gd2',
        'source_image' => $source_path,
        'new_image' => $target_path,
        'maintain_ratio' => TRUE,
        'width' => 450,
      );
      $this->load->library('image_lib', $config_manip);
      if (!$this->image_lib->resize()) {
        echo $this->image_lib->display_errors();
      }
      $this->image_lib->clear();
    }
function saveLaporanSurvei(){
  // $data = json_decode(file_get_contents('php://input'), true);
  // configurasi
  $config['upload_path'] = './upload/survei/';
  $config['allowed_types'] = 'gif|jpg|jpeg|png';
  // $config['max_size'] = 1024 * 8;
  $config['encrypt_name'] = TRUE;
  $this->load->library('upload', $config);
  $file_element_name = 'userfile';
  // update to table =
  // 'survey_pemasangan_wifi' where 'IDPERMINTAAN' ?
  $dataSurvei = array(
    'IDSURVEY' 					=> uniqid('spw'),
    'LAT' 							=> $_POST['LAT'],
    'LONG' 							=> $_POST['LONG'],
    // 'GEOGRAFIS' 				=> $_POST['GEOGRAFIS'],
    // 'SINYAL' 						=> $_POST['SINYAL'],
    'KATEGORITINGKAT' 	=> $_POST['TINGKAT'],
    'ESTIMASIKEBUTUHAN' => $_POST['ESTIMASIKEBUTUHAN'],
    'TGLSURVEY' 				=> date("Y/m/d H:i:s"),
  );
  
  if ($this->upload->do_upload($file_element_name)) {
    $uploadData = $this->upload->data();
    $this->resizeImage($uploadData['file_name']);
    $dataSurvei['FOTORUMAH'] = $uploadData['file_name'];
  }
  
  // update data in table =
  // 'prosedure_permintaan_wifi' where 'IDPERMINTAAN' ?
  $dataPermintaan = array(
    'DISURVEY'			=> $_POST['CREATEBY'],
    'STATUSPASANG' 	=> 'Selesai Survei',
    'STATUS'				=> "DISURVEI", // selesai di survei
    'TGLSELESAI' 		=> date("Y/m/d H:i:s"),
    'IDPAKET'				=> $_POST['KODEPAKET'],
    'STATUSALAT'		=> $_POST['STATUSALAT'], // == JENIS KONTRAK
    'JENISJARINGAN' => $_POST['JENISJARINGAN'],
  );
  
  // insert riwayat tindakan untuk pelanggan
  $dataRiwayatPelanggan = array(
    'ID' 						=> uniqid(),
    'IDPERMINTAAN' 	=> $_POST['IDPERMINTAAN'],
    "CREATEBY"			=> $_POST['CREATEBY'],
    'STATUSTINDAKAN'=> "Proses Survei Selesai",
    'TGLTINDAKAN' 	=> date("Y/m/d H:i:s"),
  );
  // UPDARE PENGGUNA
  $dataPengguna = array(
    'IDPENGGUNA' 	=> $_POST['IDPENGGUNA'],
    "HP"					=> $_POST['HP'],
    'EMAIL'				=> $_POST['EMAIL'],
    'ALMT' 				=> $_POST['ALMT'],
  );
  // $check = array(
  // 	'dataSurvei' => $dataSurvei,
  // 	'dataPermintaan' => $dataPermintaan,
  // 	'dataRiwayatPelanggan' => $dataRiwayatPelanggan,
  // );
  // echo json_encode($check); die();
  $datapel = $this->model->getSelectId($_POST['IDPERMINTAAN']);
  $message=$datapel[0];
  //print_r($message->HP);die();
  if ($message->HP == "") {
    $this->res(404, 'no HP null'); // bisa data / query result.
  }else{
    $checkKeyactive = $this->keyActive();
    if ($checkKeyactive==='no connect') {
      $res = json_encode(array('status' => FALSE, 'res' => $checkKeyactive));
      echo $res;
    }else{
      //jalankan fungsi cron kirim pesan dan update notivwa menjadi 1
      $this->config->load('confcompany', TRUE);
      $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration, custom configuration in config/confcompany.php
      /* SENDING MESSAGE WA */
      $curl = curl_init();
      // AMBIL urlgatewaywa, api Whatsapp from setup confcompany.
      $CURLOPT_URL = ''.$urlgateway.'/index.php/api/sendMessageText';
      // BUAT CURLOPT_POSTFIELDS /  DATA YANG AKAN DI POST KE API WHATSAPP.
      $data = '{
        "instance_key":  "'.$this->keyActive().'" ,
        "jid": "'.$message->HP.'",
        "message": "YTH. *_'.$message->NAMA_LENGKAP.'_* \n Kami informasikan Status Permintaan Pemasangan anda saat ini sbb. \n *Lokasi Sudah di survey, Biaya Installasi akan di infokan oleh admin beberapa waktu kedepan.* \n \n Terima Kasih \n Ini adalah Sistem Otomatis PT Data Arta Sedaya. Jika ada pertanyaan silahkan balas. team kami akan segera merespon."
      }';
      curl_setopt_array($curl, array(
        CURLOPT_URL => $CURLOPT_URL,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => $data,
      ));
      // curl_exec($curl);
      $ress = curl_exec($curl);
      curl_close($curl);
      /* END SENDING MESSAGE WA */
    }
  }
  $res = $this->model->updateSurvei($dataPengguna,$dataSurvei, $dataPermintaan, $dataRiwayatPelanggan);
  $res = array("result" => $res);
  echo json_encode($res);
}
function startSurvei() {
  // $data = json_decode(file_get_contents('php://input'), true);
  $dataPermintaan = array(
    'STATUSPASANG' => 'Proses Survei',
    'DISURVEY' 		=> $_POST['CREATEBY'],
    'TGLSURVEY'	=> date("Y/m/d H:i:s"),
  );
  // insert riwayat tindakan untuk pelanggan
  $dataRiwayatPelanggan = array(
    'ID' 	=> uniqid(),
    'IDPERMINTAAN' 	=> $_POST['IDPERMINTAAN'],
    "CREATEBY"			=> $_POST['CREATEBY'],
    'STATUSTINDAKAN'=> "Dalam Proses Survei",
    'TGLTINDAKAN' 	=> date("Y/m/d H:i:s"),
  );
  // $res = array(
  // 	'dataPermintaan' => $dataPermintaan,
  // 	'dataRiwayatPelanggan' => $dataRiwayatPelanggan,
  // ); // echo json_encode($res); die();
  $res 	= $this->model->startSurvei($dataPermintaan, $dataRiwayatPelanggan); echo $res;
}

// function save(){
// 	$data = json_decode(file_get_contents('php://input'), true);
// 	$check = $this->model->checkId($data['IDPENGGUNA']);
// 	if($check == "OK"){
// 		$data = array(
// 			'IDsurvei'	=> generateKodeForm('RQ','tambah'),
// 			'IDPENGGUNA'	=> $data['IDPENGGUNA'],
// 			'STATUSALAT'	=> $data['STATUSALAT'],
// 			'STATUS'			=> 'PENGAJUAN',
// 			'IDPAKET'			=> $data['KODEPAKET'],
// 			'CREATED'	=> $data['CREATEBY'], /* ID STAF SESUAI JABATAN MEREKA */
// 		);
// 		// insert to table users
// 		$this->model->insert($data);
// 	}
// 	$res = array("result" => $check);
// 	echo json_encode($res);
// }
// function update(){
// 	$data = json_decode(file_get_contents('php://input'), true);
// 		$data = array(
// 			'IDsurvei'=> $data['IDsurvei'],
// 			'IDPENGGUNA'	=> $data['IDPENGGUNA'],
// 			'STATUSALAT'	=> $data['STATUSALAT'],
// 			'IDPAKET'			=> $data['KODEPAKET'],
// 			'updated_at'	=> date("Y/m/d H:i:s"), /* ID STAF SESUAI JABATAN MEREKA */
// 		);
// 	$res = $this->model->update($data); echo $res;
// }
// function delete(){
// 	$data = json_decode(file_get_contents('php://input'), true);
// 	$data = array( 'IDsurvei' => $data['id']);
// 	$res = $this->model->delete($data); echo $res;
// }

function filterPengguna(){
  $res = $this->CheckData->getFilterPengguna($_GET['q']); echo json_encode($res);
}
function filterPaket(){
  $res = $this->model->getFilterPaket($_GET['q']); echo json_encode($res);
}
function filterLevel() {
  $res = $this->model->getFilterLevel(); echo json_encode($res);
}
function checkId(){
  $data = json_decode(file_get_contents('php://input'), true);
  $check = $this->model->checkId($data['IDPENGGUNA']);
  $res = array( 'res' => $check); echo json_encode($res);
}
// function filterJabatan(){
// 	$res = $this->model->getfilterJabatan($_GET['q']); echo json_encode($res);
// }
// function CheckPass(){
// 	$data = json_decode(file_get_contents('php://input'), true);
// 	$check = $this->model->checkPass($data['id']);
// 	$res = array( 'res' => $check);
// 	echo json_encode($res);
// }
}
?>
