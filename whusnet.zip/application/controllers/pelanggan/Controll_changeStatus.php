<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_changeStatus extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->helper(array('login','configsession','my'));cek_login();
    $this->load->model( array(
      'pelanggan/M__antrianProses' => 'modelm',
      'ChangeStatusModel' => 'model',
    ));
  }
  function keyActive(){
    $this->config->load('confcompany', TRUE);
    $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
    $curl = curl_init();
    $res = "".$urlgateway."/custom/Devices/getKeyDevice/key";
    curl_setopt_array($curl, array(
      CURLOPT_URL => $res,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    ));
    $response = curl_exec($curl); curl_close($curl);
    return $response = json_decode($response);
  }
  /*  CUSTOM = urlgateway*/
  function urlgateway(){
    $this->config->load('confcompany', TRUE);
    $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
    $curl = curl_init();
    $url = "".$urlgateway."/custom/Devices/getUrl_getway";
    curl_setopt_array($curl, array(
      CURLOPT_URL => $url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    ));
    $response = curl_exec($curl); curl_close($curl);
    return $response = json_decode($response);
  }
  /*  END CUSTOM = urlgateway*/
  function gagalkan(){
    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['IDPERMINTAAN'];
    // update data prosedure_permintaan_wifi
    $dataPermintaan = array(
      'STATUSPASANG' 			 => 'Gagal',
      'STATUS' 			 			 => 'GAGAL',
      'ALASAN'						 => $data['ALASANGAGAL'],
      'STATUSTINDAKANALAT' => 'Belum Terpasang',
      'updated_at'	 			 => date("Y/m/d H:i:s"),
    );
    // insert riwayat pelanggan
    $dataRiwayatstatus = array(
      'ID' 	=> uniqid(),
      'IDPERMINTAAN' 	=> $data['IDPERMINTAAN'],
      "CREATEBY"			=> $data['CREATEBY'],
      'STATUSTINDAKAN'=> "Gagal",
      'ALASAN'				=> $data['ALASANGAGAL'],
      'STATUSTINDAKANALAT' => 'Belum Terpasang',
      'TGLTINDAKAN' 	=> date("Y/m/d H:i:s"),
    );
    $res = $this->model->updatePermintaan($dataPermintaan, $id, $dataRiwayatstatus); echo $res;
  }
  function putuskan() {
    $data = json_decode(file_get_contents('php://input'), true);
    // $status = ;
    if($data['STATUSALAT'] == 'SEWA') { $status = ""; } else { $status = "Hak milik"; }
    $id = $data['IDPERMINTAAN'];
    // update data
    $dataPermintaan = array(
      'STATUSPASANG' 			 => 'Terpasang',
      'STATUS' 			 			 => 'PUTUS',
      'ALASAN'						 => $data['ALASANPUTUS'],
      'STATUSTINDAKANALAT' => $status,
      'UBAHKONEKSI'  			 => 0,
      'updated_at'	 			 => date("Y/m/d H:i:s"),
    );
    // insert data
    $dataRiwayatstatus = array(
      'ID' => uniqid(),
      'IDPERMINTAAN' 			=> $data['IDPERMINTAAN'],
      'CREATEBY' 					=> $data['CREATEBY'],
      'STATUSTINDAKAN'		=> 'Putus Langganan',
      'ALASAN'			 			=> $data['ALASANPUTUS'],
      'STATUSTINDAKANALAT'=> $status,
      'TGLTINDAKAN'				=> date("Y/m/d H:i:s")
    );
    $res = array(
      'Data_permintaan' 	 => $dataPermintaan,
      'Data_riwayatstatus' => $dataRiwayatstatus,
    );
    $res = $this->model->updatePermintaan($dataPermintaan, $id, $dataRiwayatstatus); echo $res;
  }
  function kembalikanSurvei(){
    // Update data from prosedure_permintaan_wifi with STATUSPASANG = ""
    $id = $_POST['IDPERMINTAAN'];
    $dataPermintaan = array(
      'STATUSPASANG' 	 => "",
      'STATUS' 			 	 => "PENGAJUAN",
      'STATUSLANGGANAN'=> 'Kembali Pengajuan',
      'updated_at'	 	 => date("Y/m/d H:i:s"),
    );
    // insert / catat tindakan ke riwayat_pelanggan yang status Gagal
    $dataRiwayatstatus = array(
      'ID' 						=> uniqid(),
      'IDPERMINTAAN' 	=> $_POST['IDPERMINTAAN'],
      'CREATEBY' 			=> $_POST['CREATEBY'],
      'STATUSLANGGANAN'=> 'Kembali Pengajuan',
      'TGLTINDAKAN'		=> date("Y/m/d H:i:s")
    );
    $res = $this->model->updatePermintaan($dataPermintaan, $id, $dataRiwayatstatus); echo $res;
  }
  // _from data list putus
  function kembalikanAntrian(){
    $data = json_decode(file_get_contents('php://input'), true);
    // jika dikembalikan sebelum alat di ambil, masuk ke antrian proses , | menunggu verifikasi admin
    if($data['STATUSPASANG']=='Terpasang' && $data['STATUSTINDAKANALAT']=='' || $data['STATUSPASANG']=='Berhasil' && $data['STATUSTINDAKANALAT']=='') {
      $id = $data['IDPERMINTAAN'];
      // update
      $dataPermintaan = array(
        'STATUS' 			 => "DISURVEI",
        'STATUSPASANG' => "Terpasang",
        'STATUSLANGGANAN'=> 'Kembali Proses',
        'updated_at'	 	 => date("Y/m/d H:i:s"),
      );
      # insert data riwayat_pelanggan
      $dataRiwayatstatus = array(
        'ID' 						=> uniqid(),
        'IDPERMINTAAN' 	=> $data['IDPERMINTAAN'],
        'CREATEBY' 			=> $data['CREATEBY'],
        'STATUSLANGGANAN'=> 'Kembali Proses',
        'TGLTINDAKAN'		=> date("Y/m/d H:i:s")
      );
      $res = $this->model->updatePermintaan($dataPermintaan, $id, $dataRiwayatstatus); echo $res;
    }
    if($data['STATUSPASANG']=='Terpasang' && $data['STATUSTINDAKANALAT']=='Hak milik' || $data['STATUSPASANG']=='Terpasang' && $data['STATUSTINDAKANALAT']=='Hak Milik'){
      $id = $data['IDPERMINTAAN'];
      # update
      $dataPermintaan = array(
        'STATUS' 			 => "PENGAJUAN",
        'STATUSPASANG' => "",
        'STATUSLANGGANAN'=> 'Kembali Pengajuan',
        'updated_at'	 	 => date("Y/m/d H:i:s"),
      );
      # insert data riwayat_pelanggan
      $dataRiwayatstatus = array(
        'ID' 						=> uniqid(),
        'IDPERMINTAAN' 	=> $data['IDPERMINTAAN'],
        'CREATEBY' 			=> $data['CREATEBY'],
        'STATUSLANGGANAN'=> 'Kembali Pengajuan',
        'TGLTINDAKAN'		=> date("Y/m/d H:i:s")
      );
      $res = $this->model->updatePermintaan($dataPermintaan, $id, $dataRiwayatstatus); echo $res;
    }
    if($data['STATUSTINDAKANALAT']=='Sudah diambil'){
      $id = $data['IDPERMINTAAN'];
      # update
      $dataPermintaan = array(
        'STATUS' 			 	 => "PENGAJUAN",
        'STATUSPASANG' 	 => "",
        'STATUSLANGGANAN'=> 'Kembali Pengajuan',
        'updated_at'	 	 => date("Y/m/d H:i:s"),
      );
      # insert data riwayat_pelanggan
      $dataRiwayatstatus = array(
        'ID' 						 => uniqid(),
        'IDPERMINTAAN' 	 => $data['IDPERMINTAAN'],
        'CREATEBY' 			 => $data['CREATEBY'],
        'STATUSLANGGANAN'=> 'Kembali Pengajuan',
        'TGLTINDAKAN'		 => date("Y/m/d H:i:s")
      );
      $res = $this->model->updatePermintaan($dataPermintaan, $id, $dataRiwayatstatus); echo $res;
    }
  }
  function ambilAlat(){
    $id 	= $_POST['IDPERMINTAAN'];
    $dataupdate = array ( 'STATUSTINDAKANALAT'=> "Proses ambil", 'updated_at' => date("Y/m/d H:i:s" )); // update
    $res = $this->model->updateStatusAlat($id, $dataupdate); echo $res;
  }
  
  function laporPengambilan() {
    $data = json_decode(file_get_contents('php://input'), true);
    $id 	= $data['IDPERMINTAAN'];
    // update alat yang terpasang jadi tersedia.
    $listalat = json_decode($data['LISTALAT'], true);
    // insert multi data on 'status pengguna barang'
    foreach ($listalat as $v) {
      if ($v['KODEBARANG']!='') {
        $updateStatusBarang = array( // tb status_barang
          "KODEBARANG" 		=> $v['KODEBARANG'], // this where
          "IDPERMINTAAN" 	=> '',
          "STATUSBARANG" 	=> 'TERSEDIA',
        );
        $res = $this->model->updateStatusBarang($updateStatusBarang);
      }
    } // END FOREACH
    # insert reportPengambilan | table riwayat_pelanggan
    
    $dataPermintaan = array(
      'STATUSTINDAKANALAT'=> 'Sudah diambil',
      'updated_at'	 	 => date("Y/m/d H:i:s"),
    );
    # insert data riwayat_pelanggan
    $dataRiwayatstatus = array(
      'ID' 								=> uniqid(),
      'STATUSTINDAKAN' 		=> 'Alat telah kembali',
      'STATUSTINDAKANALAT'=> 'Sudah diambil',
      'CREATEBY' 					=> $data['CREATEBY'],
      'TGLTINDAKAN'				=> date("Y/m/d H:i:s")
    );
    // echo json_encode($data_riwayatstatus); die();
    $res = $this->model->updatePermintaan($dataPermintaan, $id, $dataRiwayatstatus); echo $res;
  }
  
  
}?>
