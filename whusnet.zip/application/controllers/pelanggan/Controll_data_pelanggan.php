<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_data_pelanggan extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->helper(array('login','configsession','my'));cek_login();
    $this->load->model( array(
      'pelanggan/M__data_pelanggan' => 'model',
      'CheckModel' => 'CheckData',
    ));
  }
  function index() {
    $data['title'] = "Data Yang menjadi pelanggan perusahaan";
    // print session = $session['sessionName']; sessionname in configsession_helper file.
    $data['session']= session();
    $this->template->load('_template', 'pelanggan/@_dataPelanggan', $data);
  }
  function getconfigserial() {
    $sn = $this->config->item('sn');
    echo json_encode($sn);
  }

  function filterPakets() {
    $res = $this->CheckData->getdrawPaket(); $res = array('res' => $res); echo json_encode($res);
  }// filter select options

  function filterMember() {
    $res = $this->model->getdrawMember(); $res = array('res' => $res); echo json_encode($res);
  }// filter select options

  function filterAlamat(){ $res = $this->model->getFilterAlamat($_GET['q']); echo json_encode($res); }// TOKEN FILTER DATA
  function filterIpKosong(){ $res = $this->model->getFilterIpKosong($_GET['q']); echo json_encode($res); }// TOKEN FILTER DATA
  function getData() {
    $data = array( 'start' => $_POST['start'],
    'length' => $_POST['length'],
    'filtervalue' => $_POST['filtervalue'],
    'filtertext' => $_POST['filtertext'],
    'filterno' => $_POST['filterno']
  );
    //print_r($data);die();
    $res = $this->model->getDataAll($data); echo json_encode($res);
  }
  // ALAT TERPASANG
  function getDataAlatTerpasang(){
    $data = array(
      'start' => $_POST['start'],
      'length' => $_POST['length'],
      'filteralat' => $_POST['filteralat']
    );
    // print_r($data);die();
    $res = $this->model->getDataAlatTerpasang($data); echo json_encode($res);
  }

  function lepasAlat(){
    $data = json_decode(file_get_contents('php://input'), true);
    $KODEBARANG = array(
      'KODEBARANG' => $data['id'],
    );
    $data = array(
      'STATUSBARANG' => "TERSEDIA",
      'IDPERMINTAAN' => "",
    );
    // print_r($KODEBARANG);die();
    $res = $this->model->LepasAlat($KODEBARANG, $data); echo $res;
  }
  // END ALAT TERPASANG

public function resizeImage($filename) {
      $source_path = $_SERVER['DOCUMENT_ROOT'] . '/upload/proses/' . $filename;
      $target_path = $_SERVER['DOCUMENT_ROOT'] . '/upload/proses/';
      $config_manip = array(
        'image_library' => 'gd2',
        'source_image' => $source_path,
        'new_image' => $target_path,
        'maintain_ratio' => TRUE,
        'width' => 450,
      );
      $this->load->library('image_lib', $config_manip);
      if (!$this->image_lib->resize()) {
        echo $this->image_lib->display_errors();
      }
      $this->image_lib->clear();
    }
  // update data - dari data yang sudah jadi pelanggan
  function updateData(){
    // configurasi
    $config['upload_path'] = './upload/proses/';
    $config['allowed_types'] = 'gif|jpg|jpeg|png';
    // $config['max_size'] = 1024 * 8;
    $config['encrypt_name'] = TRUE;
    $this->load->library('upload', $config);
    // $file_element_name = 'userfile';
    $file_FOTOROOTER 	    = "FOTOROOTER";
    $file_FOTOKABEL		    = "FOTOKABEL";
    $file_FOTOTOWER 	    = "FOTOTOWER";
    $file_FOTOSPEED 	    = "FOTOSPEED";
    $file_FOTOFORMULIR 	  = "FOTOFORMULIR";
    $file_FOTOTTDFORMULIR = "FOTOTTDFORMULIR";

    $updateProsedur = array( // update tb prosedur pemasangan wifi
      "IDPERMINTAAN" 	=> $_POST['IDPERMINTAAN'], // this where
      "IDPAKET" 			=> $_POST['KODEPAKET'],
      "JENISJARINGAN" => $_POST['JENISJARINGAN'],
      "JENISMEMBER"   => $_POST['JENISMEMBER'],
      "STATUSALAT" 		=> $_POST['STATUSALAT'],
      "updated_at" 		=> $_POST['UPDATE_AT']
    );
    $res = $this->model->updateProsedur($updateProsedur);

    $updatePengguna = array( // update tb pengguna
      "IDPENGGUNA" 	=> $_POST['IDPENGGUNA'], // this where
      "KTP_SIM" 		=> $_POST['KTP_SIM'],
      "EMAIL" 			=> $_POST['EMAIL'],
      "NAMADEPAN" 	=> seo_title($_POST['NAMA_LENGKAP']),
      "ALMT" 				=> $_POST['ALMT'],
      "DESA" 				=> $_POST['DESA'],
      "KEC" 				=> $_POST['KEC'],
      "IDWILAYAH" 	=> $_POST['IDWILAYAH'],
      "HP" 					=> $_POST['HP'],
      "JENISKELAMIN"=> $_POST['JENISKELAMIN'],
    );
    $res = $this->model->updatePengguna($updatePengguna);

    $updateSurvei = array( // suervei pemasangan wifi
      "IDPENGGUNA" 	=> $_POST['IDPENGGUNA'], // this where
      "LAT" 				=> $_POST['LAT'],
      "LONG" 				=> $_POST['LONG'],
      "ALATPASIF" 	=> $_POST['ALATPASIF'],
      "KATEGORITINGKAT"  => $_POST['KATEGORITINGKAT'],
      "ESTIMASIKEBUTUHAN"  => $_POST['ESTIMASIKEBUTUHAN'],
    );
    $res = $this->model->updateSurvei($updateSurvei);

    // $updatebiaya = array( // biaya_tagihan
    //   "IDPELANGGAN" 	=> $_POST['IDPENGGUNA'], // this where
    //   "BIAYABULANAN" 	=> $_POST['BIAYABULANAN'],
    //   "BIAYAPASANG" 	=> $_POST['BIAYAPASANG'],
    //   "BIAYALAINLAIN" => $_POST['BIAYALAINLAIN'],
    //   "TOTALBIAYA"    => $_POST['TOTALBIAYA'],
    // );
    // $res = $this->model->updateBiaya($updatebiaya);


    $updateLaporan = array( // update tb laporan pemasangan
      "IDPERMINTAAN" 	=> $_POST['IDPERMINTAAN'], // this where
      "JENIS" 				=> $_POST['JENISJARINGAN'],
      "IPADDR" 				=> $_POST['IPADDRESS'],
      "MACADDR_ANTENA"=> $_POST['MACADDR_ANTENA'],
      "SIGNAL_WIRELESS"=> $_POST['SIGNAL_WIRELESS'],
      "SNROOTER_FIBER"=> $_POST['SNROOTER_FIBER'],
      "NOMOR_ODP"     => $_POST['NOMOR_ODP'],
      "NOMOR_PORT_ODP"=> $_POST['NOMOR_PORT_ODP'],
      "NOMOR_PORT_OLT"=> $_POST['NOMOR_PORT_OLT'],
      "KETERANGAN"=> $_POST['KETERANGAN'],
      "TESTUP"=> $_POST['TESTUP'],
      "TESTDOWN"=> $_POST['TESTDOWN'],
      "PINGGATEWAY"=> $_POST['PINGGATEWAY'],
      "PINGGOOGLE"=> $_POST['PINGGOOGLE'],
    );
    if ($this->upload->do_upload($file_FOTOROOTER)){
      $uploadDatats = $this->upload->data();
      $this->resizeImage($uploadDatats['file_name']);
      $updateLaporan['FOTOROOTER'] = $uploadDatats['file_name']; // Foto Router Terpasang.
    }
    if ($this->upload->do_upload($file_FOTOKABEL)){
      $uploadDataa = $this->upload->data();
      $this->resizeImage($uploadDataa['file_name']);
      $updateLaporan['FOTOKABEL'] = $uploadDataa['file_name']; // Foto Jalur Kabel.
    }
    if ($this->upload->do_upload($file_FOTOTOWER)){
      $uploadDatas = $this->upload->data();
      $this->resizeImage($uploadDatas['file_name']);
      $updateLaporan['FOTOTOWER'] = $uploadDatas['file_name']; // Foto Rumah Tampak Antena.
    }
    if ($this->upload->do_upload($file_FOTOSPEED)){
      $uploadData = $this->upload->data();
      $this->resizeImage($uploadData['file_name']);
      $updateLaporan['FOTOSPEED'] = $uploadData['file_name']; // Foto Jalur Kabel.
    }
    if ($this->upload->do_upload($file_FOTOFORMULIR)){
      $uploadDatta = $this->upload->data();
      $this->resizeImage($uploadDatta['file_name']);
      $updateLaporan['FOTOFORMULIR'] = $uploadDatta['file_name']; // Foto Formulir.
    }
    if ($this->upload->do_upload($file_FOTOTTDFORMULIR)){
      $uploadDatta = $this->upload->data();
      $this->resizeImage($uploadDatta['file_name']);
      $updateLaporan['FOTOTTDFORMULIR'] = $uploadDatta['file_name']; // Foto FormulirTtd.
    }
    $res = $this->model->updateLaporan($updateLaporan);
    // echo json_encode(array('updateProsedur'=>$updateProsedur,'updateLaporan'=>$updateLaporan));

    $listalat = json_decode($_POST['LISTALAT'], true);
    if($listalat != '') {
      // insert multi data on 'status pengguna barang'
      foreach ($listalat as $v) {
        if ($v['KODEBARANG']!='') {

          $updateDataMulti = array( // tb riwayat_status_pengguna_barang
            "KODEBARANG" => $v['KODEBARANG'],
            "MERKBARANG" => $v['MERKBARANG'],
            "KETERANGAN" => 'DI'.$_POST['STATUSALAT'], // disewa, dibeli, kembali
            "IDPERMINTAAN" 	=> $_POST['IDPERMINTAAN'],
            "IDPENGGUNA" 		=> $_POST['IDPENGGUNA'],
          );
          $res = $this->model->updateDataMulti($updateDataMulti);
          $updateStatusBarang = array( // tb status_barang
            "KODEBARANG" 		=> $v['KODEBARANG'], // this where
            "IDPERMINTAAN" 		=> $_POST['IDPERMINTAAN'],
            "STATUSBARANG" 	=> 'DI'.$_POST['STATUSALAT'],
          );
          $res = $this->model->updateStatusBarang($updateStatusBarang);
        }
      } // END FOREACH
    }
    // $res = array(
    //   'updateProsedur'=>$updateProsedur,
    //   'updatePengguna'=>$updatePengguna,
    //   'updateSurvei'=>$updateSurvei,
    //   'updateLaporan'=>$updateLaporan,
    //   'updateDataMulti'=>$updateDataMulti,
    //   'updateStatusBarang'=>$updateStatusBarang,
    // );
    // print_r($res);die();
    echo json_encode($res);

  }

  function updateDataNoAlat(){
    // configurasi
    $config['upload_path'] = './upload/proses/';
    $config['allowed_types'] = 'gif|jpg|jpeg|png';
    // $config['max_size'] = 1024 * 8;
    $config['encrypt_name'] = TRUE;
    $this->load->library('upload', $config);
    // $file_element_name = 'userfile';
    $file_FOTOROOTER 	= "FOTOROOTER";
    $file_FOTOKABEL		= "FOTOKABEL";
    $file_FOTOTOWER 	= "FOTOTOWER";
    $file_FOTOSPEED 	= "FOTOSPEED";
    $file_FOTOFORMULIR 	= "FOTOFORMULIR";
    $file_FOTOTTDFORMULIR 	= "FOTOTTDFORMULIR";

    $updateProsedur = array( // update tb prosedur pemasangan wifi
      "IDPERMINTAAN" 	=> $_POST['IDPERMINTAAN'], // this where
      "IDPAKET" 			=> $_POST['KODEPAKET'],
      "JENISJARINGAN" => $_POST['JENISJARINGAN'],
      "JENISMEMBER"   => $_POST['JENISMEMBER'],
      "STATUSALAT" 		=> $_POST['STATUSALAT'],
      "updated_at" 		=> $_POST['UPDATE_AT']
    );
    // print_r($updateProsedur);die();
    $res = $this->model->updateProsedur($updateProsedur);

    $updatePengguna = array( // update tb pengguna
      "IDPENGGUNA" 	=> $_POST['IDPENGGUNA'], // this where
      "KTP_SIM" 		=> $_POST['KTP_SIM'],
      "EMAIL" 			=> $_POST['EMAIL'],
      "NAMADEPAN" 	=> seo_title($_POST['NAMA_LENGKAP']),
      "ALMT" 				=> $_POST['ALMT'],
      "DESA" 				=> $_POST['DESA'],
      "KEC" 				=> $_POST['KEC'],
      "IDWILAYAH" 	=> $_POST['IDWILAYAH'],
      "HP" 					=> $_POST['HP'],
      "JENISKELAMIN"=> $_POST['JENISKELAMIN'],
    );
    $res = $this->model->updatePengguna($updatePengguna);

    $updateSurvei = array( // survey_pemasangan_wifi
      "IDPENGGUNA" 	      => $_POST['IDPENGGUNA'], // this where
      "LAT" 				      => $_POST['LAT'],
      "LONG" 				      => $_POST['LONG'],
      "ALATPASIF"         => $_POST['ALATPASIF'],
      "KATEGORITINGKAT" 	=> $_POST['KATEGORITINGKAT'],
      "ESTIMASIKEBUTUHAN"  => $_POST['ESTIMASIKEBUTUHAN'],
    );
    $res = $this->model->updateSurvei($updateSurvei);

    // $updatebiaya = array( // biaya_tagihan
    //   "IDPELANGGAN" 	=> $_POST['IDPENGGUNA'], // this where
    //   "BIAYABULANAN" 	=> $_POST['BIAYABULANAN'],
    //   "BIAYAPASANG" 	=> $_POST['BIAYAPASANG'],
    //   "BIAYALAINLAIN" => $_POST['BIAYALAINLAIN'],
    //   "TOTALBIAYA"    => $_POST['TOTALBIAYA'],
    // );
    // $res = $this->model->updateBiaya($updatebiaya);


    // cek di apikeuangan_buktitransaksipemasangan by IDPERMINTAAN
    // jika adaupdate TOTALBIAYA
    // jika tidak update BIAYABULANAN by IDPERMINTAAN

    $updateLaporan = array( // update tb laporan pemasangan
      "IDPERMINTAAN" 	=> $_POST['IDPERMINTAAN'], // this where
      "JENIS" 				=> $_POST['JENISJARINGAN'],
      "IPADDR" 				=> $_POST['IPADDRESS'],
      "MACADDR_ANTENA"=> $_POST['MACADDR_ANTENA'],
      "SIGNAL_WIRELESS"=> $_POST['SIGNAL_WIRELESS'],
      "SNROOTER_FIBER"=> $_POST['SNROOTER_FIBER'],
      "NOMOR_ODP"     => $_POST['NOMOR_ODP'],
      "NOMOR_PORT_ODP"=> $_POST['NOMOR_PORT_ODP'],
      "NOMOR_PORT_OLT"=> $_POST['NOMOR_PORT_OLT'],
      "KETERANGAN"=> $_POST['KETERANGAN'],
      "TESTUP"=> $_POST['TESTUP'],
      "TESTDOWN"=> $_POST['TESTDOWN'],
      "PINGGATEWAY"=> $_POST['PINGGATEWAY'],
      "PINGGOOGLE"=> $_POST['PINGGOOGLE'],
    );
    if ($this->upload->do_upload($file_FOTOROOTER)){
      $uploadDatats = $this->upload->data();
      $this->resizeImage($uploadDatats['file_name']);
      $updateLaporan['FOTOROOTER'] = $uploadDatats['file_name']; // Foto Router Terpasang.
    }
    if ($this->upload->do_upload($file_FOTOKABEL)){
      $uploadDataa = $this->upload->data();
      $this->resizeImage($uploadDataa['file_name']);
      $updateLaporan['FOTOKABEL'] = $uploadDataa['file_name']; // Foto Jalur Kabel.
    }
    if ($this->upload->do_upload($file_FOTOTOWER)){
      $uploadDatas = $this->upload->data();
      $this->resizeImage($uploadDatas['file_name']);
      $updateLaporan['FOTOTOWER'] = $uploadDatas['file_name']; // Foto Rumah Tampak Antena.
    }
    if ($this->upload->do_upload($file_FOTOSPEED)){
      $uploadData = $this->upload->data();
      $this->resizeImage($uploadData['file_name']);
      $updateLaporan['FOTOSPEED'] = $uploadData['file_name']; // Foto Jalur Kabel.
    }
    if ($this->upload->do_upload($file_FOTOFORMULIR)){
      $uploadDatta = $this->upload->data();
      $this->resizeImage($uploadDatta['file_name']);
      $updateLaporan['FOTOFORMULIR'] = $uploadDatta['file_name']; // Foto Formulir.
    }
    if ($this->upload->do_upload($file_FOTOTTDFORMULIR)){
      $uploadDatta = $this->upload->data();
      $this->resizeImage($uploadDatta['file_name']);
      $updateLaporan['FOTOTTDFORMULIR'] = $uploadDatta['file_name']; // Foto FormulirTtd.
    }
    $res = $this->model->updateLaporan($updateLaporan);
    echo json_encode($res);
  }
  // ----
  function getDataSelect(){
  $cekTagPertama = $this->model->getcekTagPertama($_POST['id']);
  //print_r($cekTagPertama);die();
  if ($cekTagPertama > 0) {
    $data = $this->model->getSelectId($_POST['id']);
    $status = "bulanan";
  } else {
    $data = $this->model->getSelectId($_POST['id']);
    $status = "all";
  }
  $res = array('data' => $data,'status' => $status, );
  echo json_encode($res);
}
  function getDataDetailAlats(){
    $data = json_decode(file_get_contents('php://input'), true);
    $rest 	= $this->CheckData->getDetilAlats($data['IDPERMINTAAN']); echo json_encode($rest);
  }

  function getDataInvoice(){
    $cekTagPertama = $this->model->getcekTagPertama($_POST['id']);
    //print_r($cekTagPertama);die();
    if ($cekTagPertama > 0) {
      $data = $this->model->getSelectIdInvoice($_POST['id']);
      $status = "bulanan";
    } else {
      $data = $this->model->getSelectIdInvoice($_POST['id']);
      $status = "all";
    }
    $res = array('data' => $data,'status' => $status, );
    echo json_encode($res);
  }

  function getCheckKoneksi(){
    $res = $this->model->checkKoneksi($_POST['id']); echo json_encode($res);
  }
  function updateKoneksi(){
    // update data prosedure_permintaan_wifi, field UBAHKONEKSI
    $data = array(
      'IDPERMINTAAN' 	=> $_POST['IDPERMINTAAN'],
      'UBAHKONEKSI' 	=> $_POST['UBAHKONEKSI']
    );
    // insert / catat tindakan for riwayat_pelanggan
    $data_riwayatstatus = array(
      'ID' 						=> uniqid(),
      'IDPERMINTAAN' 	=> $_POST['IDPERMINTAAN'],
      'CREATEBY' 			=> $_POST['CREATEBY'],
      'STATUSTINDAKAN'=> $_POST['STATUSKONEKSI'],
      'TGLTINDAKAN'		=> date("Y/m/d H:i:s")
    );
    $res = $this->model->DoUpdateKoneksi($data, $data_riwayatstatus); echo $res;
  }




function GetBiayaBulananBaru() {
  $cekTagPertama = $this->model->getcekTagPertama($_POST['IDPERMINTAAN']);
  $IDPERMINTAAN=$_POST['IDPERMINTAAN'];
  $kodelama = $this->model->getSelectId($IDPERMINTAAN);
  $getidpaketlama=$kodelama[0];

  $idpaketlama=$getidpaketlama->KODEPAKET;
  $idpaketbaru=$_POST['KODEPAKETBARU'];
  //print_r($cekTagPertama);die();
  if ($cekTagPertama > 0) {
    $data = UgradePaket($idpaketlama,$idpaketbaru);
    $status = "bulanan";
  } else {
    $data = UgradePaket($idpaketlama,$idpaketbaru);
    $status = "all";
  }
  $res = array('data' => $data,'status' => $status, );
  echo json_encode($res);
}


function UpgradePaket(){
  $updateProsedur = array( // update tb prosedur pemasangan wifi
    "IDPERMINTAAN" 	=> $_POST['IDPERMINTAAN'], // this where
    "IDPAKET" 			=> $_POST['KODEPAKET']
  );
  $res = $this->model->updateProsedur($updateProsedur);
  $updateapikeuangan_buktitransaksitagihan = array( // update tb prosedur pemasangan wifi
    "IDPERMINTAAN" 	=> $_POST['IDPERMINTAAN'], // this where
    "BAYAR" 			=> $_POST['BIAYABULANAN']
  );
  $res = $this->model->updateapikeuangan_buktitransaksitagihan($updateapikeuangan_buktitransaksitagihan);
  $updatebiaya = array( // update tb prosedur pemasangan wifi
    "IDPELANGGAN" 	=> $_POST['IDPENGGUNA'], // this where
    "BIAYABULANAN" 	=> $_POST['BIAYABULANAN'],
    "TOTALBIAYA" 	  => $_POST['TOTALBIAYA']
  );
  $res = $this->model->updateBiaya($updatebiaya);
  echo json_encode($res);
}

}
