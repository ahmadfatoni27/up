<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_listGagalPasang extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->model( array(
			'pelanggan/M__listGagal' => 'model',
			'CheckModel' => 'CheckData',
		));
	}
	function index(){
		$data['title'] = "Data Gagal";
		// print session = $session['sessionName']; sessionname in configsession_helper file.
		$data['session']= session();
		$this->template->load('_template', 'pelanggan/@_dataListGagal', $data);
	}
	function getData(){
		$data = array( 'start' => $_POST['start'],
			'length' => $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filtertext' => $_POST['filtertext']);
		$res = $this->model->getDataAll($data);
		echo json_encode($res);
	}
	function getDataSelect(){
		$res = $this->model->getSelectId($_POST['id']);	echo json_encode($res);
	}
	function filterPakets() {
		$res = $this->CheckData->getdrawPaket(); $res = array('res' => $res); echo json_encode($res);
	}// filter select options
	// get data view data multi insert
	function getDataDetailAlats(){
		$data = json_decode(file_get_contents('php://input'), true);
		$rest 	= $this->CheckData->getDetilAlats($data['IDPERMINTAAN']); echo json_encode($rest);
	}
	function filterAlat() {
		$res = $this->CheckData->getFilterAlat($_GET['q']); echo json_encode($res);
	}
	// function save(){
	// 	$data = json_decode(file_get_contents('php://input'), true);
	// 	$check = $this->model->checkId($data['KODEKATEGORIBARANG']);
	// 	if($check == "OK"){
	// 		// insert to table kategori
	// 		$this->model->insert($data);
	// 	}
	// 	$res = array("result" => $check);
	// 	echo json_encode($res);
	// }
	// function update(){
	// 	$data = json_decode(file_get_contents('php://input'), true);
	// 	// print_r($data);die();
	// 	$res = $this->model->update($data); echo $res;
	// }
	// function delete(){
	// 	$data = json_decode(file_get_contents('php://input'), true);
	// 	$data = array( 'KODEKATEGORIBARANG' => $data['id']);
	// 	$res = $this->model->delete($data);
	// 	echo $res;
	// }

	// function checkId(){
	// 	$data = json_decode(file_get_contents('php://input'), true);
	// 	// print_r($data['id']);die();
	// 	$check = $this->model->checkId($data['id']);
	// 	$res = array( 'res' => $check);echo json_encode($res);
	// }
}
