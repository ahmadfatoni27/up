<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_listPutusLangganan extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->model( array(
			'pelanggan/M__listPutus' => 'model',
			'CheckModel' => 'CheckData'
			));
	}
	function index(){
		$data['title'] = "Data Putus Langganan";
		// print session = $session['sessionName']; sessionname in configsession_helper file.
		$data['session']= session();
		$this->template->load('_template', 'pelanggan/@_dataListPutus', $data);
	}
	function getData(){
		$data = array( 'start' => $_POST['start'],
		'length' => $_POST['length'],
		'filtervalue' => $_POST['filtervalue'],
		'filtertext' => $_POST['filtertext']);
		$res = $this->model->getDataAll($data);
		echo json_encode($res);
	}

	function getDataSelect(){
		$res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
	}

	function getId_Alat(){
		$res = $this->model->getId_updateAlat($_POST['id']); echo json_encode($res);
	}
	function getDataSelect_AlatmilikPelanggan(){
		$res = $this->model->getId_updateAlat($_POST['id']); echo json_encode($res);
	}
	function getDataSelect_alatmasihTerpasang(){
		$res = $this->model->getId_updateAlat($_POST['id']); echo json_encode($res);
	}

	function filterPakets(){ $res = $this->model->getselectsPaket(); echo json_encode($res); } // filter select options
	// get data view data multi insert
	function getDataDetailAlats(){
		$data = json_decode(file_get_contents('php://input'), true);
		$rest 	= $this->CheckData->getDetilAlats($data['IDPERMINTAAN']); echo json_encode($rest);
	}
	function goToSurvei(){
		// Update data from prosedure_permintaan_wifi
		// menunggu verifikasi admin / terpasang / 'Terpasang' 'DISURVEI'
		$dataPermintaan = array(
			'IDPERMINTAAN' => $_POST['IDPERMINTAAN'],
			'STATUSPASANG' => "Terpasang",
			'STATUS' 			 => "DISURVEI",
		);
		// update / catat tindakan ke riwayat_pelanggan yang status Putus
		$data_riwayatstatus = array(
			'ID' 						=> uniqid(),
			'IDPERMINTAAN' 	=> $_POST['IDPERMINTAAN'],
			'CREATEBY' 			=> $_POST['CREATEBY'],
			'STATUSTINDAKAN'=> 'Terpasang', // Terpasang / menunggu verifikasi admin
			'TGLTINDAKAN'		=> date("Y/m/d H:i:s")
		);
		// echo json_encode(array('dataPermintaan'=>$dataPermintaan, 'data_riwayatstatus'=>$data_riwayatstatus)); die();
		$res = $this->model->doSendToSurvei($dataPermintaan, $data_riwayatstatus); echo $res;
	}

	// function kembaliToAntrianAdmin(){
	//
	// $data = json_decode(file_get_contents('php://input'), true);

	// $where = array('IDPERMINTAAN'=>$data['IDPERMINTAAN'] , 'IDPENGGUNA'=>$data['IDPENGGUNA']);
	// kembali menunggu verifikasi admin
	// jika STATUSTINDAKAN = 'Putus Langganan' && STATUSTINDAKANALAT = ''
	// update prosedure_permintaan_wifi : STATUS = DISURVEI && STATUSPASANG = Terpasang
	//
	// $dataPermintaan = array(
	// 	"STATUS" 				=> 'DISURVEI',
	// 	"STATUSPASANG" 	=> 'Terpasang',
	// 	"UBAHKONEKSI" 	=> 0,
	// );
	# update riwayat_pelanggan =
	// $data_riwayatstatus = array(
	// 	'CREATEBY' 			=> $data['CREATEBY'],
	// 	'STATUSTINDAKAN'=> 'Kembali',
	// 	'STATUSTINDAKANALAT'=> 'Kembali antrian ',
	// 	'TGLTINDAKAN'		=> date("Y/m/d H:i:s")
	// );
	// $res = $this->model->updateRiwayat($data_riwayatstatus, $where); echo $res;
	// }


	// function save(){
	// 	$data = json_decode(file_get_contents('php://input'), true);
	// 	$check = $this->model->checkId($data['KODEKATEGORIBARANG']);
	// 	if($check == "OK"){
	// 		// insert to table kategori
	// 		$this->model->insert($data);
	// 	}
	// 	$res = array("result" => $check);
	// 	echo json_encode($res);
	// }
	// function update(){
	// 	$data = json_decode(file_get_contents('php://input'), true);
	// 	// print_r($data);die();
	// 	$res = $this->model->update($data); echo $res;
	// }
	// function delete(){
	// 	$data = json_decode(file_get_contents('php://input'), true);
	// 	$data = array( 'KODEKATEGORIBARANG' => $data['id']);
	// 	$res = $this->model->delete($data);
	// 	echo $res;
	// }
	// function checkId(){
	// 	$data = json_decode(file_get_contents('php://input'), true);
	// 	// print_r($data['id']);die();
	// 	$check = $this->model->checkId($data['id']);
	// 	$res = array( 'res' => $check);echo json_encode($res);
	// }
}
