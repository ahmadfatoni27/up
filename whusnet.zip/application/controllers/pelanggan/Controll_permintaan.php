<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_permintaan extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->model(array(
			'pelanggan/M__permintaan' => 'model',
			'CheckModel' => 'CheckData',
			)
		);
	}
	function index(){
		$data['title'] = "Data Pelanggan";
		// print session = $session['sessionName']; sessionname in configsession_helper file.
		$data['session']= session();
		$this->template->load('_template', 'pelanggan/permintaan/@_dataPermintaan', $data);
	}
	function getData(){
		$data = array( 'start' => $_POST['start'],
			'length' => $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filterstatus' => $_POST['filterstatus'],
			'filtertext' => $_POST['filtertext']);
		$res = $this->model->getDataAll($data);
		echo json_encode($res);
	}
	function getDataSelect(){
		$res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
	}
	function save(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['IDPENGGUNA']);
		if($check == "OK"){
			// data insert to table prosedure_permintaan_wifi
			$data = array(
				'IDPERMINTAAN'	=> generateKodeForm('RQ','tambah'),
				'IDPENGGUNA'		=> $data['IDPENGGUNA'],
				'IDPAKET'				=> $data['KODEPAKET'],
				'STATUSALAT'		=> $data['STATUSALAT'],
				'JENISJARINGAN' => $data['JENISJARINGAN'],
				'STATUS'				=> 'PENGAJUAN',
				'CREATED'				=> $data['CREATEBY'], /* ID STAF SESUAI JABATAN MEREKA */
			);

			// AND data insert to table survey_pemasangan_wifi
			$dataInSurvey = array (
				'IDSURVEY' => uniqid('spw'),
				'IDPERMINTAAN' => $data['IDPERMINTAAN'],
				'IDPENGGUNA' => $data['IDPENGGUNA'],
			);

			// AND data insert to table laporan_pemasangan_wifi
			$dataInLaporan = array (
				'IDREPORT' => uniqid('lpw'),
				'IDPENGGUNA' => $data['IDPENGGUNA'],
				'IDPERMINTAAN' => $data['IDPERMINTAAN'],
			);
			// echo json_encode(Array('data permintaan'=>$data,'data survei'=>$dataInSurvey)); die();
			$this->model->insert($data, $dataInSurvey, $dataInLaporan);
		}
		$res = array("result" => $check);
		echo json_encode($res);
	}
	function update(){
		$data = json_decode(file_get_contents('php://input'), true);
			$data = array(
				'IDPERMINTAAN'=> $data['IDPERMINTAAN'],
				'IDPENGGUNA'	=> $data['IDPENGGUNA'],
				'STATUSALAT'	=> $data['STATUSALAT'],
				'IDPAKET'			=> $data['KODEPAKET'],
				'updated_at'	=> date("Y/m/d H:i:s"),
			);
			// echo json_encode($data); die();
		$res = $this->model->update($data); echo $res;
	}

	function saveSurvei(){
		// $data = json_decode(file_get_contents('php://input'), true);
		// configurasi
		$config['upload_path'] = './upload/survei/';
		$config['allowed_types'] = 'gif|jpg|jpeg|png';
		// $config['max_size'] = 1024 * 8;
		$config['encrypt_name'] = TRUE;
		$this->load->library('upload', $config);
		$file_element_name = 'userfile';
		// update to table =
		// 'survey_pemasangan_wifi'
		$dataSurvei = array(
			'IDSURVEY' 					=> uniqid('spw'),
			'IDPENGGUNA' 				=> $_POST['IDPENGGUNA'],
			'IDPERMINTAAN'			=> $_POST['IDPERMINTAAN'],
			'LAT' 							=> $_POST['getLatitude'],
			'LONG' 							=> $_POST['getLongitude'],
			'GEOGRAFIS' 				=> $_POST['GEOGRAFIS'],
			'SINYAL' 						=> $_POST['SINYAL'],
			// 'FOTORUMAH' 				=> '',
			'ESTIMASIKEBUTUHAN' => $_POST['ESTIMASIKEBUTUHAN'],
			'TGLSURVEY' 				=> date("Y/m/d H:i:s"),
		);

		if ($this->upload->do_upload($file_element_name)) {
			$uploadData = $this->upload->data();
			$dataSurvei['FOTORUMAH'] = $uploadData['file_name'];
		}

		// update data in table =
		// 'prosedure_permintaan_wifi' where 'IDPERMINTAAN' ?
		$dataPermintaan = array(
			'JENISJARINGAN'	=> $_POST['JENISJARINGAN'],
			'STATUSALAT'		=> $_POST['STATUSALAT'],
			'IDPAKET'				=> $_POST['IDPAKET'],
			'DISURVEY'			=> $_POST['CREATEBY'],
			'STATUS'				=> $_POST['DISURVEI'],
			'TGLSURVEY' 		=> date("Y/m/d H:i:s"),
			'updated_at'		=> date("Y/m/d H:i:s"),
		);
		$res = $this->model->updateSurvei($dataSurvei, $dataPermintaan); echo $res;
	}

	function delete(){
		$data = json_decode(file_get_contents('php://input'), true);
		$data = array('IDPERMINTAAN' => $data['id']);
		// echo print_r($data);die();
		$res = $this->model->delete($data); echo $res;
	}

	function filterPengguna(){ $res = $this->CheckData->getFilterPengguna($_GET['q']); echo json_encode($res); }

	function filterPaket(){ $res = $this->model->getFilterPaket($_GET['q']); echo json_encode($res); }

	function checkId() {
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['id']); $res = array( 'res' => $check); echo json_encode($res);
	}
	// function filterJabatan(){
	// 	$res = $this->model->getfilterJabatan($_GET['q']); echo json_encode($res);
	// }
	// function CheckPass(){
	// 	$data = json_decode(file_get_contents('php://input'), true);
	// 	$check = $this->model->checkPass($data['id']);
	// 	$res = array( 'res' => $check);
	// 	echo json_encode($res);
	// }



}
?>
