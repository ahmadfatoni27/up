<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_proses extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->model(array(
			'pelanggan/M__proses' => 'model',
			'CheckModel' => 'CheckData',
			)
		);
	}
	function index(){
		$data['title'] = "Data Yang telah di Survei";
		// print session = $session['sessionName']; sessionname in configsession_helper file.
		$data['session']= session();
		$this->template->load('_template', 'pelanggan/proses/@_dataProses', $data);
	}
	function getData(){
		$data = array( 'start' => $_POST['start'],
			'length' => $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filterstatus' => $_POST['filterstatus'],
			'filtertext' => $_POST['filtertext']);
		$res = $this->model->getDataAll($data); echo json_encode($res);
	}

	function getDataSelect() {
		$res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
	}

	function filterAlat() {
		$res = $this->CheckData->getFilterAlat($_GET['q']); echo json_encode($res);
	}

	function filterPengguna() {
		$res = $this->CheckData->getFilterPengguna($_GET['q']); echo json_encode($res);
	}

	function mulaiPemasangan() {
		$data = json_decode(file_get_contents('php://input'), true);
			$data = array(
				'IDPERMINTAAN' => $data['IDPERMINTAAN'],
				'DIPROSES'	=> $data['CREATEBY'], /* ID STAF SESUAI JABATAN sebagai SPV teknis */
				'TGLDIPROSES'	=> date("Y/m/d H:i:s")
			);
			// update to table
		$res =	$this->model->updatePemasangan($data); echo json_encode($res);
	}
	function updateFotoPemasangan(){
		// $data = json_decode(file_get_contents('php://input'), true);

		// configurasi
		$config['upload_path'] = './upload/proses/';
		$config['allowed_types'] = 'gif|jpg|jpeg|png';
		// $config['max_size'] = 1024 * 8;
		$config['encrypt_name'] = TRUE;
		$this->load->library('upload', $config);
		// $file_element_name = 'userfile';
		$file_FOTOTOWER = "FOTOTOWER";
		$file_FOTOKABEL = "FOTOKABEL";
		$file_FOTOROOTER = "FOTOROOTER";
		// $file[] = "userfile";
		// -----------------------------------

		if ($this->upload->do_upload($file_FOTOTOWER)){
			$uploadDatas = $this->upload->data();
			$data['FOTOTOWER'] = $uploadDatas['file_name'];
		}
		if ($this->upload->do_upload($file_FOTOKABEL)){
			$uploadDataa = $this->upload->data();
			$data['FOTOKABEL'] = $uploadDataa['file_name'];
		}
		if ($this->upload->do_upload($file_FOTOROOTER)){
			$uploadDatats = $this->upload->data();
			$data['FOTOROOTER'] = $uploadDatats['file_name'];
		}
			// echo $file_FOTOTOWER;
			// die();

		$res = $this->model->updateFotoPemasangan($data);
		echo $res;
	}
	function laporPemasangan() {
		$data = json_decode(file_get_contents('php://input'), true);

		$updateProsedur = array( // update tb prosedur pemasangan wifi
			"IDPERMINTAAN" => $data['IDPERMINTAAN'], // this where
			"DILAPORKAN" => $data['CREATEBY'],
			"STATUS" => 'ACTIVE',
			"TGLSELESAI" => date("Y/m/d H:i:s")
		);
		// echo json_encode($updateProsedur);die();
		$res = $this->model->updateProsedur($updateProsedur);

		$updateLaporan = array( // update tb laporan pemasangan
			"IDREPORT" 		=> uniqid('lp'),
			"IDPENGGUNA" 	=> $data['IDPENGGUNA'], // this where
			"IDPERMINTAAN"=> $data['IDPERMINTAAN'], // this where
			"SINYAL" 			=> $data['STATUSSINYAL'],
			"JENIS" 			=> $data['JENISJARINGAN'],
			"TESTUP" 			=> $data['SPEEDUP'],
			"TESTDOWN"		=> $data['SPEEDDOWN'],
		);
		$res = $this->model->updateLaporan($updateLaporan);

		$listalat = json_decode($data['LISTALAT'], true);
		 // insert multi data on 'status pengguna barang'
			foreach ($listalat as $v) {

				if ($v['KODEBARANG']!='' && $data['STATUSALAT']==='SEWA') {
					$insertDataMulti = array( // tb riwayat_status_pengguna_barang
						"ID" 				 => uniqid(),
						"KODEBARANG" => $v['KODEBARANG'],
						"MERKBARANG" => $v['MERKBARANG'],
						"IDPENGGUNA" => $data['IDPENGGUNA']
					);
					$res = $this->model->insertDataMulti($insertDataMulti);

					$updateStatusBarang = array( // tb status_barang
						"KODEBARANG" 		=> $v['KODEBARANG'], // this where
						// "IDMERK" 		=> $v['IDMERK'], // this where
						"PENGGUNAID" 		=> $data['IDPENGGUNA'],
						"STATUSBARANG" 	=> 'DI'.$data['STATUSALAT'],
						"STATUSKEADAAN" => $v['STATUSKEADAAN'],
					);
					$res = $this->model->updateStatusBarang($updateStatusBarang);
					// print_r(array('data'=>$insertDataMulti)); die();
				}

			} // END FOREACH

			// $dataCek = array(
			// 	"update Prosedur" => $updateProsedur,
			// 	"update Laporan" => $updateLaporan,
			// 	"update Data Multi" => $insertDataMulti,
			// 	"update Status Barang" => $updateStatusBarang,
			// );
			echo json_encode($res);
			// die();

	}




}
