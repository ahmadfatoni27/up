<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_registrasiPelanggan extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->model(array(
			'pelanggan/M__registrasiPelanggan' => 'model',
			'CheckModel' => 'CheckData',
			'ChangeStatusModel' => 'StatusModel',
		));
	}
	function index(){
		$data['title'] = "Data Pelanggan";
		// print session = $session['sessionName']; sessionname in configsession_helper file.
		$data['session']= session();
		// $this->template->load('_template', 'pelanggan/permintaan/@_dataPermintaan', $data);
		$this->template->load('_template', 'pelanggan/permintaan/@_dataRegistrasiPelanggan', $data);
	}
	function keyActive(){
		$this->config->load('confcompany', TRUE);
		$urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
		$curl = curl_init();
		$res = "".$urlgateway."/custom/Devices/getKeyDevice/key";
		curl_setopt_array($curl, array(
			CURLOPT_URL => $res,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		));
		$response = curl_exec($curl); curl_close($curl);
		return $response = json_decode($response);
	}
	/*  CUSTOM = urlgateway*/
	function urlgateway(){
		$this->config->load('confcompany', TRUE);
		$urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
		$curl = curl_init();
		$url = "".$urlgateway."/custom/Devices/getUrl_getway";
		curl_setopt_array($curl, array(
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		));
		$response = curl_exec($curl); curl_close($curl);
		return $response = json_decode($response);
	}
	public function resizeImage($filename) {
		$source_path = $_SERVER['DOCUMENT_ROOT'] . '/upload/fotoktp/' . $filename;
		$target_path = $_SERVER['DOCUMENT_ROOT'] . '/upload/fotoktp/';
		$config_manip = array(
			'image_library' => 'gd2',
			'source_image' => $source_path,
			'new_image' => $target_path,
			'maintain_ratio' => TRUE,
			'width' => 450,
		);
		$this->load->library('image_lib', $config_manip);
		if (!$this->image_lib->resize()) {
			echo $this->image_lib->display_errors();
		}
		$this->image_lib->clear();
	}
	/*  END CUSTOM = urlgateway*/
	function save(){
		$checkUser = $this->model->checkId($_POST['USERNAME']);
		$checkPengguna = $this->model->checkBynama($_POST['NAMA_LENGKAP']);
		if($checkUser == "OK" && $checkPengguna == "OK"){
			if($_POST['JENISPELANGGAN']=='RUMAHAN'){ $IDPENGGUNA = generateKodeForm('PE','tambah'); }
			else { $IDPENGGUNA = generateKodeForm('US','tambah'); }
			$IDCABANG = '1'; // == pusat
			$JABATANID = '8'; // == pelanggan

			// configurasi Upload
			$config['upload_path'] = 'upload/fotoktp/';
			$config['allowed_types'] = 'gif|jpg|jpeg|png';
			//$config['max_size'] = 1024 * 8;
			$config['encrypt_name'] = TRUE;
			$this->load->library('upload', $config);
			$file_element_name = 'userfile';
			//print_r($_POST['userfile']);die();

			// AND data insert to table pengguna
			$dataInPengguna = array (
				'IDPENGGUNA' => $IDPENGGUNA,
				'IDCABANG' => $IDCABANG,
				'IDJABATAN' => $JABATANID,
				'NAMADEPAN' => seo_title($_POST['NAMA_LENGKAP']),
				// 'NAMABELAKANG' => $data['NAMABELAKANG'],
				'KTP_SIM' => $_POST['KTP_SIM'],
				// 'FOTOKTP' => $data['FOTOKTP'],
				'JENISKELAMIN' => $_POST['JENISKELAMIN'],
				'JENISPELANGGAN' => $_POST['JENISPELANGGAN'],
				'EMAIL' => $_POST['EMAIL'],
				'HP' => $_POST['HP'],
				// 'TLP' => $data['TLP'],
				'IDWILAYAH' => $_POST['IDWILAYAH'],
				'KOTA' => $_POST['KOTA'],
				'KEC' => $_POST['KEC'],
				'DESA' => $_POST['DESA'],
				'ALMT' => $_POST['ALMT'],
				'STATUSAKUN' => 'aktif',
				// 'NAMAPERUSAHAAN' => $data['NAMAPERUSAHAAN'],
				'NPWP' => $_POST['NPWP'],
			);
			// Upload FOTOKTP
			if ($this->upload->do_upload($file_element_name)) {
				$uploadData = $this->upload->data();
				$this->resizeImage($uploadData['file_name']);
				$dataInPengguna['FOTOKTP'] = $uploadData['file_name'];
			}

			// AND data insert to table users
			$dataInUserLogin = array (
				'IDUSERS' 		=> uniqid(),
				'IDPENGGUNA' 	=> $IDPENGGUNA,
				'USERNAME'		=> $_POST['USERNAME'],
				'PASSWORD' 		=> sha1('1234567'),
				'IDCABANG'		=> $IDCABANG,
				'JABATANID'		=> $JABATANID,
				'ENTRYBY' 		=> $_POST['CREATEBY'],
				'ENTRYDATE'		=> date('Y-m-d'),
				'LASTIPADDR'	=> $this->input->ip_address()
			);

			// data insert to table prosedure_permintaan_wifi
			$IDPERMINTAAN = generateKodeForm('RQ','tambah');
			$dataInPermintaan = array(
				'IDPERMINTAAN'	=> $IDPERMINTAAN,
				'IDPENGGUNA'		=> $IDPENGGUNA,
				'IDPAKET'				=> $_POST['KODEPAKET'],
				'STATUSALAT'		=> $_POST['STATUSALAT'], // == JENIS KONTRAK
				'JENISJARINGAN' => $_POST['JENISJARINGAN'],
				'STATUS'				=> 'PENGAJUAN',
				'CREATED'				=> $_POST['CREATEBY'], /* ID PENGISI DATA */
			);

			$dataRiwayatstatus = array(
				'ID'						=> uniqid(),
				'IDPERMINTAAN'	=> $IDPERMINTAAN,
				'CREATEBY'			=> $IDPENGGUNA,
				'STATUSTINDAKAN'=> 'PENGAJUAN',
				'TGLTINDAKAN' 	=> date("Y/m/d H:i:s")
			);

			// AND data insert to table survey_pemasangan_wifi
			$dataInSurvey = array (
				'IDSURVEY' 		=> uniqid('spw'),
				'IDPERMINTAAN'=> $IDPERMINTAAN,
				'IDPENGGUNA' 	=> $IDPENGGUNA,
				'LAT' 				=> $_POST['getLatitude'],
				'LONG' 				=> $_POST['getLongitude'],
			);

			// AND data insert to table laporan_pemasangan_wifi
			$dataInLaporan = array (
				'IDREPORT' 		=> uniqid('lpw'),
				'IDPENGGUNA' 	=> $IDPENGGUNA,
				'IDPERMINTAAN'=> $IDPERMINTAAN,
			);
			$cek = array(
				"InPengguna"=>$dataInPengguna,
				"InUserLogin"=>$dataInUserLogin,
				"InPermintaan"=>$dataInPermintaan,
				"InSurvey"=>$dataInSurvey,
				"InLaporan"=>$dataInLaporan,
				"Riwayatstatus" => $dataRiwayatstatus,
			);

			if ($_POST['HP'] == "null") {
				$this->model->insert($dataInPengguna, $dataInUserLogin, $dataInPermintaan, $dataInSurvey, $dataInLaporan,$dataRiwayatstatus);
				$res = array("success" => "data_tersimpan_tanpa_kirimpesan");
				echo json_encode($res);
				die();
			}else{
				// $checkKeyactive = $this->keyActive();
				// if ($checkKeyactive==='no connect') {
				// 	$res = json_encode(array('status' => FALSE, 'res' => $checkKeyactive));
				// 	echo $res;
				// }else{
				//jalankan fungsi cron kirim pesan dan update notivwa menjadi 1
				$this->config->load('confcompany', TRUE);
				$urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration, custom configuration in config/confcompany.php
				/* SENDING MESSAGE WA */
				$curl = curl_init();
				// AMBIL urlgatewaywa, api Whatsapp from setup confcompany.
				$CURLOPT_URL = ''.$urlgateway.'/index.php/api/sendMessageText';
				$data = '{
					"instance_key":"'.$this->keyActive().'",
					"jid":"'.$_POST['HP'].'",
					"message":"YTH. *_'.$_POST['NAMA_LENGKAP'].'_* \n Pendaftaran Pemasangan Internet sudah kami terima dengan rincian sbb : \n \n Nama Pelanggan : *'.$_POST['NAMA_LENGKAP'].'* \n Alamat : *'.$_POST['ALMT'].'* \n NoHP : *'.$_POST['HP'].'* \n Paket Internet : *'.$_POST['KODEPAKET'].'* \n Jenis Kontrak : *'.$_POST['STATUSALAT'].'* \n Jenis Jaringan : *'.$_POST['JENISJARINGAN'].'* \n \n Permintaan pemasangan anda sedang dalam proses antrian survey. \n anda akan di hubungi teknisi survey dalam waktu dekat. \n \n Terima Kasih \n Ini adalah Sistem Otomatis PT Data Arta Sedaya. Jika ada pertanyaan silahkan balas. team kami akan segera merespon."
				}';
				// print_r($cek);die();
				curl_setopt_array($curl, array(
					CURLOPT_URL => $CURLOPT_URL,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_ENCODING => '',
					CURLOPT_MAXREDIRS => 10,
					CURLOPT_TIMEOUT => 15,
					CURLOPT_FOLLOWLOCATION => true,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_CUSTOMREQUEST => 'POST',
					CURLOPT_POSTFIELDS => $data,
				));
				// curl_exec($curl);
				$res = curl_exec($curl);
				curl_close($curl);
				/* END SENDING MESSAGE WA */
				// }
			}
			$response = $res;
			if (empty($response)) {
				$response = "null";
				echo $response;
				die();
			} else {
				$response;
				$this->model->insert($dataInPengguna, $dataInUserLogin, $dataInPermintaan, $dataInSurvey, $dataInLaporan,$dataRiwayatstatus);
				echo $response;
				die();
			}
		}else{
			$res = array("success" => $checkUser);
			$res = array("success" => $checkPengguna);
			echo json_encode($res);
			die();
		}
	}
	// TOKEN FILTER DATA
	function filterAlamat(){
		$res = $this->CheckData->getFilterAlamat($_GET['q']); echo json_encode($res);
	}
	function filterPakets() {
		$res = $this->CheckData->getdrawPaket(); $res = array('res' => $res); echo json_encode($res);
	}
	function checkId(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['id']); $res = array( 'res' => $check); echo json_encode($res);
	}
	function checkBypengguna(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkBynama($data['id']);
		$res = array( 'res' => $check);
		echo json_encode($res);
	}

	// function filterJabatan(){
	// 	$res = $this->model->getfilterJabatan($_GET['q']); echo json_encode($res);
	// }
	// function CheckPass(){
	// 	$data = json_decode(file_get_contents('php://input'), true);
	// 	$check = $this->model->checkPass($data['id']);
	// 	$res = array( 'res' => $check);
	// 	echo json_encode($res);
	// }


}?>
