<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_survei extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->model(array(
			'pelanggan/M__survei' => 'model',
			'CheckModel' => 'CheckData',
			)
		);
	}
	function index(){
		$data['title'] = "Data Yang telah di Survei";
		// print session = $session['sessionName']; sessionname in configsession_helper file.
		$data['session']= session();
		$this->template->load('_template', 'pelanggan/survei/@_dataSurvei', $data);
	}
	function getData(){
		$data = array( 'start' => $_POST['start'],
			'length' => $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filtertext' => $_POST['filtertext']);
		$res = $this->model->getDataAll($data); echo json_encode($res);
	}

	function putuskan(){
		$data = json_decode(file_get_contents('php://input'), true);
		// update data
		$dataPermintaan = array(
			'IDPERMINTAAN' => $data['IDPERMINTAAN'],
			'STATUS' => 'D',
			'updated_at'	=> date("Y/m/d H:i:s"),
		);

		// insert data
		$data_riwayatstatus = array(
			'ID' => uniqid(),
			'IDPELANGGAN' => $data['IDPENGGUNA'],
			'IDPERMINTAAN' => $data['IDPERMINTAAN'],
			'TGLPUTUS'	=> date("Y/m/d H:i:s")
		);

		$res = array(
			'Data_permintaan' => $dataPermintaan,
			'Data_riwayatstatus' => $data_riwayatstatus,
		);
		// echo json_encode($res); die();

		$res = $this->model->Putuskan($dataPermintaan, $data_riwayatstatus); echo $res;
	}
	function getDataSelect(){
		$res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
	}
	function save(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['IDPENGGUNA']);
		if($check == "OK"){
			$data = array(
				'IDsurvei'	=> generateKodeForm('RQ','tambah'),
				'IDPENGGUNA'	=> $data['IDPENGGUNA'],
				'STATUSALAT'	=> $data['STATUSALAT'],
				'STATUS'			=> 'PENGAJUAN',
				'IDPAKET'			=> $data['KODEPAKET'],
				'CREATED'	=> $data['CREATEBY'], /* ID STAF SESUAI JABATAN MEREKA */
			);
			// insert to table users
			$this->model->insert($data);
		}
		$res = array("result" => $check);
		echo json_encode($res);
	}
	function update(){
		$data = json_decode(file_get_contents('php://input'), true);
			$data = array(
				'IDsurvei'=> $data['IDsurvei'],
				'IDPENGGUNA'	=> $data['IDPENGGUNA'],
				'STATUSALAT'	=> $data['STATUSALAT'],
				'IDPAKET'			=> $data['KODEPAKET'],
				'updated_at'	=> date("Y/m/d H:i:s"), /* ID STAF SESUAI JABATAN MEREKA */
			);
		$res = $this->model->update($data); echo $res;
	}
	function delete(){
		$data = json_decode(file_get_contents('php://input'), true);
		$data = array( 'IDsurvei' => $data['id']);
		$res = $this->model->delete($data); echo $res;
	}
	function filterPengguna(){
		$res = $this->CheckData->getFilterPengguna($_GET['q']); echo json_encode($res);
	}

	function filterPaket(){
		$res = $this->model->getFilterPaket($_GET['q']); echo json_encode($res);
	}

	function filterLevel() {
		$res = $this->model->getFilterLevel(); echo json_encode($res);
	}

	function checkId(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['IDPENGGUNA']);
		$res = array( 'res' => $check); echo json_encode($res);
	}
	// function filterJabatan(){
	// 	$res = $this->model->getfilterJabatan($_GET['q']); echo json_encode($res);
	// }
	// function CheckPass(){
	// 	$data = json_decode(file_get_contents('php://input'), true);
	// 	$check = $this->model->checkPass($data['id']);
	// 	$res = array( 'res' => $check);
	// 	echo json_encode($res);
	// }

}
?>
