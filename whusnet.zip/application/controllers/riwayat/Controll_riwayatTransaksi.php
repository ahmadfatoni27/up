<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_riwayatTransaksi extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->model('riwayat/M__riwayatTransaksi','model');
	}
	function index(){
		$data['title'] = "Data kategori";
		$data['session']= session();
		$this->template->load('_template', 'riwayat/@_dataRiwayatTransaksi', $data);
	}
	//pemasukan
	function getDatatransaksipemasukan(){
		$data = array(
			'start' 			=> $_POST['start'],
			'length' 			=> $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filtertext' 	=> $_POST['filtertext']);
		$res = $this->model->getDataAlltransaksipemasukan($data);
		echo json_encode($res);
	}
	function getDatadetailtransaksipemasukan(){
		$data = array(
			'start' 			=> $_POST['start'],
			'length' 			=> $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filtertext' 	=> $_POST['filtertext'],
			'filterdata' 	=> $_POST['filterdata']);
		$res = $this->model->getDataAlldetailtransaksipemasukan($data);
		echo json_encode($res);
	}
	function getDatadetailpenggunatransaksipemasukan(){
		$id=$_POST['id'];
		$res = $this->model->_getlistDetailPenggunaPemasukan($id); echo json_encode($res);
	}
	// pengeluaran
	function getDatatransaksipengeluaran(){
		$data = array(
			'start' 			=> $_POST['start'],
			'length' 			=> $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filtertext' 	=> $_POST['filtertext']);
		$res = $this->model->getDataAlltransaksipengeluaran($data);
		echo json_encode($res);
	}
	function getDatadetailtransaksipengeluaran(){
		$data = array(
			'start' 			=> $_POST['start'],
			'length' 			=> $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filtertext' 	=> $_POST['filtertext'],
			'filterdata' 	=> $_POST['filterdata']);
		$res = $this->model->getDataAlldetailtransaksipengeluaran($data);
		echo json_encode($res);
	}
	function getDatadetailpenggunatransaksipengeluaran(){
		$id=$_POST['id'];
		$res = $this->model->_getlistDetailPenggunaPengeluaran($id); echo json_encode($res);
	}
	// Pembayaran
  	function getDatatransaksipembayaranTerkumpul(){
		$data = array(
			'start' 			=> $_POST['start'],
			'length' 			=> $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filtertext' 	=> $_POST['filtertext']);
		$res = $this->model->getDataAlltransaksipembayaranTerkumpul($data);
		echo json_encode($res);
	}
	function getDatatransaksipembayaranLunas(){
		$data = array(
			'start' 			=> $_POST['start'],
			'length' 			=> $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filtertext' 	=> $_POST['filtertext']);
		$res = $this->model->getDataAlltransaksipembayaranLunas($data);
		echo json_encode($res);
	}
	// backup
	function getDatatransaksipembayaran(){
		$data = array(
			'start' 			=> $_POST['start'],
			'length' 			=> $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filtertext' 	=> $_POST['filtertext']);
		$res = $this->model->getDataAlltransaksipembayaran($data);
		echo json_encode($res);
	}
	function getDatadetailtransaksipembayaran(){
		$data = array(
			'start' 			=> $_POST['start'],
			'length' 			=> $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filtertext' 	=> $_POST['filtertext'],
			'filterdata' 	=> $_POST['filterdata']);
			// $cekflag = $this->model->cekflag($data);
			// print_r($cekflag['FLAG']);die();
			$res = $this->model->getDataAlldetailtransaksipembayaran($data);
			echo json_encode($res);
		}
	function getDatadetailpenggunatransaksipembayaran(){
		$id=$_POST['id'];
		$res = $this->model->_getlistDetailPemasukan($id); echo json_encode($res);
	}






}
