<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_Backres extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->model(array(
			'setting/M__Backres'=>'model'
		)
	);
}
function index(){
	$data['title'] = "Data kategori";
	$data['session']= session();
	$this->template->load('_template', 'Settings/@_dataBackres', $data);
}
//
function db() {
	$this->load->dbutil();
	$prefs = array(
		'format' => 'zip',
		// format file
		'filename' => 'faru_dbsmw_db_backup.sql',
		// mana file
		'tables'     => array('barang', 'beritainfo', 'biaya_tagihan', 'buktitransaksilunas', 'buktitransaksipemasangan', 'buktitransaksitagihan', 'buktitransaksiterkumpul', 'cabang', 'detail_aktivasi_pppoe', 'detail_aktivasi_queue', 'detail_jurnal_harian', 'detail_komisi_mitra', 'ip_kosong', 'jabatan', 'jenka_paket', 'jurnalharian', 'kategori_barang', 'komisi', 'komisi_mitra', 'laporan_pemasangan_wifi', 'level', 'merk_barang', 'olt', 'paket', 'penagihan', 'pengguna', 'prosedure_permintaan_wifi', 'riwayatstatus_penggunabarang', 'riwayat_pelanggan', 'router', 'satuan', 'set_app', 'statusbarang', 'sumberdaya', 'survey_pemasangan_wifi', 'tampilan', 'tb_alamat', 'tb_menu', 'tb_menujabatan', 'tb_urut', 'testupload', 'tglpenagihan', 'transaksi', 'users'),
		// Array table yang akan dibackup
		'ignore'     => array(),
		// Daftar table yang tidak akan dibackup
		'add_drop'   => TRUE,
		// Untuk menambahkan drop table di backup
		'add_insert' => TRUE,
		// Untuk menambahkan data insert di file backup
		'newline'    => "\n"
		// Baris baru yang digunakan dalam file backup
	);
	$backup =& $this->dbutil->backup($prefs);
	$db_name = 'faru_dbsmw-' . date("Y-m-d-H-i-s") . '.zip'; // file name
	$save  = 'backup/db/' . $db_name; // dir name backup output destination
	write_file($save, $backup);
	force_download($db_name, $backup);
}

function restoredb(){
	$this->load->dbforge();
	$this->dbforge->drop_database('db_smw'); //success
	$this->dbforge->create_database('db_smw');  //success
	// drop semua isi table
	$temp_line = '';
	$lines = file('/backup/db/smw-master.zip');
	foreach ($lines as $line)
	{
		if (substr($line, 0, 2) == '--' || $line == '' || substr($line, 0, 1) == '#')
		continue;
		$temp_line .= $line;
		if (substr(trim($line), -1, 1) == ';')
		{
			$this->db->query($temp_line);
			$temp_line = '';
		}
	}
}




}?>
