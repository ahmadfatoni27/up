<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_Promo extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->helper(array('login','configsession','my'));cek_login();
    $this->load->model('setting/M__Promo','model');
  }
  function index()
  {
    $data['title'] = "Data Paket";
    $data['session']= session();
    $this->template->load('_template', 'Settings/@_dataPromo',$data);
  }
  function getData(){
    $data = array( 'start' => $_POST['start'],
    'length' => $_POST['length'],
    'filtervalue' => $_POST['filtervalue'],
    'filtertext' => $_POST['filtertext']);
    $res = $this->model->getDataAll($data); echo json_encode($res);
  }
  function getDataSelect(){
		$res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
	}

  function save(){
    // configurasi Upload
    $config['upload_path'] = 'upload/fotoBanner/';
    $config['allowed_types'] = 'gif|jpg|jpeg|png';
    // $config['max_size'] = 1024 * 8;
    $config['encrypt_name'] = TRUE;
    $this->load->library('upload', $config);
    $file_element_name = 'userfile';

    $dataPromo = array (
      'IDPROMO' => uniqid(),
      'TITLE' => $_POST['TITLE'],
      'DESKRIPSI' => $_POST['DESKRIPSI'],
    );
    // Upload FOTOKTP
    if ($this->upload->do_upload($file_element_name)) {
      $uploadData = $this->upload->data();
      $dataPromo['IMG'] = $uploadData['file_name'];
    }
    $res =	$this->model->insert($dataPromo);
    echo json_encode($res);
  }


  function Update(){
    // configurasi Upload
    $config['upload_path'] = 'upload/fotoBanner/';
    $config['allowed_types'] = 'gif|jpg|jpeg|png';
    // $config['max_size'] = 1024 * 8;
    $config['encrypt_name'] = TRUE;
    $this->load->library('upload', $config);
    $file_element_name = 'userfile';

    $dataPromo = array (
      'IDPROMO' => $_POST['IDPROMO'],
      'TITLE' => $_POST['TITLE'],
      'DESKRIPSI' => $_POST['DESKRIPSI'],
    );
    // Upload FOTOKTP
    if ($this->upload->do_upload($file_element_name)) {
      $uploadData = $this->upload->data();
      $dataPromo['IMG'] = $uploadData['file_name'];
    }
    $res =	$this->model->update($dataPromo);
    echo json_encode($res);
  }


	function delete(){
		$data = json_decode(file_get_contents('php://input'), true);
    // print_r($data);die();
		$data = array( 'IDPROMO' => $data['id']);
		$res = $this->model->delete($data);
		echo $res;
	}
}
  ?>
