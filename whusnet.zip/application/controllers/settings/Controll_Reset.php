<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_Reset extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->model(array(
			'setting/M__Reset'=>'model'
		)
	);
	}
	function index(){
		$data['title'] = "Data kategori";
		$data['session']= session();
		$this->template->load('_template', 'Settings/@_dataReset', $data);
	}

	function resetData(){
		$res = $this->model->reset(); echo $res;
	}




}?>
