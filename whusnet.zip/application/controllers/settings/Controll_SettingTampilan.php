<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Controll_SettingTampilan extends CI_Controller

{

	function __construct(){

		parent::__construct();

    $this->load->helper(array('login','configsession','my'));

		cek_login();

		$this->load->model('setting/M__SettingTampilan','model');

	}

	function index()

	{

		$data['title'] = "Setting Umum";

		$data['session']= session();

		$this->template->load('_template', 'Settings/@_settingTampilan',$data);

	}

	function getData(){

		$data = array( 'start' => $_POST['start'],

		'length' => $_POST['length'],

		'filtervalue' => $_POST['filtervalue'],

		'filtertext' => $_POST['filtertext']);

		$res = $this->model->getDataAll($data); echo json_encode($res);

	}

	function getDataSelect(){

		$res = $this->model->getSelectId($_POST['id']); echo json_encode($res);

	}
	function getSelectUrlTiketReview(){
		$res = $this->model->getSelectUrlReview($alt = 'url_review');
		$res = array('result'=>$res); echo json_encode($res);
	}
	function checkId(){

		$data = json_decode(file_get_contents('php://input'), true);

		$check = $this->model->checkId($data['id']);

		$res = array( 'res' => $check);echo json_encode($res);

	}

	function save(){

		$checkPengguna = $this->model->checkData($_POST['IDTAMPILAN']);

		if( $checkPengguna == "OK" ){

			// configurasi Upload

			$config['upload_path'] = 'upload/tampilan/';

			$config['allowed_types'] = 'jpg|jpeg|png';

			// $config['max_size'] = 1024 * 8;

			$config['encrypt_name'] = FALSE;

			$this->load->library('upload', $config);

			$file_element_name = 'userfile';

			// AND data insert to table testUpload

			$data = array (

				'IDTAMPILAN' 		=> $_POST['IDTAMPILAN'],

			);

			// Upload IMG

			if ($this->upload->do_upload($file_element_name)) {

				$uploadData = $this->upload->data();

				$data['IMG'] = $uploadData['file_name'];

			}

			$this->model->Update($data);

		}

		$res = array("result" => $checkPengguna);

		echo json_encode($res);

	}

}?>

