<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_SetupWA extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->helper(array('login','configsession','my'));
    cek_login();
    $this->load->model('setting/M__SetupWA','model');
  }
  function index()
  {
    $data['title'] = "";
    $data['session']= session();
    $this->template->load('_template', 'Settings/@_settingTampilan',$data);
  }
  function getData(){
    $data = array( 'start' => $_POST['start'],
    'length' => $_POST['length'],
    'filtervalue' => $_POST['filtervalue'],
    'filtertext' => $_POST['filtertext']);
    $res = $this->model->getDataAll($data); echo json_encode($res);
  }
  function getDataSelect(){
    $res = $this->model->selectDataSetup($_POST['id']); echo json_encode($res);
  }
  function selectEditTemplateWa(){
    $res = $this->model->selectEditTemplateWa($_POST['id']); echo json_encode($res);
  }

  function saveSetupWA(){
    $checkPengguna = $this->model->checkData($_POST['IDTAMPILAN']);
    if( $checkPengguna == "OK" ){

      $data = array (
        'IDTAMPILAN'    => $_POST['IDTAMPILAN'],
        'SETUP'     => $_POST['SETUP'],
      );

      $this->model->updateSetupWA($data);
    }
    $res = array("result" => $checkPengguna);
    echo json_encode($res);
  }
  function saveTemplateWA(){
    $checkPengguna = $this->model->checkDataTemplate($_POST['ID']);
    if( $checkPengguna == "OK" ){

      $data = array (
        'ID'              => $_POST['ID'],
        'TITLE'           => $_POST['TITLE'],
        'ALIAS'           => $_POST['ALIAS'],
        'TEMPLATEMESSAGE' => $_POST['TEMPLATEMESSAGE'],
      );
      $this->model->updateTemplateWA($data);
    }
    $res = array("result" => $checkPengguna);
    echo json_encode($res);
  }


}?>
