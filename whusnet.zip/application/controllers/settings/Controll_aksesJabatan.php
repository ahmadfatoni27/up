<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_aksesJabatan extends CI_Controller
{
	function __construct(){
		parent::__construct();
    $this->load->helper(array('login','configsession','my'));
		cek_login();
		$this->load->model('setting/M__DataModel');
	}
	function index(){
		$data['title'] = "Data Akses Jabatan";
		// print session = $session['sessionName']; sessionname in configsession_helper file.
		$data['session']= session();
		$data['menu'] = $this->M__DataModel->getAllMenu();
		$data['menu'] = json_encode($data['menu']);
		$this->template->load('_template', 'Settings/@_aksesjabatan', $data);
	}
	function getData(){
		$data = array( 'start' => $_POST['start'],
			'length' => $_POST['length']);
		$res = $this->M__DataModel->getDataMenuAkses($data);
		echo json_encode($res);
	}
	function getDataSelectAkses(){
		$data = json_decode(file_get_contents('php://input'), true);
		$res = $this->M__DataModel->getMenuAkses($data['id']);
		echo json_encode($res);
	}
	function filterMenu(){
		$res = $this->M__DataModel->getFilterMenu($_GET['q']);
		echo json_encode($res);
	}
	function save(){
		$data = json_decode(file_get_contents('php://input'), true);
		$listmenu = json_decode($data['listdata'], true);
		$datadel = array( 'JABATANID' => $data["JABATANID"]);
		$this->M__DataModel->deleteAllAkses($datadel);
		foreach ($listmenu as $v){
			// echo $v["menuid"];
			$datamenu = array(
				'JABATANID'=>$data["JABATANID"],
				'menuid'=>$v["menuid"],
				'status'=>$v["status"],
			);
			$this->M__DataModel->updateMenuAkses($datamenu);
		}
		echo json_encode(array("res"=>"OK"));
	}

	function checkId(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->M__DataModel->checkId($data['id']);
		$res = array( 'res' => $check);
		echo json_encode($res);
	}

}
?>
