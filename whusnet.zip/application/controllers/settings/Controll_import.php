<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_import extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->library('Excel');
		$this->load->model(array(
			'tools/M__ipkosong'=>'model',
			'CheckModel'=>'CheckData',
		));
	}
	function index(){
		$data['title'] = "Data Ip-Kosong";
		$data['session']= session();
		$this->template->load('_template', 'Settings/@_dataImport',$data);
	}
	function getData(){
		$data = array( 'start' => $_POST['start'],
		'length' => $_POST['length'],
		'filtervalue' => $_POST['filtervalue'],
		'filtertext' => $_POST['filtertext']);
		$res = $this->model->getDataAll($data); echo json_encode($res);
	}
	function getDataSelect(){ $res = $this->model->getSelectId($_POST['id']); echo json_encode($res); }
	function save(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['IPADDRESS']);
		if($check == "OK"){
			$data = array(
				'IPADDRESS' => $data('IPADDRESS'),
				'PARENT' =>  $data['PARENT'],
				'KATEGORISTOK' =>  $data['KATEGORISTOK'],
				'JENISIP' =>  $data['JENISIP'],
				'LOKASIROUTER' =>  $data['LOKASIROUTER'],
			);
			$this->model->insert($data);
		}
		$res = array("result" => $check); echo json_encode($res);
	}


	function update(){
		$data = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'IPADDRESS'    => $data['IPADDRESS'],
			'PARENT'       => $data['PARENT'],
			'KATEGORISTOK' => $data['KATEGORISTOK'],
			'JENISIP'      => $data['JENISIP'],
			'LOKASIROUTER' => $data['LOKASIROUTER'],
		);
		$res = $this->model->update($data); echo $res;
	}
	function delete(){
		$data = json_decode(file_get_contents('php://input'), true);
		$data = array( 'IPADDRESS' => $data['id']); $res = $this->model->delete($data); echo $res;
	}
	function checkId(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['id']); $res = array( 'res' => $check);echo json_encode($res);
	}



	function importPelanggan() {
		if(isset($_FILES["userfile"]["name"]))
		{
			$path = $_FILES["userfile"]["tmp_name"];
			$object = PHPExcel_IOFactory::load($path);
			foreach($object->getWorksheetIterator() as $worksheet)
			{
				$highestRow = $worksheet->getHighestRow();
				$highestColumn = $worksheet->getHighestColumn();
				for($row=2; $row<=$highestRow; $row++)
				{
					if($worksheet->getCellByColumnAndRow(1, $row)->getValue()<>null) {
						// field from Excel

						// Baca dataInPengguna dari file excel
						// $IDPENGGUNA 	= $worksheet->getCellByColumnAndRow(0, $row)->getValue(); // default =
						$IDPENGGUNA 		= generateKodeForm('PL','tambah');
						$NAMA_LENGKAP 		= $worksheet->getCellByColumnAndRow(0, $row)->getValue();
						$NOKTP_SIM 			= $worksheet->getCellByColumnAndRow(1, $row)->getValue();
						$JENISKELAMIN  		= $worksheet->getCellByColumnAndRow(2, $row)->getValue(); // select =
						$JENISPELANGGAN 	= $worksheet->getCellByColumnAndRow(3, $row)->getValue(); // select =
						$EMAIL  			= $worksheet->getCellByColumnAndRow(4, $row)->getValue();
						$HP  				= $worksheet->getCellByColumnAndRow(5, $row)->getValue(); // default
						// $IPADDR  				= $worksheet->getCellByColumnAndRow(6, $row)->getValue(); // default
						// $IDWILAYAH			= $worksheet->getCellByColumnAndRow(6, $row)->getValue(); // wajib, id yang sudah tersedia
						$IDWILAYAH			= '3502110020'; // wajib, id yang sudah tersedia
						// $KOTA  					= $worksheet->getCellByColumnAndRow(7, $row)->getValue(); // nama
						// $KEC  					= $worksheet->getCellByColumnAndRow(8, $row)->getValue(); // nama
						// $DESA  					= $worksheet->getCellByColumnAndRow(9, $row)->getValue(); // nama
						$ALMT  					= $worksheet->getCellByColumnAndRow(6, $row)->getValue();
						$NPWP  					= $worksheet->getCellByColumnAndRow(7, $row)->getValue();
						// END

						// Baca dataInUserLogin dari file Excel
						// $USERNAME  			 = $worksheet->getCellByColumnAndRow(13, $row)->getValue(); // username DEFAULT = NO-HP
						// $JABATANID 			 = $worksheet->getCellByColumnAndRow(14, $row)->getValue(); // JABATANID DEFAULT = 8 = Pelanggan

						// Baca dataInPermintaan dari file excel
						// $IDPERMINTAAN  	= $worksheet->getCellByColumnAndRow(13, $row)->getValue(); // default = RQ20000001
						$IDPERMINTAAN 		= generateKodeForm('RQ','tambah');
						// $KODEPAKET 		= $worksheet->getCellByColumnAndRow(13, $row)->getValue(); // lihat master paket
						$STATUSALAT 		= $worksheet->getCellByColumnAndRow(8, $row)->getValue(); // ATAU STATUS KONTRAK
						// $JENISJARINGAN 	= $worksheet->getCellByColumnAndRow(18, $row)->getValue(); // select =
						// $STATUS 			= $worksheet->getCellByColumnAndRow(10, $row)->getValue(); // default = ACTIVE,
						$STATUS 			= 'ACTIVE'; // default = ACTIVE,
						// $STATUSPASANG 	= $worksheet->getCellByColumnAndRow(11, $row)->getValue(); // default = Berhasil,
						$STATUSPASANG 		= 'Berhasil'; // default = Berhasil,
						// $UBAHKONEKSI 	= $worksheet->getCellByColumnAndRow(12, $row)->getValue(); // default = Berhasil,
						$UBAHKONEKSI 		= '1'; // default = Berhasil,

						// Baca dataInSurvey
						$getLatitude 		= $worksheet->getCellByColumnAndRow(9, $row)->getValue();
						$getLongitude 		= $worksheet->getCellByColumnAndRow(10, $row)->getValue();

						// MODUL INSERT BIAYA BULANAN ----------------------------------------------
						// $IDBIAYA				= $worksheet->getCellByColumnAndRow(21, $row)->getValue();
						$IDBIAYA 			= generateKodeForm('IN','tambah');
						$BIAYAPASANG		= $worksheet->getCellByColumnAndRow(11, $row)->getValue();
						$BIAYABULANAN		= $worksheet->getCellByColumnAndRow(12, $row)->getValue();
						$BIAYALAINLAIN		= $worksheet->getCellByColumnAndRow(13, $row)->getValue();
						$TOTALBIAYA			= $worksheet->getCellByColumnAndRow(14, $row)->getValue();

						$IDCABANG = '1'; // == pusat
						$JABATANID = '8'; // == pelanggan

						// AND data insert to table pengguna  [masuk]
						$dataInPengguna[] = array (
							'IDPENGGUNA' 	=> $IDPENGGUNA, // GENERATE ID AWALI DENGAN 2, 11 ANGKA
							'IDCABANG' 	 	=> $IDCABANG, // paten
							'IDJABATAN' 	=> $JABATANID, // jika pelanggan isikan 2
							'NAMADEPAN' 	=> seo_title($NAMA_LENGKAP),
							// 'NAMABELAKANG' => $data['NAMABELAKANG'],
							'KTP_SIM' => $NOKTP_SIM,
							// 'FOTOKTP' => $data['FOTOKTP'],
							'JENISKELAMIN' => $JENISKELAMIN,
							'JENISPELANGGAN' => $JENISPELANGGAN,
							'EMAIL' => $EMAIL,
							'HP' => $HP,
							// 'TLP' => $data['TLP'],
							'IDWILAYAH' => $IDWILAYAH,
							// 'KOTA' => $KOTA,
							// 'KEC' => $KEC,
							// 'DESA' => $DESA,
							'ALMT' => $ALMT,
							'STATUSAKUN' => 'aktif',
							// 'NAMAPERUSAHAAN' => $data['NAMAPERUSAHAAN'],
							'NPWP' => $NPWP,
						);

						// AND data insert to table users [masuk]
						$dataInUserLogin[] = array (
							'IDUSERS' 		=> uniqid(),
							'IDPENGGUNA' 	=> $IDPENGGUNA,
							'USERNAME'		=> $HP,
							'PASSWORD' 		=> sha1('1234567'),
							'IDCABANG'		=> $IDCABANG,
							'JABATANID'		=> $JABATANID,
							// 'ENTRYBY' 		=> $_POST['CREATEBY'],
							'ENTRYDATE'		=> date('Y-m-d'),
							'LASTIPADDR'	=> $this->input->ip_address()
						);

						// data insert to table prosedure_permintaan_wifi
						// $IDPERMINTAAN = generateKodeForm('RQ','tambah');
						$dataInPermintaan[] = array(
							'IDPERMINTAAN'	=> $IDPERMINTAAN,
							'IDPENGGUNA'	=> $IDPENGGUNA,
							'IDPAKET'		=> 'PK21000001', // default
							'STATUSALAT'	=> $STATUSALAT, // == JENIS KONTRAK
							'JENISJARINGAN' => $JENISPELANGGAN,
							'STATUS'		=> $STATUS, // Default PENGAJUAN
							'STATUSPASANG' 	=> $STATUSPASANG,
							'UBAHKONEKSI' 	=> $UBAHKONEKSI,
							'IDBIAYA' 		=> $IDBIAYA,
							// 'CREATED'	=> $_POST['CREATEBY'], /* ID PENGISI DATA */
						);

						$dataRiwayatstatus[] = array(
							'ID'						=> uniqid(),
							'IDPERMINTAAN'	=> $IDPERMINTAAN,
							'STATUSTINDAKAN'=> "Berhasil Active",
							'TGLTINDAKAN' 	=> date("Y/m/d H:i:s")
						);

						// AND data insert to table survey_pemasangan_wifi
						$dataInSurvey[]	= array (
							'IDSURVEY' 		=> uniqid(),
							'IDPERMINTAAN'=> $IDPERMINTAAN,
							'IDPENGGUNA' 	=> $IDPENGGUNA,
							'LAT' 				=> $getLatitude,
							'LONG' 				=> $getLongitude,
						);

						// AND data insert to table laporan_pemasangan_wifi
						$dataInLaporan[] = array (
							'IDREPORT' 		=> uniqid(),
							'IDPENGGUNA' 	=> $IDPENGGUNA,
							'IDPERMINTAAN'=> $IDPERMINTAAN,
							// 'IPADDR' 				=> $IPADDR,
						);

						// MODUL INSERT BIAYA BULANAN ----------------------------------------------

						$dataBiayaTagihan[] = array( //INSERT tb baiya_tagihan  [tidak masuk]
							'IDBIAYA' 			=> $IDBIAYA,
							'IDPELANGGAN' 	=> $IDPENGGUNA,
							'IDPERMINTAAN' 	=> $IDPERMINTAAN,
							'BIAYAPASANG' 	=> $BIAYAPASANG,
							'BIAYABULANAN' 	=> $BIAYABULANAN,
							'BIAYALAINLAIN' => $BIAYALAINLAIN,
							'TOTALBIAYA' 		=> $TOTALBIAYA,
						);

						$cek = array(
							"InPengguna"=>$dataInPengguna,
							"InUserLogin"=>$dataInUserLogin,
							"InPermintaan"=>$dataInPermintaan,
							"InSurvey"=>$dataInSurvey,
							"InLaporan"=>$dataInLaporan,
							"Riwayatstatus" => $dataRiwayatstatus,
							"dataBiayaTagihan" => $dataBiayaTagihan,
						);

					}
				}
				$res = json_encode(array(
					"InPengguna"=>$dataInPengguna,
					"InUserLogin"=>$dataInUserLogin,
					"InPermintaan"=>$dataInPermintaan,
					"InSurvey"=>$dataInSurvey,
					"InLaporan"=>$dataInLaporan,
					"Riwayatstatus" => $dataRiwayatstatus,
					"dataBiayaTagihan" => $dataBiayaTagihan)
				);
				// $this->CheckData->importDataPelanggan($dataInPengguna, $dataInUserLogin, $dataInPermintaan, $dataInSurvey, $dataInLaporan, $dataRiwayatstatus, $dataBiayaTagihan);
				$this->CheckData->importDataPengguna($dataInPengguna);
				$this->CheckData->importDataUserLogin($dataInUserLogin);
				$this->CheckData->importDataPermintaan($dataInPermintaan);
				$this->CheckData->importDataSurvey($dataInSurvey);
				$this->CheckData->importDataLaporan($dataInLaporan);
				$this->CheckData->importDataRiwayatStatus($dataRiwayatstatus);
				$this->CheckData->importDataBiayaTagihan($dataBiayaTagihan);
				echo $res;
				// die();

			}
		}
	}

	function ExportJurnalPemasukan(){
	 $this->load->library("excel");
	 $object = new PHPExcel();
	 $object->setActiveSheetIndex(0);
	 $table_columns = array("IDJURNALPEMASUKAN", "KODEDATA", "KATEGORI", "JUDUL", "HARGA", "QTY", "TOTAL", "KETERANGAN", "JENISBAYAR", "INFO", "NAMALENGKAP", "ALMT", "KOTA", "JENISJARINGAN", "DESA", "REKOMENDASI");
	 $column = 0;
	 foreach($table_columns as $field){
		 $object->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
		 $column++;
	 }

	 $employee_data = $this->CheckData->getdataExportJurnalPemasukan();
	 // print_r($employee_data);die();
	 $excel_row = 2;

	 foreach($employee_data as $row){
		 // print_r($row->NOTIKET);die();
		 $object->getActiveSheet()->setCellValueByColumnAndRow(0, $excel_row, $row->IDJURNALPEMASUKAN);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(1, $excel_row, $row->KODEDATA);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(2, $excel_row, $row->KATEGORI);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(3, $excel_row, $row->JUDUL);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(4, $excel_row, $row->HARGA);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(5, $excel_row, $row->QTY);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(6, $excel_row, $row->TOTAL);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(7, $excel_row, $row->KETERANGAN);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(8, $excel_row, $row->JENISBAYAR);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(9, $excel_row, $row->INFO);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(10, $excel_row, $row->NAMALENGKAP);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(11, $excel_row, $row->ALMT);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(12, $excel_row, $row->KOTA);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(13, $excel_row, $row->JENISJARINGAN);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(14, $excel_row, $row->DESA);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(15, $excel_row, $row->REKOMENDASI);
		 $excel_row++;
	 }

	 $object_writer = PHPExcel_IOFactory::createWriter($object, 'Excel5');
	 header('Content-Type: application/vnd.ms-excel');
	 header('Content-Disposition: attachment;filename="Employee Data.xls"');
	 $object_writer->save('php://output');
 }


 function ExportJurnalPengeluaran(){
	$this->load->library("excel");
	$object = new PHPExcel();
	$object->setActiveSheetIndex(0);
	$table_columns = array("IDJURNALPENGELUARAN", "KODEDATA", "KATEGORI", "JUDUL", "HARGA", "QTY", "TOTAL", "KETERANGAN", "JENISBAYAR", "INFO", "NAMALENGKAP", "ALMT", "KOTA", "JENISJARINGAN", "DESA", "REKOMENDASI");
	$column = 0;
	foreach($table_columns as $field){
		$object->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
		$column++;
	}

	$employee_data = $this->CheckData->getdataExportJurnalPengeluaran();
	$excel_row = 2;

	foreach($employee_data as $row){
		// print_r($row->NOTIKET);die();
		$object->getActiveSheet()->setCellValueByColumnAndRow(0, $excel_row, $row->IDJURNALPENGELUARAN);
		$object->getActiveSheet()->setCellValueByColumnAndRow(1, $excel_row, $row->KODEDATA);
		$object->getActiveSheet()->setCellValueByColumnAndRow(2, $excel_row, $row->KATEGORI);
		$object->getActiveSheet()->setCellValueByColumnAndRow(3, $excel_row, $row->JUDUL);
		$object->getActiveSheet()->setCellValueByColumnAndRow(4, $excel_row, $row->HARGA);
		$object->getActiveSheet()->setCellValueByColumnAndRow(5, $excel_row, $row->QTY);
		$object->getActiveSheet()->setCellValueByColumnAndRow(6, $excel_row, $row->TOTAL);
		$object->getActiveSheet()->setCellValueByColumnAndRow(7, $excel_row, $row->KETERANGAN);
		$object->getActiveSheet()->setCellValueByColumnAndRow(8, $excel_row, $row->JENISBAYAR);
		$object->getActiveSheet()->setCellValueByColumnAndRow(9, $excel_row, $row->INFO);
		$object->getActiveSheet()->setCellValueByColumnAndRow(10, $excel_row, $row->NAMALENGKAP);
		$object->getActiveSheet()->setCellValueByColumnAndRow(11, $excel_row, $row->ALMT);
		$object->getActiveSheet()->setCellValueByColumnAndRow(12, $excel_row, $row->KOTA);
		$object->getActiveSheet()->setCellValueByColumnAndRow(13, $excel_row, $row->JENISJARINGAN);
		$object->getActiveSheet()->setCellValueByColumnAndRow(14, $excel_row, $row->DESA);
		$object->getActiveSheet()->setCellValueByColumnAndRow(15, $excel_row, $row->REKOMENDASI);
		$excel_row++;
	}

	$object_writer = PHPExcel_IOFactory::createWriter($object, 'Excel5');
	header('Content-Type: application/vnd.ms-excel');
	header('Content-Disposition: attachment;filename="Employee Data.xls"');
	$object_writer->save('php://output');
}


}?>
