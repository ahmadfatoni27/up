<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_jabatan extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->model(array(
			'setting/M__DataModel'=>'M__DataModel',
			'setting/M__jabatan'=>'model'
		)
	);
}
function index(){
	$data['title'] = "Data kategori";
	// print session = $session['sessionName']; sessionname in configsession_helper file.
	$data['menu'] = $this->model->getAllMenu();
	$data['menu'] = json_encode($data['menu']);
	$data['session']= session();
	$this->template->load('_template', 'Settings/@_dataJabatan', $data);
}
function getData(){
	$data = array( 'start' => $_POST['start'],
	'length' => $_POST['length'],
	'filtervalue' => $_POST['filtervalue'],
	'filtertext' => $_POST['filtertext']);
	$res = $this->model->getDataAll($data); echo json_encode($res);
}
function getDataSelect(){
	$res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
}
function save(){
	$data = json_decode(file_get_contents('php://input'), true);
	$check = $this->model->checkId($data['ID']);
	if($check == "OK"){
		$data = array(
			'JABATAN' 	=> $data['JABATAN'],
			'IDLEVEL'	=> $data['IDLEVEL'],
			'KET' 	=> $data['KET']
		);
		// print_r($data);die();
		$res = $this->model->insert($data);
	}
	$res = array("result" => $check);
	echo json_encode($res);
}
function update(){
	$data = json_decode(file_get_contents('php://input'), true);
	$data = array(
		'ID' 	=> $data['ID'],
		'JABATAN' 	=> $data['JABATAN'],
		'IDLEVEL'	=> $data['IDLEVEL'],
		'KET' 	=> $data['KET']);
		$res = $this->model->update($data); echo $res;
	}
	function delete(){
		$data = json_decode(file_get_contents('php://input'), true);
		$data = array( 'ID' => $data['id']);
		$res = $this->model->delete($data); echo $res;
	}
	function filterLevel() {
		$res = $this->model->getdrawLevel($_GET['q']); echo json_encode($res);
	}
	function checkId(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['id']);
		$res = array( 'res' => $check); echo json_encode($res);
	}

	function getDataSelectAkses(){
		$data = json_decode(file_get_contents('php://input'), true);
		$res = $this->M__DataModel->getMenuAkses($data['id']);
		echo json_encode($res);
	}
	function saveAkses(){
		$data = json_decode(file_get_contents('php://input'), true);
		$listmenu = json_decode($data['listdata'], true);
		$datadel = array( 'JABATANID' => $data["JABATANID"]);
		$this->M__DataModel->deleteAllAkses($datadel);
		foreach ($listmenu as $v){
			// echo $v["menuid"];
			$datamenu = array(
				'JABATANID'=>$data["JABATANID"],
				'menuid'=>$v["menuid"],
				'status'=>$v["status"],
			);
			$this->M__DataModel->updateMenuAkses($datamenu);
		}
		echo json_encode(array("res"=>"OK"));
	}

}
?>
