<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_pengguna extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->model(array(
			'setting/M__pengguna'=>'model',
			'CheckModel'=>'CheckData',
		));
	}
	function index(){
		$data['title'] = "Data Pengguna";
		$data['session']= session();
		$this->template->load('_template', 'Settings/@_dataPengguna', $data);
	}
	function getData(){
		$data = array( 'start' => $_POST['start'],
		'length' => $_POST['length'],
		'filtervalue' => $_POST['filtervalue'],
		'filtertext' => $_POST['filtertext']);
		$res = $this->model->getDataAll($data); echo json_encode($res);
	}
	function getDataSelect(){
		$res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
	}
	function selectCabang() {
		$res = $this->CheckData->getSelectCabang(); $res = array('res' => $res); echo json_encode($res);
	}
	function selectJabatan() {
		$res = $this->CheckData->getSelectJabatan(); $res = array('res' => $res); echo json_encode($res);
	}
    function checkAdmin_appKeuangan() {
      $res = $this->CheckData->getCheckAdmin_appKeuangan();
      
      if($res !== "empty"){ $status = "200"; } else { $status = "404"; }
      
      $res = array(
        'status' => $status,
        'results' => $res
      ); 
      echo json_encode($res);
    }
	function save(){
		$data = json_decode(file_get_contents('php://input'), true);
		$IDPENGGUNA = generateKodeForm('PG','tambah');
		$JABATANID = $data['ID'];
		$created = $data['CREATEBY'];
		if ($data['FORMSELECT'] === "FORM PERORANGAN"){
			$data = array(
				'IDPENGGUNA' => generateKodeForm('PE','tambah'),
				'NAMADEPAN' => $data['NAMADEPAN'],
				'IDJABATAN' => $data['ID'],
				'IDCABANG' => $data['IDCABANG'],
				'NAMABELAKANG' => $data['NAMABELAKANG'],
				'HP' => $data['HP'],
				'TLP' => $data['TLP'],
				'IDWILAYAH' => $data['IDWILAYAH'],
				'KEC' => $data['KEC'],
				'KOTA' => $data['KOTA'],
				'DESA' => $data['DESA'],
				'ALMT' => $data['ALMT'],
			);
		}
		else if ($data['FORMSELECT'] === "FORM USAHA"){
			$data = array(
				'IDPENGGUNA' => generateKodeForm('US','tambah'),
				'IDCABANG' => $data['IDCABANG'],
				'IDJABATAN' => $data['ID'],
				'NAMADEPAN' => $data['NAMADEPAN'],
				'NAMABELAKANG' => $data['NAMABELAKANG'],
				'EMAIL' => $data['EMAIL'],
				'HP' => $data['HP'],
				'TLP' => $data['TLP'],
				'IDWILAYAH' => $data['IDWILAYAH'],
				'KEC' => $data['KEC'],
				'KOTA' => $data['KOTA'],
				'DESA' => $data['DESA'],
				'ALMT' => $data['ALMT'],
				'NAMAPERUSAHAAN' => $data['NAMAPERUSAHAAN'],
				'NPWP' => $data['NPWP'],
			);
		}
		else if ($data['FORMSELECT'] === "FORM PEGAWAI"){
			$data = array(
				'IDPENGGUNA' => $IDPENGGUNA,
				'IDCABANG' => $data['IDCABANG'],
				'IDJABATAN' => $data['ID'],
				'NAMADEPAN' => $data['NAMADEPAN'],
				'NAMABELAKANG' => $data['NAMABELAKANG'],
				'EMAIL' => $data['EMAIL'],
				'HP' => $data['HP'],
				'TLP' => $data['TLP'],
				'IDWILAYAH' => $data['IDWILAYAH'],
				'KEC' => $data['KEC'],
				'KOTA' => $data['KOTA'],
				'DESA' => $data['DESA'],
				'ALMT' => $data['ALMT'],
				'STATUSAKUN' => $data['STATUSAKUN'],
				'KTP_SIM' => $data['KTP_SIM'],
			);
			$dataInUserLogin = array (
				'IDUSERS' 		=> uniqid(),
				'IDPENGGUNA' 	=> $IDPENGGUNA,
				// 'USERNAME'		=> $_POST['USERNAME'],
				// 'PASSWORD' 		=> sha1('1234567'),
				'IDCABANG'		=> $data['IDCABANG'],
				'JABATANID'		=> $JABATANID,
				'ENTRYBY' 		=> $created,
				'ENTRYDATE'		=> date('Y-m-d'),
				'LASTIPADDR'	=> $this->input->ip_address()
			);
		}
		// print_r($dataInUserLogin);die();
		$res = $this->model->insert($data, $dataInUserLogin);
		$res = array("result" => $res);
		echo json_encode($res);
	}
	function update(){
		$data = json_decode(file_get_contents('php://input'), true);
		if ($data['FORMSELECT'] == "FORM PERORANGAN"){
			$data = array(
				'IDPENGGUNA' => $data['IDPENGGUNA'],
				'IDJABATAN' => $data['ID'],
				'IDCABANG' => $data['IDCABANG'],
				'NAMADEPAN' => $data['NAMADEPAN'],
				'NAMABELAKANG' => $data['NAMABELAKANG'],
				'EMAIL' => $data['EMAIL'],
				'HP' => $data['HP'],
				'TLP' => $data['TLP'],
				'KOTA' => $data['KOTA'],
				'KEC'  => $data['KEC'],
				'DESA' => $data['DESA'],
				'ALMT' => $data['ALMT'],
			);
		}
		else if ($data['FORMSELECT'] == "FORM USAHA"){
			$data = array(
				'IDPENGGUNA' => $data['IDPENGGUNA'],
				'IDJABATAN' => $data['ID'],
				'IDCABANG' => $data['IDCABANG'],
				'NAMADEPAN' => $data['NAMADEPAN'],
				'NAMABELAKANG' => $data['NAMABELAKANG'],
				'EMAIL' => $data['EMAIL'],
				'HP' => $data['HP'],
				'TLP' => $data['TLP'],
				'KOTA' => $data['KOTA'],
				'KEC'  => $data['KEC'],
				'DESA' => $data['DESA'],
				'ALMT' => $data['ALMT'],
				'NAMAPERUSAHAAN' => $data['NAMAPERUSAHAAN'],
				'NPWP' => $data['NPWP'],
			);
		}
		else if ($data['FORMSELECT'] == "FORM PEGAWAI"){
			$data = array(
				'IDPENGGUNA' => $data['IDPENGGUNA'],
				'IDJABATAN' => $data['ID'],
				'IDCABANG' => $data['IDCABANG'],
				'NAMADEPAN' => $data['NAMADEPAN'],
				'NAMABELAKANG' => $data['NAMABELAKANG'],
				'EMAIL' => $data['EMAIL'],
				'HP' => $data['HP'],
				'TLP' => $data['TLP'],
				'IDWILAYAH' => $data['IDWILAYAH'],
				'KEC'  => $data['KEC'],
				'KOTA' => $data['KOTA'],
				'DESA' => $data['DESA'],
				'ALMT' => $data['ALMT'],
				'STATUSAKUN' => $data['STATUSAKUN'],
				'KTP_SIM' => $data['KTP_SIM'],
			);
		}
		$res = $this->model->update($data); // update Pengguna
		$res = $this->model->updateUser($data); // update User
      echo $res;
	}

	function getpass(){
		$pass = "6";
		if ($pass!="") {
			$res = randomPass($pass);
			// $res = "Ok";
			echo json_encode($res);
		}
	}

	function delete(){
		$data = json_decode(file_get_contents('php://input'), true);
		$data = array( 'IDPENGGUNA' => $data['id']);
		$res = $this->model->deletepengguna($data);
		$res = $this->model->deleteuser($data);
		echo $res;
	}
	// FUNCTION FOR JABATAN TOKEN INPUT FACEBOOK.
	function filterJabatan(){
		$res = $this->model->getFilterJabatan($_GET['q']); echo json_encode($res);
	}
	// TOKEN FILTER DATA
	function filterAlamat(){
		$res = $this->CheckData->getFilterAlamat($_GET['q']); echo json_encode($res);
	}
	// FUNCTION FOR KOTA TOKEN INPUT FACEBOOK.
	function filterKota(){
		$res = $this->model->getFilterKota($_GET['q']); echo json_encode($res);
	}
	// FUNCTION FOR KOTA TOKEN INPUT FACEBOOK.
	function filterDesa(){
		$res = $this->model->getFilterDesa($_GET['q']); echo json_encode($res);
	}
	// FUNCTION FOR KOTA TOKEN INPUT FACEBOOK.
	function filterKeca(){
		$res = $this->model->getFilterKecamatan($_GET['q']); echo json_encode($res);
	}
	// FUNCTION FOR CABANG TOKEN INPUT FACEBOOK.
	function filterCabang(){
		$res = $this->model->getFilterCabang($_GET['q']); echo json_encode($res);
	}
	function checkId(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['id']);
		$res = array( 'res' => $check);echo json_encode($res);
	}
}
?>
