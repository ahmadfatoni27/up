<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Controll_snmpProtocol extends CI_Controller

{

	function __construct() {

		parent::__construct();

		$this->load->helper(array('login','configsession','my')); cek_login();

		$this->load->model('setting/M__SnmpProtocol','model');

	}

	function index(){

		$data['title'] = "Data Interkoneksi";

		$data['session']= session();

		$this->template->load('_template', 'Settings/@_setSnmpProtocol', $data);
	}

	function getData() {

		$data = array( 'start' => $_POST['start'],

			'length' => $_POST['length'],

			'filtervalue' => $_POST['filtervalue'],

			'filtertext' => $_POST['filtertext']);

		$res = $this->model->getDataAll($data); echo json_encode($res);

	}

	function getDataSelectSession() {

		$res = $this->model->getSelectIdSession($_POST['id']); echo json_encode($res);

	}

	function sambungkan() {

		$data = json_decode(file_get_contents('php://input'), true);

		$data = array(

			'IP_ROUTER' 	=> $data['IP_ROUTER'],

			'STATUSROUTER'  => '1',

		);

		$res = $this->model->updateRouter($data); echo $res;

	}

	function checkId()

	{

		$data = json_decode(file_get_contents('php://input'), true);

		$check = $this->model->checkId($data['id']);

		$res = array( 'res' => $check); echo json_encode($res);

	}

	function saveBisnis(){

		$data = json_decode(file_get_contents('php://input'), true);

		$data = array(

			'ID' => "1",

			'NAMA' => $data['NAMA'],

			'ALAMAT' => $data['ALAMAT'],

			'KONTAK' => $data['KONTAK'],

		);

		$res = $this->model->updateBisnis($data); echo $res;

	}

	function getDataSelectBisnis(){

		$res = $this->model->getSelectIdBisnis(); echo json_encode($res);

	}

}?>

