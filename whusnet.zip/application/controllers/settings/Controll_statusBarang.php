<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_statusBarang extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->model('setting/M__settingBarang','model');
	}
	function index(){
		$data['title'] = "Data Alat";
		// print session = $session['sessionName']; sessionname in configsession_helper file.
		$data['session']= session();
		$this->template->load('_template', 'Settings/@_dataStatusBarang', $data);
	}
	function getData(){
		$data = array( 'start' => $_POST['start'],
			'length' => $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filtertext' => $_POST['filtertext']);
		$res = $this->model->getDataAll($data); echo json_encode($res);
	}

	function getDataRiwayat(){
		$data = json_decode(file_get_contents('php://input'), true);

		$data = array( 'start' => $_POST['start'],
			'length' => $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filterriwayat' => $_POST['filterriwayat'],
			'filtertext' => $_POST['filtertext']);
		$res = $this->model->getDataAllRiwayat($data); echo json_encode($res);
	}

	function getDataSelect(){
		$res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
	}
	function save(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['IDPENGGUNA']);
		if($check == "OK"){
			$data = array(
				'IDUSERS' 		=> uniqid(),
				'IDPENGGUNA' 	=> $data['IDPENGGUNA'],
				'USERNAME'		=> $data['USERNAME'],
				'PASSWORD' 		=> MD5('1234567'),
				'IDCABANG'		=> $data['IDCABANG'],
				'JABATANID'		=> $data['IDJABATAN'],
				'ENTRYBY' 		=> $data['CREATEBY'],
				'ENTRYDATE'		=> date('Y-m-d'),
				'LASTIPADDR'	=> $this->input->ip_address()
			);
			// insert to table users
			$this->model->insert($data);
		}
		$res = array("result" => $check); echo json_encode($res);
	}
	function update(){
		$data = json_decode(file_get_contents('php://input'), true);
		if ($data['changePass']==true) {
			$data = array(
				'IDUSERS' 	=> $data['IDUSERS'],
				'USERNAME'	=> $data['USERNAME'],
				'PASSWORD' 	=> md5($data['PASSWORDBARU']),
				'ENTRYBY' 	=> $data['CREATEBY'],
				'LASTLOGIN'	=> date('Y-m-d'),
				'LASTIPADDR'=> $this->input->ip_address()
			);
		} else{
			$data = array(
				'IDUSERS' 	=> $data['IDUSERS'],
				'USERNAME'	=> $data['USERNAME'],
				'ENTRYBY' 	=> $data['CREATEBY'],
				'LASTLOGIN'	=> date('Y-m-d'),
				'LASTIPADDR'=> $this->input->ip_address()
			);
		}
			// print_r($data);die();
		$res = $this->model->update($data); echo $res;
	}
	function delete(){
		$data = json_decode(file_get_contents('php://input'), true);
		$data = array( 'IDUSERS' => $data['id']);
		$res = $this->model->delete($data); echo $res;
	}

	function filterMerkBarang(){
		$res = $this->model->getFilterMerkBarang($_GET['q']); echo json_encode($res);
	}

	function filterJabatan(){
		$res = $this->model->getfilterJabatan($_GET['q']); echo json_encode($res);
	}
	function CheckPass(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkPass($data['id']);
		$res = array( 'res' => $check); echo json_encode($res);
	}
	function checkId(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['id']);
		$res = array( 'res' => $check); echo json_encode($res);
	}


}
?>
