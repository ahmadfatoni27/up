<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_users extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->model('setting/M__users','model');
	}
	function index(){
		$data['title'] = "Data Users";
		// print session = $session['sessionName']; sessionname in configsession_helper file.
		$data['session']= session();
		$this->template->load('_template', 'Settings/user/@_dataUsers', $data);
	}
	function getData(){
		$data = array( 'start' => $_POST['start'],
			'length' => $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filtertext' => $_POST['filtertext']);
		$res = $this->model->getDataAll($data);
		echo json_encode($res);
	}
	function getDataSelect(){
		$res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
	}
	function getCheckKoneksi(){
    $res = $this->model->checkKoneksi($_POST['id']); echo json_encode($res);
  }
  function updateKoneksi(){
    // update data prosedure_permintaan_wifi, field UBAHKONEKSI
    $data = array(
      'IDPENGGUNA' 			=> $_POST['IDPENGGUNA'],
      'AKSESAPPPELANGGANID' => $_POST['AKSESAPPPELANGGANID']
    );
    $res = $this->model->DoUpdateKoneksi($data); echo $res;
  }
	function save(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['IDPENGGUNA']);
		// $akses = $data['AKSESANDROID'];
		if($check == "OK"){
			if ($data['AKSESANDROID'] === true) {
				$data = array(
					'IDUSERS' 		=> uniqid(),
					'IDPENGGUNA' 	=> $data['IDPENGGUNA'],
					'USERNAME'		=> $data['USERNAME'],
					'PASSWORD' 		=> sha1('1234567'),
					'IDCABANG'		=> $data['IDCABANG'],
					'JABATANID'		=> $data['IDJABATAN'],
					'AKSESANDROID'	=> "1",
					'ENTRYBY' 		=> $data['CREATEBY'],
					'ENTRYDATE'		=> date('Y-m-d'),
					'LASTIPADDR'	=> $this->input->ip_address()
				);
			}else {
				$data = array(
					'IDUSERS' 		=> uniqid(),
					'IDPENGGUNA' 	=> $data['IDPENGGUNA'],
					'USERNAME'		=> $data['USERNAME'],
					'PASSWORD' 		=> sha1('1234567'),
					'IDCABANG'		=> $data['IDCABANG'],
					'JABATANID'		=> $data['IDJABATAN'],
					'AKSESANDROID'	=> "0",
					'ENTRYBY' 		=> $data['CREATEBY'],
					'ENTRYDATE'		=> date('Y-m-d'),
					'LASTIPADDR'	=> $this->input->ip_address()
				);
			}
			// print_r($data);die();
			// insert to table users
			$this->model->insert($data);
		}
		$res = array("result" => $check);
		echo json_encode($res);
	}
	function update(){
		$data = json_decode(file_get_contents('php://input'), true);
		if ($data['AKSESANDROID']== true ) { $akses = "1"; } else { $akses = "0"; }

		if ($data['ASADMIN_APPKEUANGAN']== true) { $asadmin = "true"; } else { $asadmin = ""; }

		if ($data['changePass']==true){
			if ($data['USERNAME']!="" OR $data['PASSWORDBARU'] != "") {
				$data = array(
					'IDUSERS' 		=> $data['IDUSERS'],
					'USERNAME'		=> $data['USERNAME'],
					'PASSWORD' 		=> sha1($data['PASSWORDBARU']),
					'ENTRYBY' 		=> $data['CREATEBY'],
					'LASTLOGIN'		=> date('Y-m-d'),
					'AKSESANDROID'=> $akses,
					'ASADMIN_APPKEUANGAN' => $asadmin,
					'LASTIPADDR'	=> $this->input->ip_address()
				);
			}
			else {
				$data = array(
					'IDUSERS' 	=> $data['IDUSERS'],
					'USERNAME'	=> $data['USERNAME'],
					'ENTRYBY' 	=> $data['CREATEBY'],
					'LASTLOGIN'	=> date('Y-m-d'),
					'AKSESANDROID'=> $akses,
					'ASADMIN_APPKEUANGAN' => $asadmin,
					'LASTIPADDR'=> $this->input->ip_address()
				);
			}
		}
		// else if($data['changePassAwal']==true) {
		// 	if ($data['USERNAME']!="") {
		// 		$data = array(
		// 			'IDUSERS' 	=> $data['IDUSERS'],
		// 			'USERNAME'	=> $data['USERNAME'],
		// 			'PASSWORD' 	=> sha1('1234567'),
		// 			'ENTRYBY' 	=> $data['CREATEBY'],
		// 			'LASTLOGIN'	=> date('Y-m-d'),
		// 			'AKSESANDROID'=> $akses,
		// 			'ASADMIN_APPKEUANGAN' => $asadmin,
		// 			'LASTIPADDR'=> $this->input->ip_address()
		// 		);
		// 	}else {
		// 		$data = array(
		// 			'IDUSERS' 	=> $data['IDUSERS'],
		// 			'PASSWORD' 	=> sha1('1234567'),
		// 			'ENTRYBY' 	=> $data['CREATEBY'],
		// 			'LASTLOGIN'	=> date('Y-m-d'),
		// 			'AKSESANDROID'=> $akses,
		// 			'ASADMIN_APPKEUANGAN' => $asadmin,
		// 			'LASTIPADDR'=> $this->input->ip_address()
		// 		);
		// 	}
		// }
		else{
			if ($data['USERNAME']!="") {
				$data = array(
					'IDUSERS' 	=> $data['IDUSERS'],
					'USERNAME'	=> $data['USERNAME'],
					'ENTRYBY' 	=> $data['CREATEBY'],
					'LASTLOGIN'	=> date('Y-m-d'),
					'AKSESANDROID'=> $akses,
					'ASADMIN_APPKEUANGAN' => $asadmin,
					'LASTIPADDR'=> $this->input->ip_address()
				);
			}else {
				$data = array(
					'IDUSERS' 	=> $data['IDUSERS'],
					'ENTRYBY' 	=> $data['CREATEBY'],
					'LASTLOGIN'	=> date('Y-m-d'),
					'AKSESANDROID'=> $akses,
					'ASADMIN_APPKEUANGAN' => $asadmin,
					'LASTIPADDR'=> $this->input->ip_address()
				);
			}
		}
		// print_r($data);die();
		$res = $this->model->update($data); echo json_encode($res);
	}
	function delete(){
		$data = json_decode(file_get_contents('php://input'), true);
		$data = array( 'IDUSERS' => $data['id']);
		$res = $this->model->delete($data);
		echo $res;
	}

	function filterPengguna(){
		$res = $this->model->getFilterPengguna($_GET['q']); echo json_encode($res);
	}

	function filterJabatan(){
		$res = $this->model->getfilterJabatan($_GET['q']); echo json_encode($res);
	}
	function CheckPass(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkPass($data['id']);
		$res = array( 'res' => $check);
		echo json_encode($res);
	}
	function checkId(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['id']);
		$res = array( 'res' => $check); echo json_encode($res);
	}


}
?>
