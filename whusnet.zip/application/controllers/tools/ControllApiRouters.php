<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class ControllApiRouters extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->model(array(
			'tools/M__Routers' => 'model',
		));
		// $data['session_router']= session_router();
	}



	

 


}?>
