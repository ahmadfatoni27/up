<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_Routers extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('login','configsession','my'));cek_login();
		$this->load->model(array(
			'tools/M__Routers' => 'model',
		));
	}
	function index()
	{
		$data['title'] = "Data Router";
		$data['session']= session();
		$this->template->load('_template', 'tools/@_dataRouters',$data);
	}
	function getData() {
		$data = array( 'start' => $_POST['start'],
			'length' => $_POST['length'],
			'filtervalue' => $_POST['filtervalue'],
			'filtertext' => $_POST['filtertext']);
		$res = $this->model->getDataAll($data); echo json_encode($res);
	}
	function getDataSelect() {
		$res = $this->model->getSelectId($_POST['id']); echo json_encode($res);
	}
	function save(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['IP_ROUTER']);
		if($check == "OK"){
			$data = array(
				'IP_ROUTER'   =>  $data['IP_ROUTER'],
				'NAMA_ROUTER' =>  $data['NAMA_ROUTER'],
				'USERNAME'    =>  $data['USERNAME_ROUTER'],
				'PASSWORD'    =>  $data['PASSWORD_ROUTER'],
				'PORT'    	  =>  $data['PORT_ROUTER'],
				'STATUSROUTER'=>  '0',
			);
			// print_r($data);die();
			$this->model->insert($data);
		}
		$res = array("result" => $check);
		echo json_encode($res);
	}
	function update(){
		$data = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'IP_ROUTER'   =>  $data['IP_ROUTER'],
			'NAMA_ROUTER' =>  $data['NAMA_ROUTER'],
			'USERNAME'    =>  $data['USERNAME'],
			'PASSWORD'    =>  md5($data['PASSWORD']),
		);
		$res = $this->model->update($data); echo $res;
	}
	function delete(){
		$data = json_decode(file_get_contents('php://input'), true);
		$data = array( 'IP_ROUTER' => $data['id']);
		$res = $this->model->delete($data);
		echo $res;
	}
	function checkId(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['id']);
		$res = array( 'res' => $check);echo json_encode($res);
	}
	// cek status router aktif / non aktif
	function getCheckKoneksi() {
		$res = $this->model->checkKoneksi($_POST['id']); echo json_encode($res);
	}

	// FUNGSI API ROUTER
	function func_Add_queue() {
		$data = json_decode(file_get_contents('php://input'), true);
		$this->load->model('CheckModel');

		if ($data['PARENTTERDAFTAR'] == "") {
			$parent = 'none';
			$name 	= $data['PARENT'];
		} else {
			$parent = $data['PARENTTERDAFTAR'];
			$name 	= $data['PARENT'];
		}
		$generate = generateKode('PQ','tambah');
		$pengguna = $data['IDPENGGUNA'];
		$data = array(
			"hostname" 			=> $data['host'], 					// SESSION ROUTER
			"username" 			=> $data['username_router'], 		// SESSION ROUTER
			"password" 			=> $data['password_router'], 		// SESSION ROUTER
			'IDDETAILAKTIVASIQUEUE'	=> $generate,
			// "STATUSKONEKSI"	=> $data['STATUSKONEKSI'], 			// SESSION ROUTER
			"target" 			=> $data['IPADDRESS'],  			// ADD NEW QUEUE
			'name' 				=> $name, 				// ADD NEW QUEUE str_replace('-',' ', 	//
			'comment' 			=> $data['NAMADEPAN'].'-'.$data['JENISJARINGAN'].'-'.$data['LOKASIROUTER'],
			'maxlimit' 	  		=> $data['SPEEDUP'].'M/'.$data['SPEEDUP'].'M',
			'limitat' 	  		=> "500k/500k",
			'parent'			=> $parent,
		);
		// print_r($data);die();
		$queue = array(
			'IDDETAILAKTIVASIQUEUE'	=> $generate,
			'IDPENGGUNA'			=> $pengguna,
		);
		// $dataDataPermintaan = array(
		// 	'UBAHKONEKSI' 		=> 1 // Tersambung
		// );
		$res = $this->CheckModel->insertQUEUE($queue);
		$res = $this->CheckModel->updateIpKosong($data);
		$this->curl->simple_get($this->simpleAdd_queue($data));
		$res = json_encode(array("result"=>$res)); echo $res;
	}

	function simpleAdd_queue($data) {
		if ($this->routerosapi->connect($data['hostname'], $data['username'], $data['password']) == true ) {
			$this->routerosapi->write('/queue/simple/add',false);
			$this->routerosapi->write('=name='.$data['name'], false);
			$this->routerosapi->write('=parent='.$data['parent'], false);
			$this->routerosapi->write('=target='.$data['target'],false);   			 // 	IP
			$this->routerosapi->write('=max-limit='.$data['maxlimit'],false);   //   2M/2M   [TX/RX]
			$this->routerosapi->write('=limit-at='.$data['limitat'],false);   //   2M/2M   [TX/RX]
			$this->routerosapi->write('=comment='.$data['comment'],true);     // 	 coment
			$READ  = $this->routerosapi->read(false);
			$ARRAY = $this->routerosapi->parseResponse($READ);
			// echo "success";
			$this->routerosapi->disconnect();
		}
	}

	// FUNGSI ppp Secret add (pppoe)
	function func_Add_ppp() {
		$data = json_decode(file_get_contents('php://input'), true);
		$this->load->model('CheckModel');
		if ($data['JENISIPPPP'] == "PPPOE") {
			$jenis = 'pppoe';
		} else {
			$jenis = 'pppoe';
		}
		$generate = generateKode('PP','tambah');
		$pengguna = $data['IDPENGGUNA'];
		$data = array(
			"hostname" 			=> $data['host'], 					// SESSION ROUTER
			"username" 			=> $data['username_router'],		// SESSION ROUTER
			"password" 			=> $data['password_router'],		// SESSION ROUTER
			'IDDETAILAKTIVASIPPPOE'		=> $generate,
			'name' 				=> $data['USERNAMEPPP'],
			'passwordppp' 		=> $data['PASSPPP'],
			'jenis' 			=> $jenis,
			// 'jenis' 			=> $data['JENISIPPPP'],
			'profile' 			=> $data['PROFILPPP'],
			"ip" 	  			=> $data['IPADDRESSPPP'],
		);
		$ppp = array(
			'IDDETAILAKTIVASIPPPOE'		=> $generate,
			'IDPENGGUNA'				=> $pengguna,
		);
		// print_r($data);print_r($ppp);die();
		$res = $this->CheckModel->insertPPP($ppp);
		$res = $this->CheckModel->updateIpKosongppp($data);
		$this->curl->simple_get($this->simpleAdd_ppp($data));
		$res = json_encode(array("result"=>$res));
		echo $res;
	}
	function simpleAdd_ppp($data) {
		if ($this->routerosapi->connect($hostname=$data['hostname'], $username=$data['username'], $password=$data['password']) == true)
		{
			$this->routerosapi->write('/ppp/secret/add', false);
			$this->routerosapi->write('=name='.$data['name'], false);
			$this->routerosapi->write('=password='.$data['passwordppp'], false);
			$this->routerosapi->write('=service='.$data['jenis'], false);
			$this->routerosapi->write('=profile='.$data['profile'], false);
			// $this->routerosapi->write('=local-address='.$data['hostname'], false);
			$this->routerosapi->write('=remote-address='.$data['ip'], false);
			$this->routerosapi->write('=comment='.$data['jenis'].'-'.$data['hostname'],true);     // 	 coment
			$READ  = $this->routerosapi->read(false);
			$ARRAY = $this->routerosapi->parseResponse($READ);
			// echo "success";
			$this->routerosapi->disconnect();
		}
	}

	// Function Connect Router
	function func_conn_router() {
		$data = json_decode(file_get_contents('php://input'), true);
		$hostname = $data['IP_ROUTER'];
		$username = $data['USERNAME_ROUTER'];
		$password = $data['PASSWORD_ROUTER'];
		$port 	  = $data['PORT_ROUTER'];
		$NAMA_ROUTER = $data['NAMA_ROUTER'];
		$con = $this->connrouter($hostname, $username, $password, $port, $data);
		// $con = $this->curl->simple_get($this->connrouter($hostname, $username, $password, $data));

		$data = array(
			"IP_ROUTER"  		=> $hostname,
			"NAMA_ROUTER"  		=> $NAMA_ROUTER,
			"USERNAME"  		=> $username,
			"PASSWORD"  		=> $password,
			// "PORT"  			=> $port,
			"STATUSROUTER"		=> $this->routerosapi->connect($hostname, $username, $password, $port),
		);

		// $this->session->set_userdata($data); //  Create Session.
		echo json_encode(array("result"=>$data));
	}
	// SCRIPT TO ROUTER OS API
	function connrouter($hostname, $username, $password, $port, $data) {
		// if($this->routerosapi->connect($hostname, $username, $password, $port) == true ) {
		if($this->routerosapi->connect($hostname, $username, $password, $port) == true ) {
			$this->session->set_userdata($data); //  Create Session.
			$this->routerosapi->connect($hostname, $username, $password, $port);
			$this->routerosapi->disconnect();
		} else {
			redirect(base_url('form-snmp-protocol','refresh'));
		}
	}

	// Function disConnect Router
	function func_disconn_router() {
		$hostname 	 = $_POST['IP_ROUTER'];
		$data = array(
			"IP_ROUTER"  		=> $hostname,
			"STATUSROUTER"		=> '0',
		);
		cek_sessionRouter();
		$cek = $this->session->flashdata('result');
		if ($cek === 'true') {

			$data2 = array ( // create session router
				'host',
				'nama',
				'username_router',
				'password_router',
				'port_router',
				'status_router',
				'is_logged', 
			);
			$this->session->unset_userdata($data2);
		}
		$this->routerosapi->disconnect();
		$this->model->updateStatusRouter($data);
		echo json_encode(array("result"=>$data));
	}

// Function Connect Router
	function sambungkan_router() {
		$hostname 	 = $_POST['IP_ROUTER'];
		$username 	 = $_POST['USERNAME'];
		$password 	 = $_POST['PASSWORD'];
		$NAMA_ROUTER = $_POST['NAMA_ROUTER'];
		$port 		 = $_POST['PORT_ROUTER'];
		$STATUSROUTER= $_POST['STATUSROUTER'];

		$data = array(
			"IP_ROUTER"  		=> $hostname,
			"NAMA_ROUTER"  		=> $NAMA_ROUTER,
			"USERNAME"  		=> $username,
			"PASSWORD"  		=> $password,
			"PORT"  			=> $port,
			"STATUSROUTER"		=> '1',
		);
	$data2 = array ( // create session router
		'host' 			=> $_POST['IP_ROUTER'],
		'NAMA_ROUTER' 	=> $_POST['NAMA_ROUTER'],
		'USERNAME' 		=> $_POST['USERNAME'],
		'PASSWORD'		=> $_POST['PASSWORD'],
		'PORT'			=> $_POST['PORT_ROUTER'],
		'STATUSROUTER'	=> $_POST['STATUSROUTER'],
		'is_logged'  	=> true,
	);

	// print_r($data2); die();
		$this->session->set_userdata($data2); //  Create Session.
		// $cek = $this->curl->simple_get($this->connrouterAgain( $hostname, $username, $password, $port, $data ));
		$cek = $this->connrouterAgain( $hostname, $username, $password, $port, $data );
		echo json_encode(array("result"=> $data2));
	}

	// SCRIPT TO ROUTER OS API
	function connrouterAgain( $hostname, $username, $password, $port, $data ) {
			set_time_limit(7); // this way
			ini_set('max_execution_time', 7); // or this way
			if($this->routerosapi->connect($hostname, $username, $password, $port) == true ) {
				$this->model->updateStatusRouter($data);
				$this->routerosapi->connect($hostname, $username, $password, $port);
				$this->routerosapi->disconnect();
			} else {
				redirect(base_url('form-snmp-protocol'));
			}
		}

	function deleteSessionRouter(){
		$data = json_decode(file_get_contents('php://input'), true);
		$data = array('IP_ROUTER' => $data['id']);
		$res = $this->model->deleteSessionRouter($data); echo $res;
	}


	// function clearSessionRouter()
	// {
	// 	$session = session();
	// 	// $array_items = array('username', 'email');
	// 	$checkSession = array(
	// 		'host', 'nama', 'username', 'password',
	// 	);
	// 	// $this->session->unset_userdata($checkSession);
	// 	unset($session['host']);
	// 	$cek = $session['host'];
	// 	print_r($cek);die();
	// 	// redirect('tools/Controll_Routers');
	// }



}?>
