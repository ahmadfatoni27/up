<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_ipkosong extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->helper(array('login','configsession','my'));cek_login();
    $this->load->model(array(
      'tools/M__ipkosong'=>'model',
      'CheckModel'=>'CheckData',
    ));
  }
  function index(){
    $data['title'] = "Data Ip-Kosong";
    $data['session']= session();
    $this->template->load('_template', 'tools/@_dataIpkosong',$data);
  }
  function getData(){
    $data = array( 'start' => $_POST['start'],
    'length' => $_POST['length'],
    'filtervalue' => $_POST['filtervalue'],
    'filtertext' => $_POST['filtertext']);
    $res = $this->model->getDataAll($data); echo json_encode($res);
  }
  function getDataSelect(){ $res = $this->model->getSelectId($_POST['id']); echo json_encode($res); }
  function save(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['IPADDRESS']);
		if($check == "OK"){
      $data = array(
        'IPADDRESS' => $data('IPADDRESS'),
        'PARENT' =>  $data['PARENT'],
        'KATEGORISTOK' =>  $data['KATEGORISTOK'],
        'JENISIP' =>  $data['JENISIP'],
        'LOKASIROUTER' =>  $data['LOKASIROUTER'],
        'LOKASIOLT'    =>  $data['LOKASIOLT'],
      );
			$this->model->insert($data);
		}
		$res = array("result" => $check); echo json_encode($res);
	}
	function update(){
		$data = json_decode(file_get_contents('php://input'), true);
    $data = array(
      'IPADDRESS'    => $data['IPADDRESS'],
      'PARENT'       => $data['PARENT'],
      'KATEGORISTOK' => $data['KATEGORISTOK'],
      'JENISIP'      => $data['JENISIP'],
      'LOKASIROUTER' => $data['LOKASIROUTER'],
      'LOKASIOLT'    =>  $data['LOKASIOLT'],
    );
		$res = $this->model->update($data); echo $res;
	}
	function delete(){
		$data = json_decode(file_get_contents('php://input'), true);
		$data = array( 'IPADDRESS' => $data['id']); $res = $this->model->delete($data); echo $res;
	}
	function checkId(){
		$data = json_decode(file_get_contents('php://input'), true);
		$check = $this->model->checkId($data['id']); $res = array( 'res' => $check);echo json_encode($res);
	}

  function import() {
    $this->load->library('Excel');

    if(isset($_FILES["userfile"]["name"]))
    {
      $path = $_FILES["userfile"]["tmp_name"];
      $object = PHPExcel_IOFactory::load($path);
      foreach($object->getWorksheetIterator() as $worksheet)
      {
        $highestRow = $worksheet->getHighestRow();
        $highestColumn = $worksheet->getHighestColumn();
        for($row=2; $row<=$highestRow; $row++)
        {
          if($worksheet->getCellByColumnAndRow(1, $row)->getValue()<>null) {
          $AMBILIPADDRESS     = $worksheet->getCellByColumnAndRow(0, $row)->getValue();
          $AMBILPARENT        = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
          $AMBILKATEGORISTOK  = $worksheet->getCellByColumnAndRow(2, $row)->getValue();
          $AMBILJENISIP       = $worksheet->getCellByColumnAndRow(3, $row)->getValue();
          $AMBILLOKASI        = $worksheet->getCellByColumnAndRow(4, $row)->getValue();
          $AMBILLOKASIOLT     = $worksheet->getCellByColumnAndRow(5, $row)->getValue();

            $data[] = array(
              'IPADDRESS'     => $AMBILIPADDRESS,
              'PARENT'        => $AMBILPARENT,
              'KATEGORISTOK'  => $AMBILKATEGORISTOK,
              'JENISIP'       => $AMBILJENISIP,
              'LOKASIROUTER'  => $AMBILLOKASI,
              'LOKASIOLT'     => $AMBILLOKASIOLT,
            );
          }
        }
        $res = json_encode(array('res'=>$data));
        // print_r(json_encode(array('res'=>$data))); die();
        $this->model->insert($data); echo $res;
      }
    }
  }



}?>
