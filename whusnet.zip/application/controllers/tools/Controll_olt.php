<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_olt extends CI_Controller
{
  function __construct() {
    parent::__construct();
    $this->load->helper(array('login','configsession','my'));cek_login();
    $this->load->model( array(
      'tools/M__Olt' => 'model',
      'CheckModel' => 'CheckData',
    ));
  }
  function index(){
    $data['title'] = "Data Olt";
    $data['session']= session();
    $this->template->load('_template', 'tools/@_dataOlt',$data);
  }
  function GetSelectNoOnu()
  {
    $query = $this->db->query('SELECT n.noonu as NOONU FROM noonu1024 as n WHERE NOT EXISTS
      ( SELECT sr.NOONU FROM olt_slot_register as sr WHERE sr.NOONU = n.noonu ) ORDER BY n.noonu DESC' );
    $record = $query->result();
    $res = json_encode($record, true);
    echo $res;
  }

  // MODUL ONU BELUM AKTIF
  function getDataOnuBelumAktif(){
    $data = array( 'start' => $_POST['start'],
      'length' => $_POST['length'],
      'filtervalue' => $_POST['filtervalueonubelumaktif'],
      'filtertext' => $_POST['filtertextonubelumaktif']);
    $res = $this->model->getDataAllOnuBelumAktif($data); echo json_encode($res);
  }
  function getDataSelectOnubelumaktif(){
    $res = $this->model->getSelectIdOnubelumaktif($_POST['id']); echo json_encode($res);
  }

  function getDataSelectPaket(){
    $res = $this->CheckData->getSelectPaket(); $res=array('res' => $res); echo json_encode($res);
  }

  function filterPengguna() { $res = $this->CheckData->getFilterPengguna_active($_GET['q']); echo json_encode($res); } // TOKEN FILTER DATA

    function getFilterIpKosong() { $res = $this->CheckData->getFilterIpKosong($_GET['q']); echo json_encode($res); } // TOKEN FILTER DATA

    function regisOnu() {
      $data = json_decode(file_get_contents('php://input'), true);
      $check = $this->model->checkId($data['INDEXONU']);
      if($check == "OK"){
      //   $data = array(
      //   'INDEXONU'      =>  $data['INDEXONU'], //Index Onu Uncfg
      //   'NOONU'         =>  $data['NOONU'], // NO ONU
      //   'NAMAPELANGGAN' =>  $data['NAMADEPAN'], // NAMA PELANGGAN
      //   'IDPELANGGAN'   =>  $data['IDPENGGUNA'], // NAMA PELANGGAN
      //   'SN'            =>  $data['SN'], // SN
      //   'PROFILKONEKSI' =>  $data['PROFILKONEKSI'], //PROFIL KONEKSI
      //   'VLAN'          =>  $data['VLAN'], // VLAN
      //   'USERPPP'       =>  $data['USERPPP'], //PPPOE USERNAME
      //   'PASSPPP'       =>  $data['PASSPPP'], //PPPOE PASSWORD
      //   'PROFILPPP'     =>  $data['PROFILPPP'], // PROFIL PPP
      //   'IPADDRESS'     =>  $data['IPADDRESS'], // IP ADDRESS
      //   // TAMBAH FILD  =>
      //   'LOKASIOLT'     =>  $data['LOKASIOLT'], // LOKASI OLT
      //   'JENISLAYANAN'  =>  $data['JENISLAYANAN'], // JENIS LAYANAN
      //   'JENISDIAL'     =>  $data['JENISDIAL'], // JENIS DIAL
      //   'PAKET'         =>  $data['PAKET'], // PAKET
      //   // DARI MESIN OLT
      //   'IDMESIN'            => $data['IDMESIN'],
      //   'PHASE_STATE'        => $data['PHASE_STATE'],
      //   'ADMIN_STATE'        => $data['ADMIN_STATE'],
      //   'OMCC_STATE'         => $data['OMCC_STATE'],
      //   'CHANNEL'            => $data['CHANNEL'],
      //   'RX_POWER'           => $data['RX_POWER'],
      //   'PREVIOUS_RXPOWER'   => $data['PREVIOUS_RXPOWER'],
      //   'UPLOAD_RX'          => $data['UPLOAD_RX'],
      //   'UPLOAD_TX'          => $data['UPLOAD_TX'],
      //   'UPLOAD_ATTENUATION' => $data['UPLOAD_ATTENUATION'],
      //   'DOWN_RX'            => $data['DOWN_RX'],
      //   'DOWN_TX'            => $data['DOWN_TX'],
      //   'DOWN_ATTENUATION'   => $data['DOWN_ATTENUATION'],
      //   'STATUS_SIGNAL'      => $data['STATUS_SIGNAL'],
      //   'PAKETQUEUE'         => $data['PAKETQUEUE'],
      //   'PARENT'             => $data['PARENT'],
      // );
      // $this->model->registrasiOnu($data);
      $insertaktivasi = array(
        'IDAKTIFASI' => $data['INDEXONU'] ,
        'IDPELANGGAN' => $data['IDPENGGUNA'] ,
        'INDEXONU' => $data['INDEXONU'] ,
        'NOONU' => $data['NOONU'] ,
        'INDEXONUAKTIF' => $data['INDEXONUAKTIF'] ,
        'IDMESIN' => $data['IDMESIN'] ,
        'SN' => $data['SN'] ,
        'IDONUREGISTER' => $data['IDONUREGISTER'] ,
        'JENISDIAL' => $data['JENISDIAL'] ,
        'VLAN' => $data['VLAN'] ,
        'PROFIL_PPP' => $data['PROFILPPP'] ,
        'PPPOE_USERNAME' => $data['USERPPP'] ,
        'PPPOE_PASSWORD' => $data['PASSPPP'] ,
        'PAKET' => $data['PAKET'] ,
        'IPADDRESS' => $data['IPADDRESS'] ,
        'LOKASIOLT' => $data['LOKASIOLT'] ,
        'PROFIL_KONEKSIOLT' => $data['PROFILOLT'] ,
        'TYPEMODEM' => $data['TYPEMODEM'] ,
        'PROFIL_KONEKSI' => $data['PROFILKONEKSI'] ,
        'FLAGOLT' => '0' ,
        'FLAGROOTER' => '0' ,
       );
      // print_r($insertaktivasi);die();
      $this->model->registrasiOnu($insertaktivasi);
      }
      $res = array("result" => $check);
      echo json_encode($res);
    }
  // MODUL ONU AKIF
    function getDataOnuAktif() {
      $data = array( 'start' => $_POST['start'],
        'length' => $_POST['length'],
        'filtervalue' => $_POST['filtervalueonuaktif'],
        'filtertext' => $_POST['filtertextonuaktif']);
      $res = $this->model->getDataAllOnuAktif($data); echo json_encode($res);
    }
    function getDataSelectOnuAktif() {
      $res = $this->model->getSelectIdOnuaktif($_POST['id']);
      echo json_encode($res);
    }

  // MODUL ONU LOS
    function getDataOnuLos(){
      $data = array( 'start' => $_POST['start'],
        'length' => $_POST['length'],
        'filtervalue' => $_POST['filtervalueonulos'],
        'filtertext' => $_POST['filtertextonulos']);
      $res = $this->model->getDataAllOnuLos($data); echo json_encode($res);
    }
    function getDataselectdataOnuLos(){
      $res = $this->model->getSelectIdOnuLos($_POST['id']);
      echo json_encode($res);
    }
  // MODUL ONU LOS DYINGOSP
    function getDataOnuDyingGosp(){
      $data = array( 'start' => $_POST['start'],
        'length' => $_POST['length'],
        'filtervalue' => $_POST['filtervalueonudyinggosp'],
        'filtertext' => $_POST['filtertextonudyinggosp']);
      $res = $this->model->getDataAllOnuDyingGosp($data); echo json_encode($res);
    }
    function getDataselectdataOnuDyingGosp(){
      $res = $this->model->getSelectIdOnuDyingGosp($_POST['id']);
      echo json_encode($res);
    }

  function filterJenisPaket(){ $res = $this->model->getselectsJenisPaket(); echo json_encode($res); } // filter select options
  function filterKategoriPaket(){ $res = $this->model->getselectsKategoriPaket(); echo json_encode($res); } // filter select options
  function update(){
    $data = json_decode(file_get_contents('php://input'), true);
    $data = array(
      'KODEPAKET' =>  $data['KODEPAKET'],
      'NAMA_PAKET' =>  $data['NAMA_PAKET'],
      'JENIS_PAKET' =>  $data['JENIS_PAKET'],
      'KATEGORI_PAKET' =>  $data['KATEGORI_PAKET'],
      'HARGA' =>   $data['HARGA'],
      'SPEEDUP' =>  $data['SPEEDUP'],
      'SPEEDDOWN' =>   $data['SPEEDDOWN'],
      'BONUS' =>   $data['BONUS'],
      'KETERANGAN' => $data['KETERANGAN'],
    );
    $res = $this->model->update($data); echo $res;
  }
  function delete(){
    $data = json_decode(file_get_contents('php://input'), true);
    $data = array( 'KODEPAKET' => $data['id']);
    $res = $this->model->delete($data); echo $res;
  }
  function checkId(){
    $data = json_decode(file_get_contents('php://input'), true);
    $check = $this->model->checkId($data['id']);
    $res = array( 'res' => $check);echo json_encode($res);
  }
}
?>
