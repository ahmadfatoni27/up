<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_Pembayaran extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->helper(array('login','configsession','my'));cek_login();
    $this->load->model('transaksi/M__Pembayaran','model');
  }
  function index()
  {
    $data['title'] = "Data Paket";
    $data['session']= session();
    $this->template->load('_template', 'pelanggan/transaksi/@_dataPembayaran',$data);
  }
  function getData(){
    $data = array( 'start' => $_POST['start'],
    'length' => $_POST['length'],
    'filtervalue' => $_POST['filtervalue'],
    'filtertext' => $_POST['filtertext']);
    $res = $this->model->getDataAll($data); echo json_encode($res);
  }

  function getDataSelect(){
    $id = $this->input->get('id');
    $baseurl = base_url('upload/fotoktp/');
    $data = array('id' => $id, 'base_url' => $baseurl);
    $res = $this->model->getSelectId($data); echo json_encode($res);
  }
  function getDataTunggak(){
    $id = $this->input->get('id');
    $res = $this->model->_getTagihanTunggak($id); echo json_encode($res);
  }

  function save() {
    $data = json_decode(file_get_contents('php://input'), true);
    $listTagihan = $data['DATA_LIST_BAYAR_TAGIHAN'];
    $BayarListTagihan = json_decode($listTagihan);
    // print_r($BayarListTagihan);die();
    if($BayarListTagihan != '')
    $date = date("Y-m-d H:i:s");

    // if ($check['ID']==1) {
    foreach ($BayarListTagihan as $id) {
      $getdatainsert = $this->model->GetDataInsert($id);

      $idcheckBayar = array('IDTRANSAKSI' => $getdatainsert['IDBIAYA']);
      $hasil = $this->model->checkIdBayar($idcheckBayar);

      if ($hasil == "totalbiaya") {
        if ($getdatainsert['IDBIAYA']!='') {
          $insertDataMulti = array(
            "IDUNIQ" 				  => uniqid(),
            "IDTRANSAKSI"     => $getdatainsert['IDBIAYA'],
            "TGLBAYAR"        => $date,
            "JENISPEMBAYARAN" => $data['JENISPEMBAYARAN'],
            "IDPENERIMA" 	    => $data['CREATEBY'],
            "NOINDEXTAGIHAN" 	=> $getdatainsert['NOINDEXTAGIHAN'],
            "BAYAR" 	        => $getdatainsert['BAYAR'],
            "KET" 		        => $data['KET'],
          );
          $ress = $this->model->insertDataMultiLunas($insertDataMulti);
          $updateFlagTagihan = array(
            'IDTRANSAKSI' => $getdatainsert['IDBIAYA'],
            'FLAG'        => "2",
          );
          $ress = $this->model->updateFlagTagihan($updateFlagTagihan);
          $insertbuktitransasi = array(
            'IDPERMINTAAN' => $getdatainsert['IDBIAYA'],
            'TGLBAYAR'    => $date,
          );
          $cekvalue = array(
            'insertDataMulti' => $insertDataMulti,
            'updateFlagTagihan' => $updateFlagTagihan,
            'insertbuktitransasi' => $insertbuktitransasi,
          );
          // print_r($cekvalue);die();
          $ress = $this->model->insertbuktitransasi($insertbuktitransasi);
        }
      }else {
        if ($getdatainsert['IDBIAYA']!='') {
          $insertDataMulti = array(
            "IDUNIQ" 				  => uniqid(),
            "IDTRANSAKSI"     => $getdatainsert['IDBIAYA'],
            "TGLBAYAR"        => $date,
            "JENISPEMBAYARAN" => $data['JENISPEMBAYARAN'],
            "IDPENERIMA" 	    => $data['CREATEBY'],
            "NOINDEXTAGIHAN" 	=> $getdatainsert['NOINDEXTAGIHAN'],
            "BAYAR" 	        => $getdatainsert['BAYAR'],
            "KET" 		        => $data['KET'],
          );
          $ress = $this->model->insertDataMultiLunas($insertDataMulti);
          $updateFlagTagihan = array(
            'IDTRANSAKSI' => $getdatainsert['IDBIAYA'],
            'FLAG'        => "2",
          );
          $cekvalue = array(
            'insertDataMulti' => $insertDataMulti,
            'updateFlagTagihan' => $updateFlagTagihan,
          );
          // print_r($cekvalue);die();
          $ress = $this->model->updateFlagTagihan($updateFlagTagihan);
        }
      }


      // kirim pesan wa
      if ($data['HP']=="") {
        $ress = array(
          'status'  => false,
          'message' => 'NO HP NOT FOUND',
        );
      }else {
        $checkKeyactive = $this->keyActive();
        if ($checkKeyactive==='no connect') {
          $res = json_encode(array('status' => FALSE, 'res' => $checkKeyactive));
          echo $res;
        }else{
          $gettgl = array('id' => $getdatainsert['IDBIAYA'], 'no' => $getdatainsert['NOINDEXTAGIHAN'] );
          $tgltagihan = $this->model->gettanggaltagihan($gettgl);
          $bulan = NamaBulan($tgltagihan['BULAN']);
          //jalankan fungsi cron kirim pesan dan update notivwa menjadi 1
          $this->config->load('confcompany', TRUE);
          $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration, custom configuration in config/confcompany.php
          /* SENDING MESSAGE WA */
          $curl = curl_init();
          // AMBIL urlgatewaywa, api Whatsapp from setup confcompany.
          $CURLOPT_URL = ''.$urlgateway.'/index.php/api/sendMessageText';
          // BUAT CURLOPT_POSTFIELDS /  DATA YANG AKAN DI POST KE API WHATSAPP.
          $datakirimpesan = '{
            "instance_key":  "'.$this->keyActive().'" ,
            "jid": "'.$data['HP'].'",
            "message": "'.$date.' \n Pelanggan a.n *'.$data['NAMALENGKAP'].'*\n No.Pelanggan : _*'.$getdatainsert['IDBIAYA'].'*_ .\n Terimakasih anda telah melakukan pembayaran tagihan paket internet anda kepada \n Admin Dengan ID : _*'.$data['CREATEBY'].'*_.\n Untuk tagihan bulan : '.$bulan.' '.$tgltagihan['TAHUN'].'.\n Total Bayar: '.$getdatainsert['BAYAR'].'"
          }';
          // print_r($datakirimpesan);die();
          curl_setopt_array($curl, array(
            CURLOPT_URL => $CURLOPT_URL,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $datakirimpesan,
          ));
          curl_exec($curl);
          // $res = curl_exec($curl);
          curl_close($curl);
          /* END SENDING MESSAGE WA */
        }
      }

    } // END FOREACH
    echo json_encode($ress);
  }

  function deletetagihan(){
    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'];
    // print_r($id);die();
    $cektempat = $this->model->CekTempatData($id);
    $data = array('IDUNIQ' => $id);
    switch ($cektempat) {
      case 'data_tagihan':
      $res = $this->model->deleteapikeuangan_buktitransaksitagihan($data);
      break;
      case 'data_terkumpul':
      $res = $this->model->deleteapikeuangan_buktitransaksiterkumpul($data);
      break;
      default:
      $res = $cektempat;
      break;
    }
    echo json_encode($res);
  }
  function checkId(){
    $data = json_decode(file_get_contents('php://input'), true);
    // print_r($data['id']);die();
    $check = $this->model->checkId($data['id']);
    $res = array( 'res' => $check);echo json_encode($res);
  }

/* FUNCTION TO RUN WA MESSAGE */
  function keyActive(){
    $this->config->load('confcompany', TRUE);
    $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
    $curl = curl_init();
    $res = "".$urlgateway."/custom/Devices/getKeyDevice/key";
    curl_setopt_array($curl, array(
      CURLOPT_URL => $res,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    ));
    $response = curl_exec($curl); curl_close($curl);
    return $response = json_decode($response);
  }
  /*  CUSTOM = urlgateway*/
  function urlgateway(){
    $this->config->load('confcompany', TRUE);
    $urlgateway = $this->config->item('urlgatewaywa', 'confcompany'); // getconfiguration of url gatway
    $curl = curl_init();
    $url = "".$urlgateway."/custom/Devices/getUrl_getway";
    curl_setopt_array($curl, array(
      CURLOPT_URL => $url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    ));
    $response = curl_exec($curl); curl_close($curl);
    return $response = json_decode($response);
  }
  /*  END CUSTOM = urlgateway*/



  // reset tagihan
  // 1. ResetTagihan.php
  // 2. CronSesuaikanHarga.php
  // 3. CronTambahTagihanBulanan.php
  // 4. CronUpdateBukti.php
}
?>
