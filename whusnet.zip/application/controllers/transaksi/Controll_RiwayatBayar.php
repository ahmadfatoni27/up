<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controll_RiwayatBayar extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->helper(array('login','configsession','my'));cek_login();
    $this->load->model('transaksi/M__RiwayatBayar','model');
  }
  function index()
  {
    $data['title'] = "Data Paket";
    $data['session']= session();
    $this->template->load('_template', 'pelanggan/transaksi/@_dataRiwayatBayar',$data);
  }
  function getData(){
    $data = array( 'start' => $_POST['start'],
    'length' => $_POST['length'],
    'filtervalue' => $_POST['filtervalue'],
    'filtertext' => $_POST['filtertext']);
    $res = $this->model->getDataAll($data); echo json_encode($res);
  }

  function getDataSelect(){
    $id = $this->input->get('id');
    $baseurl = base_url('upload/fotoktp/');
    $data = array('id' => $id, 'base_url' => $baseurl);
    $res = $this->model->getSelectId($data); echo json_encode($res);
  }
  function getDataTunggak(){
    $id = $this->input->get('id');
    $res = $this->model->_getTagihanTunggak($id); echo json_encode($res);
  }
}?>
