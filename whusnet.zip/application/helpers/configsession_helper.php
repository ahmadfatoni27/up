<?php

function session(){

	$CI   = get_instance();
	$result = array(
		'IDUSERS' 			=> $CI->session->userdata('IDUSERS'),
		'IDPENGGUNA' 		=> $CI->session->userdata('IDPENGGUNA'),
		'JABATANID' 		=> $CI->session->userdata('JABATANID'),
		'JABATAN' 			=> $CI->session->userdata('JABATAN'),
		'CABANG' 			=> $CI->session->userdata('CABANG'),
		'NAMADEPAN' 		=> $CI->session->userdata('NAMADEPAN'),
		'NAMABELAKANG'		=> $CI->session->userdata('NAMABELAKANG'),
		'IDLEVEL' 			=> $CI->session->userdata('IDLEVEL'),
		'LEVEL' 			=> $CI->session->userdata('LEVEL'),
		'HP' 				=> $CI->session->userdata('HP'),
		'TLP' 				=> $CI->session->userdata('TLP'),
		'KOTA' 				=> $CI->session->userdata('KOTA'),
		'KEC' 				=> $CI->session->userdata('KEC'),
		'DESA' 				=> $CI->session->userdata('DESA'),
		'ALMT' 				=> $CI->session->userdata('ALMT'),
		'EMAIL' 			=> $CI->session->userdata('EMAIL'),
		'STATUSAKUN' 		=> $CI->session->userdata('STATUSAKUN'),
		'NAMAPERUSAHAAN'	=> $CI->session->userdata('NAMAPERUSAHAAN'),
		'NPWP' 				=> $CI->session->userdata('NPWP'),
		'KTP_SIM' 			=> $CI->session->userdata('KTP_SIM'),
		'FOTO' 				=> $CI->session->userdata('FOTO'),
		'is_logged_in' 		=> $CI->session->userdata('is_logged_in'),

		'host' 				=> $CI->session->userdata('host'),
		'nama'		 		=> $CI->session->userdata('NAMA_ROUTER'),
		'username_router' 	=> $CI->session->userdata('USERNAME'),
		'password_router' 	=> $CI->session->userdata('PASSWORD'),
		'port_router'	 	=> $CI->session->userdata('PORT'),
		'status_router' 	=> $CI->session->userdata('STATUSROUTER'),
		'is_logged'  		=> $CI->session->userdata('is_logged'),

		// theme
		'theme'  			=> $CI->session->userdata('theme'), 
	);
	return $result;
}



// function session_router() {

// 	$CI   = get_instance();

// 	$result = array(	

// 		'host' 				=> $CI->session->userdata('host'),

// 		'nama'		 		=> $CI->session->userdata('NAMA_ROUTER'),

// 		'username_router' 	=> $CI->session->userdata('USERNAME'),

// 		'password_router' 	=> $CI->session->userdata('PASSWORD'),

// 		'status_router' 	=> $CI->session->userdata('STATUSROUTER'),

// 		'is_logged'  		=> $CI->session->userdata('is_logged'),

// 	);

// 	return $result;

// }



// function configApp($title='tes', $c_des=null)

// {

//     $CI = get_instance();

//     // $CI->load->model('Konfigurasi_model');

//     $CI->load->model('M_auth', 'model');

//     $auth = $CI->model->get_by_id('IDUSERS');

//     $site = $CI->model->listing();

//     $data = array(

//         'TITLE' => $title.' | '.$site['nama_website'],

//         'LOGO' => $site['logo'],

//         'FAVICON' => $site['favicon'],

//         'email' => $site['email'],

//         'NO_TELP' => $site['no_telp'],

//         'ALAMAT' => $site['alamat'],

//         'FACEBOOK' => $site['facebook'],

//         'INSTAGRAM' => $site['instagram'],

//         'KEYWORDS' => $site['keywords'],

//         'METATEXT' => $site['metatext'],

//         'ABOUT' => $site['about'],

//         'SITE' => $site,

//         'C_JUDUL' => $title,

//         'C_DES' => $c_des,

//         'userdata' => $auth,

//     );

//     print_r($data);die();

//     return $data;

// }

