<?php

function cek_login()

{

  $CI = get_instance();

  if ($CI->session->userdata('is_logged_in') == "") {



    $CI->session->set_flashdata('msg', 'Please Login to Continue');

    redirect('Auth');
  }
}



function custom_redirect()
{

  $CI = get_instance();



  $CI->load->model('setting/M__jabatan', 'MJabatan');



  $sess_idjabatan = $CI->session->userdata('JABATANID');

  // check table jabatan

  $dataJabatanlevel[] = $CI->MJabatan->getSelectId($sess_idjabatan);

  // check jika Admin dan Admin / SPV survey dan SPV / SPV teknisi dan SPV

  $check_datasession = $dataJabatanlevel[0][0];
  //print_r($check_datasession->JABATAN);
  //die();
  //echo $check_datasession->JABATAN;
  if ($check_datasession->JABATAN == "Admin") {
    redirect('Admin');
  } else if ($check_datasession->JABATAN == "SPV Teknisi") {

    redirect('Admin_teknisi');
  } else if ($check_datasession->JABATAN == "SPV Survey") {

    redirect('Admin_survey');
  } else if ($check_datasession->JABATAN == "Manajer Utama") {

    redirect('Admin_manager');
  }
}





function cek_sessionRouter()

{

  $CI = get_instance();

  if ($CI->session->userdata('is_logged') == false) {

    $CI->session->set_flashdata('result', 'false');
  } else {

    $CI->session->set_flashdata('result', 'true');
  }
}



function signupString($s)

{

  $c = array(' ');

  $d = array('-', '/', '\\', ',', '.', '#', ':', ';', '\'', '"', '[', ']', '{', '}', ')', '(', '|', '`', '~', '!', '@', '%', '$', '^', '&', '*', '=', '?', '+');



  $s = str_replace($d, '', $s); // Hilangkan karakter yang telah disebutkan di array $d



  $s = strtolower(str_replace($c, '', $s)); // Ganti spasi dengan tanda - dan ubah hurufnya menjadi kecil semua

  return $s;
}
