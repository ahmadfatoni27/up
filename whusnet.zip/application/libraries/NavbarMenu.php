<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class NavbarMenu {

	function parentsData()
	{
		$this_CI =& get_instance();

		$this_CI->load->model('HelperModel');
		$this_CI->load->helper('configsession');

		$session 		= session();
		$idjabatan 	= $session['JABATANID'];

		$parents 		= $this_CI->HelperModel->getNavbarParents($idjabatan);
		$res 				= json_encode($parents); echo $res;
	}


}
/* End of file NavbarMenu.php */
